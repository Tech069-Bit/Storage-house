"""
Automation rules — simple "when I say X, do Y (and Z)" macros.

A rule maps a trigger phrase the user speaks to one or more short command
strings. When the user's speech matches a trigger, the mapped commands are
replayed into the live session exactly like a typed command would be — so
each action goes through the normal tool-selection path (Gemini decides
which real tool handles "lock my screen", "dim the lights", etc.). This
module only owns storage and matching; main.py is responsible for actually
injecting matched actions into the session.

Rules are stored locally in config/automation_rules.json — never synced,
never sent anywhere. Not committed to git (see .gitignore).
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


_RULES_PATH = _base_dir() / "config" / "automation_rules.json"

_MAX_RULES           = 40   # keeps the matcher cheap and the list manageable in UI
_MAX_ACTIONS_PER_RULE = 5
_MAX_TRIGGER_LEN      = 80
_MAX_ACTION_LEN       = 200


def _normalize(text: str) -> str:
    """Lowercase, collapse whitespace, strip punctuation for matching."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text


def load_rules() -> list[dict]:
    """Returns a list of {trigger, actions: [str, ...]} dicts."""
    try:
        data = json.loads(_RULES_PATH.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return data
    except Exception:
        pass
    return []


def _save_rules(rules: list[dict]) -> None:
    try:
        _RULES_PATH.parent.mkdir(parents=True, exist_ok=True)
        _RULES_PATH.write_text(json.dumps(rules, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print(f"[Automation] ⚠️  Could not save rules: {e}")


def add_rule(trigger: str, actions: list[str]) -> str:
    """Adds or replaces (same trigger = overwrite) a rule. Returns a spoken result string."""
    trigger = (trigger or "").strip()[:_MAX_TRIGGER_LEN]
    actions = [a.strip()[:_MAX_ACTION_LEN] for a in (actions or []) if a and a.strip()]
    actions = actions[:_MAX_ACTIONS_PER_RULE]

    if not trigger:
        return "I need a trigger phrase to set up that rule."
    if not actions:
        return "I need at least one action to run for that rule."

    rules = load_rules()
    norm = _normalize(trigger)
    rules = [r for r in rules if _normalize(r.get("trigger", "")) != norm]  # replace existing

    if len(rules) >= _MAX_RULES:
        return f"I already have {_MAX_RULES} automation rules — remove one before adding another."

    rules.append({"trigger": trigger, "actions": actions})
    _save_rules(rules)
    action_desc = ", then ".join(actions)
    return f"Done. When you say \"{trigger}\", I'll {action_desc}."


def remove_rule(trigger: str) -> str:
    trigger = (trigger or "").strip()
    rules = load_rules()
    norm = _normalize(trigger)
    kept = [r for r in rules if _normalize(r.get("trigger", "")) != norm]
    if len(kept) == len(rules):
        return f"I don't have a rule for \"{trigger}\"."
    _save_rules(kept)
    return f"Removed the rule for \"{trigger}\"."


def list_rules_text() -> str:
    rules = load_rules()
    if not rules:
        return "You don't have any automation rules set up yet."
    lines = [f"- \"{r['trigger']}\" → {', then '.join(r['actions'])}" for r in rules]
    return "Your automation rules:\n" + "\n".join(lines)


def match_rule(spoken_text: str) -> list[str] | None:
    """
    Returns the action list for the first rule whose trigger phrase appears
    in spoken_text (substring match on normalized text), or None.

    Substring rather than exact match so "I'm leaving now, bye" still hits
    a trigger of "leaving". Rules are checked longest-trigger-first so a more
    specific phrase wins over a shorter one it happens to contain.
    """
    if not spoken_text:
        return None
    norm_text = _normalize(spoken_text)
    if not norm_text:
        return None

    rules = sorted(load_rules(), key=lambda r: len(r.get("trigger", "")), reverse=True)
    for r in rules:
        norm_trigger = _normalize(r.get("trigger", ""))
        if norm_trigger and norm_trigger in norm_text:
            return r.get("actions", []) or None
    return None
