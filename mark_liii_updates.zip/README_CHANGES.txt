MARK LIII — CHANGED FILES PACKAGE
==================================
Extract this zip and copy each file into your project at the SAME relative
path shown below, overwriting the existing file each time.

ui.py
  -> Mark-LIII-main/ui.py
  Font swap: Courier New -> Segoe UI (centralized as FONT_FAMILY constant),
  one 6pt caption bumped to 7pt for legibility.

main.py
  -> Mark-LIII-main/main.py
  Added the automation-rule matching hook + queue that replays matched
  rule actions into the live session.

core/automation.py  (NEW FILE)
  -> Mark-LIII-main/core/automation.py
  Automation rule storage + trigger-phrase matching.

plugins/automation_control.py  (NEW FILE)
  -> Mark-LIII-main/plugins/automation_control.py
  Voice-facing tool: create/remove/list "when I say X, do Y" rules.

dashboard/static/app.html
  -> Mark-LIII-main/dashboard/static/app.html
  Push notifications (tab backgrounded) + quick-action buttons row.

.gitignore
  -> Mark-LIII-main/.gitignore
  Added config/automation_rules.json so your rules never get committed.

Not included: ui_preview.html and ui_original.py (reference/preview only,
not meant to be dropped into the project).

--- Window & Accessibility batch ---

ui.py (updated again)
  -> Mark-LIII-main/ui.py
  1. System tray icon: minimize-to-tray on close, tray menu (Show/Hide,
     Mute, Quit), left-click toggles window. Explicit Quit is the only
     path that actually exits.
  2. Always-on-top toggle: new button in the settings drawer + Ctrl+T,
     persisted across restarts.
  3. New shortcuts: Ctrl+R (remote dashboard), Ctrl+M (memory panel),
     Ctrl+T (always on top), Ctrl+L (focus command input),
     Ctrl+Shift+Q (quit for real, bypassing the tray).
  4. Left/right side panels are now a resizable QSplitter (drag to
     resize, double-click the handle to collapse) instead of fixed-width.

memory/config_manager.py  (updated)
  -> Mark-LIII-main/memory/config_manager.py
  Added get_always_on_top() / save_always_on_top() for the new toggle.
