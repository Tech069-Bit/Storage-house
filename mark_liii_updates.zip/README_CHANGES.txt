MARK LIII — CHANGED FILES PACKAGE
==================================
Extract this zip and copy each file into your project at the SAME relative
path shown below, overwriting the existing file each time.

ui.py
  -> Mark-LIII-main/ui.py
  Font swap: Courier New -> Segoe UI (centralized as FONT_FAMILY constant),
  one 6pt caption bumped to 7pt for legibility.

main.py
  -> Mark-LIII-main/main.py
  Added the automation-rule matching hook + queue that replays matched
  rule actions into the live session.

core/automation.py  (NEW FILE)
  -> Mark-LIII-main/core/automation.py
  Automation rule storage + trigger-phrase matching.

plugins/automation_control.py  (NEW FILE)
  -> Mark-LIII-main/plugins/automation_control.py
  Voice-facing tool: create/remove/list "when I say X, do Y" rules.

dashboard/static/app.html
  -> Mark-LIII-main/dashboard/static/app.html
  Push notifications (tab backgrounded) + quick-action buttons row.

.gitignore
  -> Mark-LIII-main/.gitignore
  Added config/automation_rules.json so your rules never get committed.

Not included: ui_preview.html and ui_original.py (reference/preview only,
not meant to be dropped into the project).
