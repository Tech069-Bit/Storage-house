"""
Automation rules plugin — "when I say X, do Y" voice macros.

Lets the user define simple trigger -> action(s) rules by voice, e.g.
"when I say I'm leaving, lock my screen and turn off the lights."
Matching + storage lives in core/automation.py; main.py checks each
finished user utterance against the stored rules and replays the matched
rule's actions into the live session as if the user had said them, so each
action still goes through normal tool selection (lock screen, smart home,
etc. — whatever already exists).
"""
from core.automation import add_rule, remove_rule, list_rules_text

PLUGIN = {
    "name": "manage_automation_rule",
    "description": (
        "Creates, removes, or lists automation rules — simple 'when I say X, do Y' voice "
        "macros the user sets up once and triggers later just by saying the trigger phrase "
        "naturally in conversation. Use action='add' when the user says things like "
        "'when I say leaving, lock my screen', 'set up a routine for X', 'automate X'. "
        "Use action='remove' when they say 'stop doing X when I say Y' or 'delete that automation'. "
        "Use action='list' when they ask what automations/routines they have set up. "
        "Do NOT use this tool to directly perform an action the user asks for right now — "
        "only use it to create, remove, or list the stored rules themselves."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "One of: 'add', 'remove', 'list'.",
            },
            "trigger": {
                "type": "STRING",
                "description": (
                    "The phrase that triggers this rule, e.g. 'leaving' or 'good morning'. "
                    "Required for 'add' and 'remove'."
                ),
            },
            "actions": {
                "type": "ARRAY",
                "items": {"type": "STRING"},
                "description": (
                    "One or more short natural-language commands to run in order when the "
                    "trigger fires, e.g. ['lock my screen', 'turn off the living room light']. "
                    "Required for 'add'."
                ),
            },
        },
        "required": ["action"],
    },
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    action = (parameters.get("action") or "").strip().lower()
    trigger = parameters.get("trigger", "")
    actions = parameters.get("actions", [])

    try:
        if action == "add":
            result = add_rule(trigger, actions)
        elif action == "remove":
            result = remove_rule(trigger)
        elif action == "list":
            result = list_rules_text()
        else:
            result = f"Sir, I don't recognize automation action '{action}'."
    except Exception as e:
        return f"Sir, automation rule handling failed: {e}"

    if player:
        try:
            player.write_log(f"JARVIS: {result}")
        except Exception:
            pass
    return result
