import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { mount, flushPromises } from "@vue/test-utils";
import { reactive } from "vue";

// vi.mock is HOISTED; vi.doMock is not. Mocking the store from inside a helper
// would run AFTER the component's graph resolved, loading the real singleton
// and failing every assertion.
// `call` is stubbed too: @/api imports it at module scope, and vitest throws
// "No 'call' export is defined on the mock" for any imported name the factory
// omits — so leaving it out would break the import of supportDownloadUrl, which
// these tests deliberately exercise for real.
// The thread reply is now SupportReplyBox (a collapse-to-expand wrapper around
// SupportComposer, which is a frappe-ui TextEditor + footer) — so TextEditor must
// be stubbed (TipTap is too heavy for jsdom) and toast needs `info` (the attach-flow
// + removed-images notices). SupportReplyBox forwards the same props/events, so the
// thread tests drive it directly (no need to expand into the nested composer).
// dompurify is left REAL: renderSupportHtml's sanitize is exercised for real by
// the "routes the body through the sanitizer" test below.
vi.mock("frappe-ui/editor-style.css", () => ({}));
vi.mock("frappe-ui", () => ({
	Badge: { name: "Badge", template: "<span/>" },
	Button: {
		// name so the refresh-on-close test below can pick the Resolve button
		// out of a tree that has several unlabelled <button> stubs.
		name: "Button",
		props: ["label", "disabled", "loading"],
		template: "<button :disabled='disabled'><slot/></button>",
	},
	FeatherIcon: { template: "<i/>" },
	LoadingIndicator: { template: "<i/>" },
	TextEditor: { name: "TextEditor", props: ["content"], template: "<div class='editor'/>" },
	call: vi.fn(),
	toast: { success: vi.fn(), error: vi.fn(), info: vi.fn() },
}));

// useRoute/useRouter are injection-based — global.mocks.$route does NOT feed
// them; the module has to be mocked. `routeTicket` is mutable so the C1
// switch test below can mount with a different ticket than the rest of the
// file, which all assume "T1".
let routeTicket = "T1";
// Each useRoute() call returns its OWN fresh reactive() proxy (never a shared
// singleton) — real vue-router's route is reactive, and ticketName's computed
// depends on route.params.ticket, so a plain object here would make that
// computed cache its first value forever with no way to observe a mid-flight
// route change. Per-call freshness keeps this isolated: only the CURRENTLY
// mounting instance's object is tracked in `lastRouteState`, so a later
// test's mutation can never reach an earlier test's still-mounted instance.
let lastRouteState = null;
vi.mock("vue-router", () => ({
	useRoute: () => {
		lastRouteState = reactive({ params: { ticket: routeTicket } });
		return lastRouteState;
	},
	useRouter: () => ({ push: vi.fn(), replace: vi.fn() }),
}));

// datetime.js's formatDate/exactDate route through frappe-ui's dayjsLocal,
// which needs a systemTimezone config this test never sets up. Mock it
// directly so timestamp formatting is a pure, predictable pass-through here —
// the real tz-conversion path is covered where it's actually exercised
// (datetime.js has no dedicated suite yet, but nothing in this file asserts
// on exact formatted output, only presence/absence).
// dayLabel is mocked to a bare YYYY-MM-DD bucket (not the real "Today" /
// "Yesterday" / weekday logic — that belongs to datetime.js's own suite) so
// the day-divider tests below can assert on BUCKETING (same day vs. different
// day) without depending on wall-clock "today".
vi.mock("@/utils/datetime", () => ({
	formatDate: (v) => (v ? String(v) : ""),
	exactDate: (v) => (v ? String(v) : ""),
	dayLabel: (v) => (v ? String(v).slice(0, 10) : ""),
	// SupportTicketPanel (rendered via the #aside slot) imports toLocalMs; vitest
	// throws on any imported name the mock omits, so provide a plain parser.
	toLocalMs: (v) => (v == null || v === "" ? null : typeof v === "number" ? v : Date.parse(v)),
}));

const storeDouble = {
	tickets: [],
	thread: { ticket: "T1", messages: [], attachments: [], loading: false, error: "" },
	ticketRow: () => storeDouble.tickets[0] || null,
	badgeFor: () => ({ label: "Open", theme: "blue" }),
	isClosed: () => false,
	isAwaiting: () => false,
	fingerprintOf: () => "x",
	loadTickets: vi.fn(),
	loadThread: vi.fn(),
	closeTicket: vi.fn(),
	// async, matching the real store's contract (an `async function`, so it
	// ALWAYS returns a Promise even though it catches its own errors
	// internally) - the call sites chain .catch() on this, so a default
	// double that returns bare `undefined` would throw "Cannot read
	// properties of undefined (reading 'catch')" in every test that reaches
	// a successful close/reply and never overrides this mock.
	refreshAwaiting: vi.fn(async () => {}),
	reply: vi.fn(async () => true),
	// Fix 2: uploadTo returns the succeeded FILE REFERENCES, not a count — a
	// realistic default double is "everything I was given succeeded".
	uploadTo: vi.fn(async (name, files) => files),
};
vi.mock("@/stores/support", () => ({ useSupportStore: () => storeDouble }));

// UserMenu (reused in SupportSidebar) pulls theme.js/frappe-ui at import time — module-mock it (own suite).
vi.mock("@/components/shell/UserMenu.vue", () => ({
	default: { name: "UserMenu", template: "<div/>" },
}));
import SupportThreadPage from "@/pages/support/SupportThreadPage.vue";
import SupportReplyBox from "@/components/support/SupportReplyBox.vue";
import SupportTicketPanel from "@/components/support/SupportTicketPanel.vue";

beforeEach(() => {
	vi.stubGlobal("matchMedia", () => ({
		matches: false,
		addEventListener() {},
		removeEventListener() {},
	}));
	// Assign onto URL; do NOT replace it with a spread — class statics are
	// non-enumerable, so `{ ...URL }` is `{}` and would destroy the constructor.
	URL.createObjectURL = () => "blob:x";
	URL.revokeObjectURL = () => {};
	routeTicket = "T1";
});

function mountWith(messages, ticket = { name: "T1", subject: "Broken", status: "Open" }) {
	storeDouble.tickets = [ticket];
	storeDouble.thread.messages = messages;
	return mount(SupportThreadPage, {
		global: {
			stubs: { SupportShell: { template: "<div><slot name='actions'/><slot/></div>" } },
		},
	});
}

describe("SupportThreadPage", () => {
	it("renders an agent message as a row and a customer message as a bubble", () => {
		// sent_or_received === "Sent" is the ONLY proven discriminator; if this
		// inverts, every message renders on the wrong side with no error.
		const w = mountWith([
			{ sent_or_received: "Sent", content: "<p>hi</p>", creation: "2026-07-24 10:00:00" },
			{
				sent_or_received: "Received",
				content: "<p>thanks</p>",
				creation: "2026-07-24 10:01:00",
			},
		]);
		const msgs = w.findAllComponents({ name: "Message" });
		expect(msgs[0].props("variant")).toBe("row");
		expect(msgs[1].props("variant")).toBe("bubble");
	});

	it("renders the customer bubble's HTML body, not flattened text", () => {
		// Message's bubble took `text` only before this task; passing email HTML
		// through textContent collapses <p>a</p><p>b</p> into "ab". The bubble has
		// to render the sanitized html, inside the bubble's own chrome.
		const w = mountWith([
			{ sent_or_received: "Received", content: "<p>one</p><p>two</p>", creation: "" },
		]);
		const bubble = w.find(".jv-ububble");
		expect(bubble.exists()).toBe(true);
		expect(bubble.findAll("p")).toHaveLength(2);
		expect(bubble.find(".jv-md-body").classes()).toContain("jv-html");
	});

	it("passes bodyClass=jv-html so email HTML gets the right style block", () => {
		const w = mountWith([{ sent_or_received: "Sent", content: "<p>hi</p>" }]);
		expect(w.findComponent({ name: "Message" }).props("bodyClass")).toBe("jv-html");
	});

	it("labels the agent 'Support' and never leaks the sender email", () => {
		// The payload carries `sender` as an email and no display name at all —
		// often the service account jarvis-support-bot@jarvis.internal. Rendering
		// it would leak plumbing and mislabel a human agent.
		const w = mountWith([
			{
				sent_or_received: "Sent",
				sender: "jarvis-support-bot@jarvis.internal",
				content: "<p>hi</p>",
			},
		]);
		const m = w.findComponent({ name: "Message" });
		expect(m.props("sender")).toBe("Support");
		expect(w.text()).not.toContain("@jarvis.internal");
	});

	it("routes the body through the sanitizer — not raw content", () => {
		// THE mutation that matters: swapping renderSupportHtml(m.content) for
		// m.content leaves every other test in this file green while shipping an
		// XSS hole. supportHtml is unit-tested in isolation; this pins its USE.
		const w = mountWith([
			{
				sent_or_received: "Sent",
				content: '<img src="/files/a.png" onerror="alert(1)"><script>alert(2)</script>',
			},
		]);
		const html = w.findComponent({ name: "Message" }).props("html");
		expect(html).not.toContain("onerror");
		expect(html).not.toContain("<script");
		expect(html).toContain("jarvis.support.media.download");
	});

	it("maps attachments into the shape Message actually renders", () => {
		// Message keys attachments on `name` and titles them `title`, and picks the
		// thumbnail vs. file-chip branch off `type`. The CP sends {file_url,
		// file_name} — pass those through untouched and every attachment silently
		// vanishes.
		const w = mountWith([
			{
				sent_or_received: "Sent",
				content: "<p>see attached</p>",
				attachments: [
					{ file_url: "/files/shot.png", file_name: "shot.png" },
					{ file_url: "/files/log.txt", file_name: "log.txt" },
				],
			},
		]);
		const atts = w.findComponent({ name: "Message" }).props("attachments");
		expect(atts[0]).toMatchObject({
			type: "image",
			title: "shot.png",
			name: "/files/shot.png",
		});
		expect(atts[0].file_url).toContain("jarvis.support.media.download");
		// Non-images must still be present and classified — they are the primary
		// agent-reply payload (logs, PDFs), not an edge case.
		expect(atts[1]).toMatchObject({ type: "file", title: "log.txt" });
		// …and they must actually REACH the DOM: Message renders a file chip for
		// them, which is the amendment this page depends on.
		const chips = w.findAll(".jv-file-chip");
		expect(chips).toHaveLength(2);
		expect(chips[0].text()).toContain("shot.png");
		expect(chips[0].attributes("href")).toContain("jarvis.support.media.download");
		const chip = chips[1];
		expect(chip.text()).toContain("log.txt");
		expect(chip.attributes("href")).toContain("jarvis.support.media.download");
		// The clip icon must be an SVG (house design forbids emoji-as-icon), not
		// the 📎 glyph this chip used to render — pin against a silent regression.
		expect(chip.find("svg").exists()).toBe(true);
		expect(chip.text()).not.toContain("📎");
	});

	it("falls back to the file_url basename when file_name is missing (minor)", () => {
		// A File record with no file_name would otherwise render Message's chip
		// as an unlabeled "📎 " — the URL's own basename is still readable.
		const w = mountWith([
			{
				sent_or_received: "Sent",
				content: "<p>see attached</p>",
				attachments: [{ file_url: "/files/abc123.pdf" }],
			},
		]);
		const atts = w.findComponent({ name: "Message" }).props("attachments");
		expect(atts[0].title).toBe("abc123.pdf");
		expect(atts[0].type).toBe("file");
	});

	it("merges ticket-level opening attachments into the opening message, proxy-authenticated", () => {
		// The opening file used to render in a captioned slab ABOVE the thread; it
		// now rides the opening message itself (the message the customer opened the
		// ticket with — "Received"), still through the authenticated download proxy.
		storeDouble.thread.attachments = [{ file_url: "/files/spec.pdf", file_name: "spec.pdf" }];
		const w = mountWith([{ sent_or_received: "Received", content: "<p>hi</p>" }]);
		const atts = w.findComponent({ name: "Message" }).props("attachments");
		const spec = atts.find((a) => a.title === "spec.pdf");
		expect(spec).toBeTruthy();
		expect(spec.file_url).toContain("jarvis.support.media.download");
		expect(spec.file_url).toContain("spec.pdf");
		storeDouble.thread.attachments = [];
	});

	it("renders every opening attachment as the same file chip, images included", () => {
		// Images get no special inline-thumbnail treatment (images-as-chips) - a
		// cropped preview read worse than a plain filename the user clicks. Both
		// shapes are {file_url, file_name} from the CP.
		storeDouble.thread.attachments = [
			{ file_url: "/files/shot.png", file_name: "shot.png" },
			{ file_url: "/files/spec.pdf", file_name: "spec.pdf" },
		];
		const w = mountWith([{ sent_or_received: "Received", content: "<p>hi</p>" }]);

		const atts = w.findComponent({ name: "Message" }).props("attachments");
		const titles = atts.map((a) => a.title);
		expect(titles).toContain("shot.png");
		expect(titles).toContain("spec.pdf");
		// image renders as a file chip, never an inline <img>
		const chips = w.findAll(".jv-file-chip");
		expect(chips.some((c) => c.text().includes("shot.png"))).toBe(true);
		expect(w.find(".jv-file-chip img").exists()).toBe(false);

		storeDouble.thread.attachments = [];
	});

	it("carries opening attachments in a synthetic customer bubble when the first message is a Support reply", () => {
		// If the opening text was never mirrored to a Communication, the first
		// Communication can be a Support reply. The customer's opening files must
		// NOT land on the agent's bubble — they get their own opening bubble.
		storeDouble.thread.attachments = [{ file_url: "/files/spec.pdf", file_name: "spec.pdf" }];
		const w = mountWith([{ sent_or_received: "Sent", content: "<p>agent first</p>" }]);
		const msgs = w.findAllComponents({ name: "Message" });
		expect(msgs).toHaveLength(2);
		expect(msgs[0].props("variant")).toBe("bubble");
		expect(msgs[0].props("attachments").some((a) => a.title === "spec.pdf")).toBe(true);
		storeDouble.thread.attachments = [];
	});

	it("shows an empty-conversation state instead of a blank void when there are no messages yet (minor)", () => {
		// Reachable: a brand-new ticket created with an empty body and no files
		// has zero Communications (the initial text is the HD Ticket's
		// `description`, not a reply).
		storeDouble.thread.loading = false;
		storeDouble.thread.error = "";
		const w = mountWith([]);
		expect(w.text()).toContain("start of your conversation");
	});

	it("shows a day-divider before the first message of each new day, and none between same-day messages", () => {
		const w = mountWith([
			{ sent_or_received: "Sent", content: "<p>a</p>", creation: "2026-07-23 09:00:00" },
			{ sent_or_received: "Received", content: "<p>b</p>", creation: "2026-07-23 09:05:00" },
			{ sent_or_received: "Sent", content: "<p>c</p>", creation: "2026-07-24 08:00:00" },
		]);
		const dividers = w.findAll(".jv-sup-daydivider");
		expect(dividers).toHaveLength(2);
		expect(dividers[0].text()).toBe("2026-07-23");
		expect(dividers[1].text()).toBe("2026-07-24");
	});

	it("renders no day-divider at all when every message is dateless", () => {
		const w = mountWith([
			{ sent_or_received: "Sent", content: "<p>a</p>" },
			{ sent_or_received: "Received", content: "<p>b</p>" },
		]);
		expect(w.findAll(".jv-sup-daydivider")).toHaveLength(0);
	});

	it("keeps the composer enabled on a resolved ticket and states both the Resolve and reply paths", () => {
		// There is no reopen endpoint — a reply is the ONLY way back. Disabling
		// the composer here would strand the user with no path forward. Resolved
		// gets its OWN copy (not the bare "Replying reopens this ticket." the
		// Closed case below uses): the header still shows "Awaiting you" AND the
		// Resolve button here, so the disclaimer spells out both valid next steps
		// instead of reading as if it contradicts the header.
		const w = mountWith([], { name: "T1", subject: "x", status: "Resolved" });
		const c = w.findComponent(SupportReplyBox);
		expect(c.props("disclaimer")).toBe("Resolve to confirm and close, or reply to reopen.");
	});

	it("shows the plain reopens disclaimer for a ticket the store considers closed (not Resolved)", () => {
		storeDouble.isClosed = (s) => s === "Closed";
		const w = mountWith([], { name: "T1", subject: "x", status: "Closed" });
		const c = w.findComponent(SupportReplyBox);
		expect(c.props("disclaimer")).toBe("Replying reopens this ticket.");
		storeDouble.isClosed = () => false; // restore the file's default double
	});

	it("arms Send for an attachment-only reply", () => {
		const w = mountWith([]);
		w.findComponent(SupportReplyBox).vm.$emit("files-added", [
			{ name: "a.png", type: "image/png" },
		]);
		return w.vm.$nextTick().then(() => {
			expect(w.findComponent(SupportReplyBox).props("canSubmit")).toBe(true);
		});
	});

	it("posts the body BEFORE uploading, since upload needs the ticket to exist", async () => {
		// media.upload attaches to an EXISTING ticket and posting the text is what
		// reopens a resolved one — so this order is a correctness constraint, not
		// a style preference. Reversed, an attachment-and-text reply to a resolved
		// ticket uploads into a ticket that is still closed.
		const order = [];
		const w = mountWith([]);
		storeDouble.reply = vi.fn(async () => {
			order.push("reply");
			return true;
		});
		storeDouble.uploadTo = vi.fn(async (name, files) => {
			order.push("upload");
			return files;
		});

		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", "here is the log");
		c.vm.$emit("files-added", [{ name: "log.txt", type: "text/plain" }]);
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await flushPromises();

		expect(order).toEqual(["reply", "upload"]);
	});

	it("keeps the draft and the pending attachment when the reply fails", async () => {
		// The regression this pins: `draft.value = ""` moving above the
		// `if (!ok) return` guard. If that happens, modelValue below reverts to
		// "" even though nothing was ever posted, and the user's text is gone.
		storeDouble.reply = vi.fn(async () => false);
		// Fresh spy: a prior test's uploadTo call history must not leak in here —
		// nothing in this file resets mocks between tests.
		storeDouble.uploadTo = vi.fn(async (name, files) => files);
		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", "please help");
		c.vm.$emit("files-added", [{ name: "log.txt", type: "text/plain" }]);
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await flushPromises();

		expect(c.props("modelValue")).toBe("please help");
		expect(c.props("pending")).toHaveLength(1);
		expect(storeDouble.uploadTo).not.toHaveBeenCalled();
	});

	it("drops canSend and shows the Send spinner while a reply is in flight, restoring both once settled", async () => {
		// Double-submit guard: `canSend` going false while `sending` is true is what
		// stands between the user and a second concurrent submit (the composer has no
		// Stop control). `loading` (F5) also tracks `sending`, so the Send button
		// spins during the reply — matching the new-ticket Submit for a unanimous feel.
		// Resolving to `false` (reply failed, draft kept) gives an unambiguous
		// "back to true / spinner off" afterward without re-typing.
		let resolveReply;
		storeDouble.reply = vi.fn(() => new Promise((r) => (resolveReply = r)));
		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", "hello");
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await w.vm.$nextTick();

		expect(c.props("canSubmit")).toBe(false);
		expect(c.props("loading")).toBe(true);

		resolveReply(false);
		await flushPromises();

		expect(c.props("canSubmit")).toBe(true);
		expect(c.props("loading")).toBe(false);
	});

	it("hides the status badge and shows no reopen disclaimer for an out-of-list ticket (fix 3, row=null)", () => {
		// A deep-linked ticket outside the newest 50 the list ever fetches has no
		// row at all — get_thread carries no status, so the row is the ONLY
		// source. Rendering "Open" (badgeFor(null)'s catch-all) would be an
		// outright lie for a possibly-Closed ticket. mountWith() always wraps a
		// row into `tickets`, so mount directly with an EMPTY list (matches the
		// double's `ticketRow: () => tickets[0] || null`).
		storeDouble.tickets = [];
		storeDouble.thread.messages = [];
		storeDouble.thread.loading = false;
		storeDouble.thread.error = "";
		storeDouble.loadThread = vi.fn(async () => {});
		storeDouble.loadTickets = vi.fn(async () => {});
		routeTicket = "T1";
		const w = mount(SupportThreadPage, {
			global: {
				stubs: { SupportShell: { template: "<div><slot name='actions'/><slot/></div>" } },
			},
		});
		expect(w.findComponent({ name: "Badge" }).exists()).toBe(false);
		const c = w.findComponent(SupportReplyBox);
		expect(c.props("disclaimer")).toBe("");
	});

	it("shows the badge + reopen disclaimer for an out-of-list ticket via thread.meta.status (deep-link fix)", () => {
		// The complement of the test above: get_thread's meta now DOES carry the
		// status, so a deep-linked ticket (row=null) shows the correct badge + Resolve
		// gating + disclaimer instead of a blank header contradicting the panel.
		storeDouble.tickets = [];
		storeDouble.thread.messages = [];
		storeDouble.thread.error = "";
		storeDouble.thread.meta = { name: "T1", status: "Closed" };
		storeDouble.isClosed = (s) => s === "Closed";
		storeDouble.loadThread = vi.fn(async () => {});
		storeDouble.loadTickets = vi.fn(async () => {});
		routeTicket = "T1";
		const w = mount(SupportThreadPage, {
			global: {
				stubs: { SupportShell: { template: "<div><slot name='actions'/><slot/></div>" } },
			},
		});
		expect(w.findComponent({ name: "Badge" }).exists()).toBe(true);
		expect(w.findComponent(SupportReplyBox).props("disclaimer")).toBe(
			"Replying reopens this ticket."
		);
		storeDouble.thread.meta = null; // restore shared state
		storeDouble.isClosed = () => false;
	});

	it("shows no disclaimer for an open (non-resolved, non-closed) ticket", () => {
		// Only the Resolved positive case was covered before; an unconditional
		// disclaimer (e.g. dropping the ternary's else branch) would pass that
		// test and still be wrong for the common case.
		const w = mountWith([], { name: "T1", subject: "x", status: "Open" });
		const c = w.findComponent(SupportReplyBox);
		expect(c.props("disclaimer")).toBe("");
	});

	it("keeps staged files pending when uploadTo reports fewer successes than requested", async () => {
		// Proof of fix 2: uploadTo returns the succeeded FILE REFERENCES. A
		// silent `files.value = []` here would discard attachments the user
		// still needs to retry after a transient upload failure.
		storeDouble.uploadTo = vi.fn(async () => []); // nothing succeeded
		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("files-added", [
			{ name: "a.png", type: "image/png" },
			{ name: "b.png", type: "image/png" },
		]);
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await flushPromises();

		expect(c.props("pending")).toHaveLength(2);
	});

	it("clears the previous ticket's messages before a different ticket's fetch resolves (C1)", () => {
		// Without this reset, opening ticket B while A's messages are still in
		// the singleton store would show A's conversation under B's title for
		// the whole fetch — and if B's fetch failed, the error branch would
		// never show (it's gated on !thread.messages.length), stranding A's
		// conversation on B's URL with a composer that posts to B.
		storeDouble.tickets = [{ name: "T2", subject: "B", status: "Open" }];
		storeDouble.thread.ticket = "T1";
		storeDouble.thread.messages = [
			{ sent_or_received: "Sent", content: "<p>A's message</p>" },
		];
		storeDouble.thread.attachments = [{ file_url: "/files/a.png", file_name: "a.png" }];
		storeDouble.thread.error = "";
		// Never resolves within this test — proves the reset happens
		// SYNCHRONOUSLY on mount, not only after B's fetch eventually settles.
		storeDouble.loadThread = vi.fn(() => new Promise(() => {}));
		routeTicket = "T2";

		mount(SupportThreadPage, {
			global: {
				stubs: { SupportShell: { template: "<div><slot name='actions'/><slot/></div>" } },
			},
		});

		expect(storeDouble.thread.messages).toEqual([]);
		expect(storeDouble.thread.attachments).toEqual([]);
		expect(storeDouble.thread.error).toBe("");
	});

	it("posts a reply/upload started before a ticket switch to the ORIGINAL ticket, not the one switched to mid-flight", async () => {
		// The regression this pins: reading ticketName.value AFTER the awaited
		// store.reply/uploadTo below (instead of a tName snapshot taken at
		// send()'s entry) would attach this in-flight reply's body and files to
		// whatever ticket the route has moved to by the time each await
		// resolves — permanent, since there is no un-attach.
		let resolveReply;
		storeDouble.reply = vi.fn(() => new Promise((r) => (resolveReply = r)));
		storeDouble.uploadTo = vi.fn(async (name, files) => files);
		storeDouble.loadThread = vi.fn(async () => {});
		storeDouble.loadTickets = vi.fn(async () => {});
		storeDouble.fingerprintOf = vi.fn(() => "x");

		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", "please help");
		c.vm.$emit("files-added", [{ name: "log.txt", type: "text/plain" }]);
		await w.vm.$nextTick();

		c.vm.$emit("submit"); // send() starts: ticketName.value is "T1" right now
		await w.vm.$nextTick();

		// The user switches to a different ticket while the reply is still in
		// flight — mutate the SAME reactive route object this mounted instance
		// captured via useRoute() (lastRouteState), same as vue-router would.
		lastRouteState.params.ticket = "T2";
		// Simulate T2 having already opened (the route watcher's own open("T2")
		// sets this too, but pin it explicitly so the guard's `!== tName` branch
		// is deterministic and doesn't depend on watcher timing).
		storeDouble.thread.ticket = "T2";
		await w.vm.$nextTick();

		// Snapshot the "T1" loadThread call count BEFORE the reply resolves: mount
		// and the route-switch's own open("T2") both call loadThread already, so
		// asserting "never called with T1" would be false regardless of the fix —
		// only a count that does NOT grow proves the tail refresh was skipped.
		const t1CallsBefore = storeDouble.loadThread.mock.calls.filter(([n]) => n === "T1").length;

		resolveReply(true);
		await flushPromises();

		expect(storeDouble.reply).toHaveBeenCalledWith("T1", "please help");
		// uploadTo(ticket, files, replyComm): the 3rd arg threads the reply
		// Communication so each File attaches to it (support store uploadTo).
		expect(storeDouble.uploadTo).toHaveBeenCalledWith(
			"T1",
			expect.anything(),
			expect.anything()
		);
		expect(storeDouble.uploadTo).not.toHaveBeenCalledWith(
			"T2",
			expect.anything(),
			expect.anything()
		);

		// The regression: send()'s post-send DISPLAY refresh must not hijack the
		// thread back to "T1" once the user is looking at "T2" — the guard
		// (`store.thread.ticket === tName`) skips loadThread(tName) entirely when
		// the two disagree. Without the guard this count would grow by one.
		const t1CallsAfter = storeDouble.loadThread.mock.calls.filter(([n]) => n === "T1").length;
		expect(t1CallsAfter).toBe(t1CallsBefore);
	});

	it("keeps text typed during an in-flight send instead of wiping it (I2)", async () => {
		// The regression this pins: an unconditional `draft.value = ""` after
		// reply() resolves wipes whatever the draft holds NOW, even if the user
		// kept typing during the multi-second send. Only a draft that still
		// equals the posted snapshot should be cleared.
		let resolveReply;
		storeDouble.reply = vi.fn(() => new Promise((r) => (resolveReply = r)));
		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", "please help");
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await w.vm.$nextTick();

		// The user keeps typing while the reply is still in flight.
		c.vm.$emit("update:modelValue", "please help more");
		await w.vm.$nextTick();

		resolveReply(true);
		await flushPromises();

		expect(c.props("modelValue")).toBe("please help more");
	});

	it("clears the reply box after a clean send (draft unchanged during flight)", async () => {
		// Pins the clear line (SupportThreadPage send()'s `draft.value = ""`):
		// without it the sent text lingers in the composer, still armed — a trivial
		// double-send. The stubbed TextEditor can't run TipTap, but the page's draft
		// ref IS the composer's modelValue, so modelValue resetting to "" proves the
		// clear ran. (The reference-safe compare is covered by the I2 test above.)
		storeDouble.reply = vi.fn(async () => true);
		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", "<p>done</p>");
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await flushPromises();

		expect(c.props("modelValue")).toBe("");
	});

	it("does NOT arm Send for a blank TipTap doc (<p></p>) with no files", async () => {
		// The reply draft is HTML now: `.trim()` on "<p></p>" is truthy and would arm
		// Send, posting an empty reply — the exact bug this whole change fixes, so
		// canSend MUST gate on supportBodyIsEmpty, not `.trim()`. Reverting canSend to
		// `!!draft.value.trim()` turns this red.
		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", "<p></p>");
		await w.vm.$nextTick();

		expect(c.props("canSubmit")).toBe(false);
	});

	it("clears an image-only draft after a files-only (synthesized) send", async () => {
		// Fix 5: draft holds only an inline data: image plus a staged file.
		// prepareSupportBody strips the image -> empty body -> a synthesized files-only
		// reply; the clear must STILL run (the raw-snapshot matches) so the editor
		// doesn't strand the very image the "removed images" toast just said was gone.
		// Re-adding the old `!synthesized` guard on the clear turns this red.
		storeDouble.reply = vi.fn(async () => true);
		storeDouble.uploadTo = vi.fn(async (name, files) => files);
		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", '<p><img src="data:image/png;base64,AAAA"></p>');
		c.vm.$emit("files-added", [{ name: "shot.png", type: "image/png" }]);
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await flushPromises();

		expect(c.props("modelValue")).toBe("");
	});
});

describe("reply box collapse + panel wiring (redesign)", () => {
	const replyBox = (w) => w.findComponent(SupportReplyBox);

	it("collapses the reply box after a clean send", async () => {
		storeDouble.reply = vi.fn(async () => true);
		storeDouble.uploadTo = vi.fn(async (n, f) => f);
		const w = mountWith([]);
		const rb = replyBox(w);
		rb.vm.$emit("update:expanded", true); // user opened it
		rb.vm.$emit("update:modelValue", "<p>hi</p>");
		await w.vm.$nextTick();
		expect(rb.props("expanded")).toBe(true);
		rb.vm.$emit("submit");
		await flushPromises();
		expect(rb.props("expanded")).toBe(false);
	});

	it("keeps the reply box expanded when a partial upload leaves files staged", async () => {
		// files remain -> nothing collapses (the user still has chips to retry).
		storeDouble.reply = vi.fn(async () => true);
		storeDouble.uploadTo = vi.fn(async () => []); // nothing succeeded
		const w = mountWith([]);
		const rb = replyBox(w);
		rb.vm.$emit("update:expanded", true);
		rb.vm.$emit("files-added", [{ name: "a.png", type: "image/png" }]);
		await w.vm.$nextTick();
		rb.vm.$emit("submit");
		await flushPromises();
		expect(rb.props("expanded")).toBe(true);
	});

	it("keeps the reply box expanded when the user retypes during an in-flight send", async () => {
		// draft changed -> cleared=false -> no collapse (mirrors the I2 keep-draft guard).
		let resolveReply;
		storeDouble.reply = vi.fn(() => new Promise((r) => (resolveReply = r)));
		const w = mountWith([]);
		const rb = replyBox(w);
		rb.vm.$emit("update:expanded", true);
		rb.vm.$emit("update:modelValue", "hello");
		await w.vm.$nextTick();
		rb.vm.$emit("submit");
		await w.vm.$nextTick();
		rb.vm.$emit("update:modelValue", "hello more"); // retype during flight
		await w.vm.$nextTick();
		resolveReply(true);
		await flushPromises();
		expect(rb.props("expanded")).toBe(true);
	});

	it("keeps the box expanded if the user retypes during the post-send refetch window", async () => {
		// Medium-6 hardening: `cleared` latches right after reply(), but the collapse
		// fires after uploadTo+loadTickets+loadThread — a follow-up typed in that
		// window must keep the box open (collapse re-checks supportBodyIsEmpty(draft)).
		storeDouble.reply = vi.fn(async () => true);
		storeDouble.loadTickets = vi.fn(async () => {});
		storeDouble.fingerprintOf = vi.fn(() => "x");
		let resolveLoad;
		storeDouble.loadThread = vi.fn(() => new Promise((r) => (resolveLoad = r)));
		const w = mountWith([]);
		const rb = replyBox(w);
		rb.vm.$emit("update:expanded", true);
		rb.vm.$emit("update:modelValue", "hi");
		await w.vm.$nextTick();
		rb.vm.$emit("submit"); // reply resolves + draft clears; send() now awaits loadThread
		await flushPromises(); // park at the loadThread await (still pending)
		rb.vm.$emit("update:modelValue", "second thought"); // retype during the refetch
		await w.vm.$nextTick();
		resolveLoad();
		await flushPromises();
		expect(rb.props("expanded")).toBe(true);
	});

	it("does NOT collapse the switched-to ticket's box when a reply finishes after a switch", async () => {
		// The collapse sits inside the `store.thread.ticket === tName` guard, so a T1
		// reply resolving after the user moved to T2 must not collapse T2's box.
		let resolveReply;
		storeDouble.reply = vi.fn(() => new Promise((r) => (resolveReply = r)));
		storeDouble.loadThread = vi.fn(async () => {});
		storeDouble.loadTickets = vi.fn(async () => {});
		storeDouble.fingerprintOf = vi.fn(() => "x");
		const w = mountWith([]);
		const rb = replyBox(w);
		rb.vm.$emit("update:modelValue", "hi");
		await w.vm.$nextTick();
		rb.vm.$emit("submit"); // send starts on T1
		await w.vm.$nextTick();
		lastRouteState.params.ticket = "T2";
		storeDouble.thread.ticket = "T2"; // pin so open()'s C1 is skipped + the guard is deterministic
		await w.vm.$nextTick();
		rb.vm.$emit("update:expanded", true); // user opened T2's box
		await w.vm.$nextTick();
		resolveReply(true);
		await flushPromises();
		expect(rb.props("expanded")).toBe(true);
	});

	it("expands the reply box when the details panel's Reply is triggered", async () => {
		// The panel is rendered via SupportShell's #aside slot; its `open` event must
		// expand the composer. The default mountWith stub omits #aside, so use one that
		// renders it here — otherwise this wiring is entirely untested.
		storeDouble.thread.meta = { name: "T1", status: "Open" };
		const w = mount(SupportThreadPage, {
			global: {
				stubs: {
					SupportShell: {
						template: "<div><slot name='actions'/><slot/><slot name='aside'/></div>",
					},
				},
			},
		});
		const panel = w.findComponent(SupportTicketPanel);
		expect(panel.exists()).toBe(true);
		panel.vm.$emit("open");
		await w.vm.$nextTick();
		expect(w.findComponent(SupportReplyBox).props("expanded")).toBe(true);
	});

	it("resets the reply box + panel meta on a real ticket switch", async () => {
		storeDouble.thread.ticket = "T1";
		storeDouble.thread.meta = { name: "T1", status: "Open" };
		const w = mountWith([]);
		const rb = replyBox(w);
		rb.vm.$emit("update:expanded", true);
		await w.vm.$nextTick();
		expect(rb.props("expanded")).toBe(true);
		// a genuine switch (thread.ticket still T1 -> open()'s C1 branch runs)
		lastRouteState.params.ticket = "T2";
		await w.vm.$nextTick();
		expect(rb.props("expanded")).toBe(false);
		expect(storeDouble.thread.meta).toBeNull();
	});
});

describe("attachment-only Send synthesizes a reply body (fix 1)", () => {
	beforeEach(() => {
		storeDouble.thread.ticket = "T1";
		storeDouble.thread.messages = [];
		storeDouble.thread.attachments = [];
		storeDouble.thread.error = "";
		storeDouble.loadThread = vi.fn(async () => {});
		storeDouble.loadTickets = vi.fn(async () => {});
		storeDouble.fingerprintOf = () => "x";
	});

	it("calls store.reply with a non-empty body BEFORE store.uploadTo when Send fires with files but no typed text", async () => {
		// CRITICAL: canSend arms on files alone, but only the reply Communication
		// reopens a Resolved/Closed ticket and notifies the agent — media.upload
		// is a bare File attach with no Communication at all. Without the
		// synthesized body, a files-only Send skipped `if (body)` entirely and
		// never posted a reply, while still reporting "success".
		const order = [];
		storeDouble.reply = vi.fn(async (name, body) => {
			order.push(["reply", body]);
			return true;
		});
		storeDouble.uploadTo = vi.fn(async (name, files) => {
			order.push(["upload"]);
			return files;
		});

		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("files-added", [{ name: "shot.png", type: "image/png" }]);
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await flushPromises();

		expect(order[0][0]).toBe("reply");
		expect(typeof order[0][1]).toBe("string");
		expect(order[0][1].length).toBeGreaterThan(0);
		expect(order[1][0]).toBe("upload");
	});
});

describe("uploadTo returns succeeded File references, not a count (fix 2)", () => {
	beforeEach(() => {
		storeDouble.thread.ticket = "T1";
		storeDouble.thread.messages = [];
		storeDouble.thread.attachments = [];
		storeDouble.thread.error = "";
		storeDouble.loadThread = vi.fn(async () => {});
		storeDouble.loadTickets = vi.fn(async () => {});
		storeDouble.fingerprintOf = () => "x";
		storeDouble.reply = vi.fn(async () => true);
	});

	it("keeps only the failed file staged after a partial failure, and a retry re-uploads just that one", async () => {
		// media.upload creates a NEW File per call and there is no un-attach
		// endpoint — re-uploading a file that already landed would be a
		// permanent duplicate attachment. uploadTo already knows exactly which
		// file failed; settleUpload must remove only the succeeded ones.
		// Filter by NAME, not object identity: `files.value` is a Vue ref, so
		// elements read back out of it are reactive proxies of what was staged —
		// not the exact literal objects this test holds.
		storeDouble.uploadTo = vi.fn(async (name, files) =>
			files.filter((f) => f.name !== "b.png")
		);

		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("files-added", [
			{ name: "a.png", type: "image/png" },
			{ name: "b.png", type: "image/png" },
		]);
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await flushPromises();

		expect(c.props("pending")).toHaveLength(1);
		expect(c.props("pending")[0].file_name).toBe("b.png");

		storeDouble.uploadTo.mockClear();
		c.vm.$emit("submit");
		await flushPromises();

		const secondCall = storeDouble.uploadTo.mock.calls[0];
		expect(secondCall[0]).toBe("T1");
		expect(secondCall[1]).toHaveLength(1);
		expect(secondCall[1][0].name).toBe("b.png");
	});
});

describe("settleUpload full-success branch", () => {
	it("clears the staged files and revokes every preview when the whole batch uploads", async () => {
		// The shortfall branch is already pinned above; the success branch was
		// not — deleting it (e.g. reverting to the old "only clear on exact
		// count match" logic backwards) still passed every other test.
		storeDouble.thread.ticket = "T1";
		storeDouble.thread.messages = [];
		storeDouble.thread.attachments = [];
		storeDouble.thread.error = "";
		storeDouble.loadThread = vi.fn(async () => {});
		storeDouble.loadTickets = vi.fn(async () => {});
		storeDouble.fingerprintOf = () => "x";
		storeDouble.reply = vi.fn(async () => true);
		storeDouble.uploadTo = vi.fn(async (name, files) => files);

		const revoke = vi.fn();
		URL.revokeObjectURL = revoke;

		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("files-added", [
			{ name: "a.png", type: "image/png" },
			{ name: "b.png", type: "image/png" },
		]);
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await flushPromises();

		expect(c.props("pending")).toHaveLength(0);
		expect(revoke).toHaveBeenCalledTimes(2);
	});
});

describe("poll / focus / watermark subsystem (fix 3 + 4)", () => {
	async function flushMicrotasks() {
		// Fake timers don't touch the microtask queue — draining a few ticks
		// lets the chained `await`s in onMounted/open/pollSignal settle without
		// depending on @vue/test-utils' flushPromises, which is setTimeout-based
		// and would otherwise never resolve while fake timers are active.
		for (let i = 0; i < 5; i++) await Promise.resolve();
	}

	beforeEach(() => {
		storeDouble.tickets = [{ name: "T1", subject: "x", status: "Open" }];
		storeDouble.thread.ticket = "T1";
		storeDouble.thread.messages = [];
		storeDouble.thread.attachments = [];
		storeDouble.thread.error = "";
		storeDouble.loadThread = vi.fn(async () => {});
		storeDouble.loadTickets = vi.fn(async () => {});
		storeDouble.fingerprintOf = vi.fn(() => "x");
		vi.useFakeTimers();
	});

	afterEach(() => {
		vi.useRealTimers();
		Object.defineProperty(document, "hidden", { value: false, configurable: true });
	});

	async function mountAndSettle() {
		const w = mountWith([]);
		await vi.advanceTimersByTimeAsync(0);
		return w;
	}

	it("fires loadTickets on the 30s interval, and refetches the thread only when the fingerprint changed", async () => {
		const w = await mountAndSettle();
		storeDouble.loadTickets.mockClear();
		storeDouble.loadThread.mockClear();

		await vi.advanceTimersByTimeAsync(30000);
		expect(storeDouble.loadTickets).toHaveBeenCalledTimes(1);
		expect(storeDouble.loadThread).not.toHaveBeenCalled(); // fingerprint unchanged ("x")

		storeDouble.fingerprintOf = vi.fn(() => "y"); // the row changed
		await vi.advanceTimersByTimeAsync(30000);
		expect(storeDouble.loadThread).toHaveBeenCalledWith("T1", { quiet: true });
		w.unmount();
	});

	it("skips the poll entirely while document.hidden is true", async () => {
		const w = await mountAndSettle();
		storeDouble.loadTickets.mockClear();
		Object.defineProperty(document, "hidden", { value: true, configurable: true });

		await vi.advanceTimersByTimeAsync(30000);
		expect(storeDouble.loadTickets).not.toHaveBeenCalled();
		w.unmount();
	});

	it("visibilitychange triggers an unconditional refetch even when the fingerprint is unchanged", async () => {
		const w = await mountAndSettle();
		// `document` is shared across the WHOLE test file, so other mounted (and
		// not explicitly unmounted) instances may also react to this dispatch —
		// assert THIS component's effect happened via a call-count delta and the
		// expected args, not an exact global count.
		const ticketsCallsBefore = storeDouble.loadTickets.mock.calls.length;
		const threadCallsBefore = storeDouble.loadThread.mock.calls.length;
		document.dispatchEvent(new Event("visibilitychange"));
		await flushMicrotasks();

		expect(storeDouble.loadTickets.mock.calls.length).toBeGreaterThan(ticketsCallsBefore);
		expect(storeDouble.loadThread.mock.calls.length).toBeGreaterThan(threadCallsBefore);
		expect(storeDouble.loadThread).toHaveBeenCalledWith("T1", { quiet: true });
		w.unmount();
	});

	it("advances the watermark only when the refetch does not error, so a failed quiet poll doesn't stall it forever", async () => {
		storeDouble.fingerprintOf = vi.fn(() => "y"); // always reads as "changed"
		storeDouble.loadThread = vi.fn(async () => {
			storeDouble.thread.error = "boom";
		});
		const w = await mountAndSettle();
		storeDouble.loadThread.mockClear();

		await vi.advanceTimersByTimeAsync(30000);
		expect(storeDouble.loadThread).toHaveBeenCalledTimes(1);

		// lastPrint never advanced past "" (the refetch errored), so the SAME
		// fingerprint "y" must still register as "changed" on the next tick.
		await vi.advanceTimersByTimeAsync(30000);
		expect(storeDouble.loadThread).toHaveBeenCalledTimes(2);
		storeDouble.thread.error = "";
		w.unmount();
	});

	it("falls back to an unconditional quiet refetch for an out-of-list ticket (row=null), where the fingerprint can never change", async () => {
		// fingerprintOf(name) returns "" forever when ticketRow(name) is null (a
		// deep-linked ticket outside the newest 50) — `print !== lastPrint` can
		// never fire, so without the row=null fallback this poll is permanently
		// dead for exactly the ticket that most needs it (an agent reply is the
		// only way it'd ever change).
		// mountWith()/mountAndSettle() always force a truthy ticket into
		// `storeDouble.tickets`, so mount directly instead — matches the double's
		// `ticketRow: () => tickets[0] || null`.
		storeDouble.tickets = [];
		storeDouble.fingerprintOf = vi.fn(() => "");
		const w = mount(SupportThreadPage, {
			global: {
				stubs: { SupportShell: { template: "<div><slot name='actions'/><slot/></div>" } },
			},
		});
		await vi.advanceTimersByTimeAsync(0);
		storeDouble.loadThread.mockClear();

		await vi.advanceTimersByTimeAsync(30000);
		expect(storeDouble.loadThread).toHaveBeenCalledWith("T1", { quiet: true });
		w.unmount();
	});

	it("clears the interval on unmount", async () => {
		const clearSpy = vi.spyOn(global, "clearInterval");
		const w = await mountAndSettle();
		w.unmount();
		expect(clearSpy).toHaveBeenCalled();
		clearSpy.mockRestore();
	});
});

// The header pill (ChatView.vue) reads store.awaitingCount, which UserMenu's
// poll only refreshes every 60s - so a reply or a close should refresh it
// immediately too, rather than leaving the pill stale for up to a minute.
describe("refreshAwaiting after reply/close (header pill freshness)", () => {
	// beforeEach, not afterEach: earlier describe blocks in this file freely
	// reassign storeDouble.reply/closeTicket/etc without restoring them
	// afterward (the file has no top-level reset), so each test here needs a
	// known-clean slate on the way IN, not just a courtesy reset on the way
	// out.
	beforeEach(() => {
		storeDouble.closeTicket = vi.fn();
		storeDouble.reply = vi.fn(async () => true);
		storeDouble.refreshAwaiting = vi.fn(async () => {});
		storeDouble.loadThread = vi.fn();
		storeDouble.loadTickets = vi.fn();
	});

	it("refreshes the awaiting count after a successful close", async () => {
		storeDouble.closeTicket = vi.fn(async () => true);
		const w = mountWith([]);

		const resolveBtn = w
			.findAllComponents({ name: "Button" })
			.find((b) => b.props("label") === "Resolve");
		expect(resolveBtn).toBeTruthy();
		await resolveBtn.trigger("click");
		await flushPromises();

		expect(storeDouble.refreshAwaiting).toHaveBeenCalledTimes(1);
	});

	it("does not refresh the awaiting count when the close call itself fails", async () => {
		storeDouble.closeTicket = vi.fn(async () => false);
		const w = mountWith([]);

		const resolveBtn = w
			.findAllComponents({ name: "Button" })
			.find((b) => b.props("label") === "Resolve");
		await resolveBtn.trigger("click");
		await flushPromises();

		expect(storeDouble.refreshAwaiting).not.toHaveBeenCalled();
	});

	it("a rejected refreshAwaiting after close does not throw or block the thread refresh", async () => {
		storeDouble.closeTicket = vi.fn(async () => true);
		storeDouble.refreshAwaiting = vi.fn(async () => {
			throw new Error("network blip");
		});
		const w = mountWith([]);

		const resolveBtn = w
			.findAllComponents({ name: "Button" })
			.find((b) => b.props("label") === "Resolve");
		// The point of the test: a rejecting refreshAwaiting must not surface as
		// an unhandled rejection (vitest fails the whole run on one - this is
		// what the .catch() guard on that call exists to prevent) or stop the
		// rest of the close flow from completing.
		await resolveBtn.trigger("click");
		await flushPromises();

		// The rest of the close flow still ran - the rejection was contained,
		// not swallowed at the cost of everything after it.
		expect(storeDouble.loadThread).toHaveBeenCalledWith("T1", { quiet: true });
	});

	it("refreshes the awaiting count after a successful reply", async () => {
		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", "<p>thanks</p>");
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await flushPromises();

		expect(storeDouble.refreshAwaiting).toHaveBeenCalledTimes(1);
	});

	it("does not refresh the awaiting count when the reply itself fails", async () => {
		storeDouble.reply = vi.fn(async () => false);
		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", "<p>thanks</p>");
		await w.vm.$nextTick();
		c.vm.$emit("submit");
		await flushPromises();

		expect(storeDouble.refreshAwaiting).not.toHaveBeenCalled();
	});

	it("a rejected refreshAwaiting after a reply does not throw or block the thread refresh", async () => {
		storeDouble.refreshAwaiting = vi.fn(async () => {
			throw new Error("network blip");
		});
		const w = mountWith([]);
		const c = w.findComponent(SupportReplyBox);
		c.vm.$emit("update:modelValue", "<p>thanks</p>");
		await w.vm.$nextTick();

		// Same point as the close-side test above: a rejecting refreshAwaiting
		// must not surface as an unhandled rejection or stop the rest of send()
		// (the loadThread refresh below) from completing.
		c.vm.$emit("submit");
		await flushPromises();

		expect(storeDouble.loadThread).toHaveBeenCalledWith("T1");
	});
});
