<template>
	<!-- The brand mark. Single source of truth for the brand glyph so the
	     onboarding wizard, the onboarding gate poster, the chat avatars (and any
	     future setup surface) can't drift apart on a brand refresh. When the
	     tenant has uploaded a whitelabel logo we render it in place of the
	     default gradient spark.

	     `mood` turns the mark into a tiny reacting face for the moments that have
	     one: eyes that glance while a reply is being written (thinking), widen
	     while the mic is capturing (listening), a one-off smile when the answer
	     lands (happy), and heavy sleepy lids with a soft "z z z" while the agent is
	     being upgraded (upgrading). Default "star" renders exactly the resting
	     spark, so the existing call sites need no change. The face is white on the
	     same brand gradient as the spark - it never introduces a colour of its
	     own, and the whitelabel <img> branch ignores mood entirely (a tenant with
	     an uploaded logo keeps their logo during an upgrade; the maintenance
	     banner still carries the "back shortly" message). -->
	<img
		v-if="brandLogoUrl"
		class="jv-mark jv-mark-img"
		:src="brandLogoUrl"
		:style="markStyle"
		alt=""
	/>
	<span
		v-else
		class="jv-mark"
		:class="[`jv-mood-${mood}`, { 'jv-hoverpeek': hoverPeek, 'jv-peek-on': peek || autoPeek }]"
		:style="markStyle"
	>
		<svg
			class="jv-star"
			:width="Math.round(size * 0.55)"
			:height="Math.round(size * 0.55)"
			viewBox="0 0 24 24"
			fill="#fff"
		>
			<path :d="BRAND_STAR_PATH" />
		</svg>
		<span v-if="hasFace" class="jv-face" aria-hidden="true">
			<span class="jv-eyes"><i class="jv-eye"></i><i class="jv-eye"></i></span>
			<span class="jv-mouth"></span>
		</span>
		<span v-if="mood === 'upgrading'" class="jv-zzz" aria-hidden="true"
			><i>z</i><i>z</i><i>z</i></span
		>
	</span>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, ref, watch } from "vue";
import { brandLogoUrl } from "@/branding";
import { BRAND_STAR_PATH } from "@/lib/brand";

const props = defineProps({
	size: { type: Number, default: 56 },
	radius: { type: Number, default: 14 },
	/**
	 * "star"      resting spark (default, byte-identical to the old mark)
	 * "thinking"  eyes glance around  - while a reply is being written
	 * "listening" eyes widen + pulse  - while voice/mic is capturing
	 * "happy"     smile, plays once   - the moment an answer lands
	 * "upgrading" sleepy lids + z z z  - while the agent is being upgraded
	 */
	mood: {
		type: String,
		default: "star",
		validator: (v) => ["star", "thinking", "listening", "happy", "upgrading"].includes(v),
	},
	/** Sidebar/brand use: reveal a friendly blink on hover, calm otherwise. */
	hoverPeek: { type: Boolean, default: false },
	/** Externally-driven peek: show the blinking eyes while true. Lets a larger
	    surface (e.g. the whole sidebar brand card) drive the same reveal that
	    hoverPeek gives on the mark alone. */
	peek: { type: Boolean, default: false },
	/** Opt-in: while resting ("star"), blink on its own every few seconds via
	    the same peek reveal hover/hoverPeek trigger on demand — the "idle"
	    animation the mark was designed to have. Off by default: message rows
	    render dozens of marks at once and only a chosen resting surface (the
	    sidebar brand mark) should breathe unprompted. Tracks prefers-reduced-motion
	    LIVE via a matchMedia change listener (not just at mount): the timer
	    stops the moment the OS preference flips on mid-session, and resumes if
	    it flips off again, so a mid-session toggle is always honored. */
	idlePeek: { type: Boolean, default: false },
});

// The face element only exists when something can show it: an active mood, a
// hover-peek surface (where mood stays "star" but hover reveals the eyes), or
// an idle auto-peek cycle.
const hasFace = computed(
	() => props.mood !== "star" || props.hoverPeek || props.peek || autoPeek.value
);

// ---- idle auto-peek: the same friendly blink hoverPeek/peek give on demand,
// but self-triggered every IDLE_PEEK_INTERVAL_MS while nothing else is
// driving the face. Only meaningful while mood is "star" - an active mood
// already owns the face.
const IDLE_PEEK_INTERVAL_MS = 9000;
const IDLE_PEEK_HOLD_MS = 4800; // ~1.4 jvm-lookaround cycles: a visible "thinking" glance, then back to resting
const autoPeek = ref(false);
let idleTimeoutId = null;
let idleHoldTimeoutId = null;
let reducedMotionMql = null;

function stopIdlePeek() {
	if (idleTimeoutId) {
		window.clearTimeout(idleTimeoutId);
		idleTimeoutId = null;
	}
	if (idleHoldTimeoutId) {
		window.clearTimeout(idleHoldTimeoutId);
		idleHoldTimeoutId = null;
	}
	autoPeek.value = false;
}

function scheduleIdlePeek() {
	idleTimeoutId = window.setTimeout(() => {
		if (props.mood === "star") {
			autoPeek.value = true;
			idleHoldTimeoutId = window.setTimeout(() => {
				autoPeek.value = false;
			}, IDLE_PEEK_HOLD_MS);
		}
		scheduleIdlePeek();
	}, IDLE_PEEK_INTERVAL_MS);
}

// Reacts to the OS preference changing mid-session, not just its value at
// mount: reduced-motion turning on stops the timer and clears any peek in
// progress; turning back off resumes scheduling.
function handleReducedMotionChange(e) {
	if (e.matches) {
		stopIdlePeek();
	} else if (props.idlePeek) {
		scheduleIdlePeek();
	}
}

// A mood taking over the face (e.g. a reply starts streaming) mid-hold must
// not leave jv-peek-on layered on top of it - the new mood should own the
// face immediately, not after the peek's own hold timer runs out.
watch(
	() => props.mood,
	(mood) => {
		if (mood !== "star" && autoPeek.value) {
			if (idleHoldTimeoutId) {
				window.clearTimeout(idleHoldTimeoutId);
				idleHoldTimeoutId = null;
			}
			autoPeek.value = false;
		}
	}
);

onMounted(() => {
	if (!props.idlePeek) return;
	if (typeof window === "undefined" || typeof window.matchMedia !== "function") return;
	reducedMotionMql = window.matchMedia("(prefers-reduced-motion: reduce)");
	reducedMotionMql.addEventListener("change", handleReducedMotionChange);
	if (!reducedMotionMql.matches) scheduleIdlePeek();
});

onBeforeUnmount(() => {
	stopIdlePeek();
	reducedMotionMql?.removeEventListener("change", handleReducedMotionChange);
});

const markStyle = computed(() => ({
	width: `${props.size}px`,
	height: `${props.size}px`,
	borderRadius: `${props.radius}px`,
	"--jv-mark-size": `${props.size}px`,
}));
</script>

<style scoped>
.jv-mark {
	position: relative;
	display: grid;
	place-items: center;
	flex-shrink: 0;
	overflow: hidden;
	/* --brand-grad is defined on :root in main.css (theme-invariant). The literal
	   fallback keeps the mark correct if this component is ever rendered outside
	   the app's stylesheet (e.g. an isolated story or a test harness). */
	background: var(--brand-grad, linear-gradient(135deg, #6e8bff, #8b5cf6));
}
/* A tenant logo fills the same square footprint; cover keeps it edge-to-edge
   at any aspect ratio without distortion. */
.jv-mark-img {
	object-fit: cover;
	display: block;
	flex-shrink: 0;
	background: var(--surface-2, #f0f0f4);
}

/* Star and face share one centred cell; we cross-fade between them. */
.jv-star {
	grid-area: 1 / 1;
	transition: opacity 0.25s ease;
}
.jv-face {
	grid-area: 1 / 1;
	position: absolute;
	inset: 0;
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	gap: calc(var(--jv-mark-size) * 0.07);
	opacity: 0;
	transition: opacity 0.25s ease;
	transform-origin: center;
}
.jv-eyes {
	display: flex;
	align-items: center;
	justify-content: center;
	gap: calc(var(--jv-mark-size) * 0.19);
}
.jv-eye {
	width: calc(var(--jv-mark-size) * 0.135);
	height: calc(var(--jv-mark-size) * 0.2);
	background: #fff;
	border-radius: 999px;
	transform-origin: center;
}
.jv-mouth {
	display: none;
}

/* Any active mood hides the star and shows the face. Written as
   :not(.jv-mood-star) so a mood added later toggles correctly on its own,
   without having to be appended to a per-mood list here. */
.jv-mark:not(.jv-mood-star) .jv-star {
	opacity: 0;
}
.jv-mark:not(.jv-mood-star) .jv-face {
	opacity: 1;
}

/* THINKING - eyes drift up and glance side to side, with a soft blink. */
.jv-mood-thinking .jv-face {
	animation: jvm-lookaround 3.4s ease-in-out infinite;
}
.jv-mood-thinking .jv-eye {
	animation: jvm-blink 3.4s infinite;
}
@keyframes jvm-lookaround {
	0%,
	100% {
		transform: translate(-16%, -8%);
	}
	28% {
		transform: translate(-16%, -8%);
	}
	52% {
		transform: translate(18%, -4%);
	}
	70% {
		transform: translate(0, -12%) scale(0.96, 1.04);
	}
}
@keyframes jvm-blink {
	0%,
	46%,
	100% {
		transform: scaleY(1);
	}
	49%,
	52% {
		transform: scaleY(0.14);
	}
}

/* LISTENING - eyes widen and pulse, attentive. */
.jv-mood-listening .jv-face {
	animation: jvm-attend 1.9s ease-in-out infinite;
}
.jv-mood-listening .jv-eye {
	animation: jvm-tall 1.9s ease-in-out infinite;
}
@keyframes jvm-attend {
	0%,
	100% {
		transform: scale(1);
	}
	50% {
		transform: scale(1.1);
	}
}
@keyframes jvm-tall {
	0%,
	100% {
		height: calc(var(--jv-mark-size) * 0.2);
	}
	50% {
		height: calc(var(--jv-mark-size) * 0.26);
	}
}

/* HAPPY - smaller eyes + a smile, one bounce, then it holds. Plays once so a
   lingering mood prop can't leave it bouncing forever. */
.jv-mood-happy .jv-face {
	gap: calc(var(--jv-mark-size) * 0.05);
	/* Plays once, ~1.5s. ChatView's markAnswerLanded (HAPPY_HOLD_MS) clears the
	   mood after the same 1500ms, so the smile reverts to the resting star exactly
	   as it finishes; keep the two durations in sync. */
	animation: jvm-cheer 1.5s ease-in-out 1 both;
}
.jv-mood-happy .jv-eye {
	width: calc(var(--jv-mark-size) * 0.1);
	height: calc(var(--jv-mark-size) * 0.14);
}
.jv-mood-happy .jv-mouth {
	display: block;
	width: calc(var(--jv-mark-size) * 0.42);
	height: calc(var(--jv-mark-size) * 0.34);
	border: calc(var(--jv-mark-size) * 0.07) solid #fff;
	border-color: transparent transparent #fff transparent;
	border-radius: 50%;
	margin-top: calc(var(--jv-mark-size) * -0.1);
}
@keyframes jvm-cheer {
	0%,
	100% {
		transform: translateY(3%) scale(1);
	}
	50% {
		transform: translateY(-12%) scale(1.05);
	}
}

/* UPGRADING - the maintenance mood. The same white pills the other moods use,
   drooped to heavy sleepy lids that slow-blink, over a soft breath, with a faint
   "z z z" rising in the corner: the mark reads as "resting, back shortly" while
   the agent is being upgraded. Everything stays inside the mark (which clips to
   its rounded square), so nothing is cut off; a whitelabel <img> shows no face,
   and the maintenance banner carries the message there. */
.jv-mood-upgrading .jv-face {
	animation: jvm-rest-breathe 4.6s ease-in-out infinite;
}
.jv-mood-upgrading .jv-eye {
	height: calc(var(--jv-mark-size) * 0.055);
	animation: jvm-rest-lid 4.6s ease-in-out infinite;
}
.jv-mood-upgrading .jv-eye:first-child {
	transform: rotate(-13deg);
}
.jv-mood-upgrading .jv-eye:last-child {
	transform: rotate(13deg);
}
@keyframes jvm-rest-breathe {
	0%,
	100% {
		transform: scale(0.99);
	}
	50% {
		transform: scale(1.02);
	}
}
@keyframes jvm-rest-lid {
	0%,
	100% {
		height: calc(var(--jv-mark-size) * 0.055);
	}
	50% {
		height: calc(var(--jv-mark-size) * 0.022);
	}
}
/* The sleep "z z z", white on the gradient, rising and fading in the corner.
   Bounded travel so it fades before the clip edge rather than being cut. */
.jv-zzz {
	position: absolute;
	top: 9%;
	right: 8%;
	display: flex;
	align-items: flex-end;
	gap: 1px;
	line-height: 1;
	pointer-events: none;
}
.jv-zzz i {
	font-style: normal;
	font-weight: 800;
	color: #fff;
	opacity: 0;
}
.jv-zzz i:nth-child(1) {
	font-size: calc(var(--jv-mark-size) * 0.13);
	animation: jvm-zfloat 3.2s ease-out infinite;
}
.jv-zzz i:nth-child(2) {
	font-size: calc(var(--jv-mark-size) * 0.17);
	animation: jvm-zfloat 3.2s ease-out 0.6s infinite;
}
.jv-zzz i:nth-child(3) {
	font-size: calc(var(--jv-mark-size) * 0.22);
	animation: jvm-zfloat 3.2s ease-out 1.2s infinite;
}
@keyframes jvm-zfloat {
	0% {
		opacity: 0;
		transform: translateY(20%) scale(0.7);
	}
	30% {
		opacity: 0.85;
	}
	100% {
		opacity: 0;
		transform: translateY(-30%) scale(1.05);
	}
}

/* PEEK - resting star until triggered, then the same "thinking" glance the
   thinking mood uses (eyes look around, with a soft blink) rather than a quick
   one-off blink, so a resting mark is clearly, visibly alive. Triggered by
   hovering the mark itself (hoverPeek), by the `peek` prop (so a larger
   surface, e.g. the whole sidebar brand card, can drive the same reveal), or
   by `idlePeek`'s own timer toggling the same `jv-peek-on` class (see
   scheduleIdlePeek in <script>) so the mark glances on its own while resting.
   Only meaningful while mood is "star" (the face is otherwise hidden). */
.jv-hoverpeek:hover .jv-star,
.jv-peek-on .jv-star {
	opacity: 0;
}
.jv-hoverpeek:hover .jv-face,
.jv-peek-on .jv-face {
	opacity: 1;
	animation: jvm-lookaround 3.4s ease-in-out infinite;
}
.jv-hoverpeek:hover .jv-eye,
.jv-peek-on .jv-eye {
	animation: jvm-blink 3.4s ease-in-out infinite;
}

/* One calm static frame per mood, matching how JvSpinner/SetupNeuralNet handle
   the same preference: the face still communicates, it just stops moving. */
@media (prefers-reduced-motion: reduce) {
	.jv-face,
	.jv-eye,
	.jv-hoverpeek:hover .jv-eye,
	.jv-peek-on .jv-eye {
		animation: none !important;
	}
	.jv-mood-thinking .jv-eye {
		transform: translateY(-8%);
	}
	/* Upgrading: hold a calm sleeping frame - heavy lids, the z z z shown
	   statically so it still reads as resting without any motion. */
	.jv-mood-upgrading .jv-eye {
		height: calc(var(--jv-mark-size) * 0.055);
	}
	.jv-zzz i {
		/* Stop the rise/fade (an animation would otherwise override this static
		   opacity); hold the z's visible so the frame still reads as resting. */
		animation: none !important;
		opacity: 0.8;
	}
}
</style>
