<template>
	<div class="flex h-full flex-col overflow-hidden bg-surface-white">
		<!-- header: this pane stays dashboard-native; it never hands the thread to
		     the general chat surface. -->
		<div class="flex min-h-[56px] shrink-0 items-center justify-between gap-2 border-b px-4">
			<div class="flex min-w-0 flex-col gap-0.5">
				<span class="text-base font-semibold text-ink-gray-9">Describe a dashboard</span>
				<span class="text-p-sm text-ink-gray-6"
					>{{ agentName }} draws it on the canvas</span
				>
			</div>
			<div class="flex shrink-0 items-center gap-1">
				<Dropdown :options="historyOptions" placement="left">
					<Button
						variant="ghost"
						label="Dashboard chats"
						tooltip="Dashboard chats"
						icon="clock"
					/>
				</Dropdown>
				<Button
					variant="ghost"
					label="Hide chat"
					tooltip="Hide chat"
					icon="x"
					@click="emit('close')"
				/>
				<Button
					variant="ghost"
					label="New chat"
					tooltip="New dashboard chat"
					icon="plus"
					@click="newChat"
				/>
			</div>
		</div>

		<!-- transcript -->
		<div ref="scroller" class="min-h-0 flex-1 overflow-y-auto px-4 py-4">
			<div v-if="loadingTranscript && !bubbles.length" class="flex justify-center py-8">
				<JvSpinner />
			</div>

			<!-- empty state: nudge toward the natural-language flow -->
			<div
				v-else-if="!bubbles.length && !runActive"
				class="flex h-full flex-col items-center justify-center gap-3 px-2 text-center"
			>
				<FeatherIcon name="bar-chart-2" class="size-7.5 text-ink-gray-5" />
				<div class="flex flex-col items-center gap-1">
					<span class="text-base font-medium text-ink-gray-8">Describe a dashboard</span>
					<span class="text-p-sm text-ink-gray-6">
						e.g. "Monthly sales by territory with a top-customers table"
					</span>
				</div>
			</div>

			<div v-else class="flex flex-col gap-3">
				<template v-for="m in bubbles" :key="m.name">
					<!-- user: right-aligned surface-gray bubble -->
					<div v-if="m.role === 'user'" class="flex justify-end">
						<div
							class="max-w-[85%] whitespace-pre-wrap rounded-lg bg-surface-gray-2 px-3 py-2 text-base text-ink-gray-8"
						>
							{{ m.content }}
						</div>
					</div>
					<!-- assistant error: inline red note (ChatView semantics, compact).
					     A run that failed before any reply leaves an EMPTY content and
					     the reason in `error` (a rate limit, a provider outage), which
					     is what the user needs to read here. -->
					<!-- a cancelled / aged-out queued turn: muted note, not a failure -->
					<div v-else-if="m.error && m.err.code === 'cancelled'" class="flex">
						<div class="text-xs text-ink-gray-5" role="status">
							{{ m.err.headline }}
						</div>
					</div>
					<div v-else-if="m.error" class="flex">
						<div class="max-w-[95%] text-sm text-ink-red-4" role="status">
							<strong>{{ m.err.headline }}</strong>
							<p>
								{{ m.err.hint }}
								<a
									v-if="m.err.statusUrl"
									class="underline underline-offset-2"
									:href="m.err.statusUrl"
									target="_blank"
									rel="noopener noreferrer"
									>{{ m.err.statusLabel }}
									<span aria-hidden="true">&#8599;</span></a
								>
								<span v-if="m.err.hint" aria-hidden="true"> &middot; </span>
								<button
									type="button"
									class="underline underline-offset-2"
									:aria-expanded="rawOpen.has(m.name) ? 'true' : 'false'"
									:aria-controls="`dash-err-raw-${m.name}`"
									@click="toggleRaw(m.name)"
								>
									{{ rawOpen.has(m.name) ? "Hide details" : "Details" }}
								</button>
							</p>
							<pre
								v-if="rawOpen.has(m.name)"
								:id="`dash-err-raw-${m.name}`"
								class="mt-1 whitespace-pre-wrap break-words font-sans text-xs"
								>{{ m.error }}</pre
							>
						</div>
					</div>
					<!-- assistant: markdown, same renderer + prose classes as the
					     Approvals/Agents surfaces (renderMarkdown escapes HTML first) -->
					<div v-else class="flex flex-col">
						<div
							class="prose prose-sm min-w-0 max-w-none text-ink-gray-8"
							v-html="renderBubble(m.content)"
						/>
						<!-- clarifying questions the agent asked before building: the
						     SAME option cards the main chat renders. paletteVars is
						     bound here because the jv-* tokens AskCard styles with are
						     not global (SkillDetail precedent). -->
						<AskCard
							v-if="askFor === m.name && activeAsk"
							:key="m.name"
							:spec="activeAsk"
							:style="paletteVars"
							:busy="sending || runActive"
							@submit="sendText"
						/>
					</div>
				</template>

				<!-- build progress while a run is active: the same Understanding /
				     Querying data / Composing / Publishing ticks main chat's live
				     dashboard-build card shows, once real tool activity names a
				     phase; a plain three-dot pulse while it is still indeterminate
				     (a mount that joined a run already in flight, or one that
				     hasn't seen its first tool yet). -->
				<div
					v-if="runActive"
					role="status"
					aria-live="polite"
					class="flex items-center gap-3 pt-1"
				>
					<template v-if="buildTickIndex >= 0">
						<span
							v-for="(ph, i) in DASHBOARD_BUILD_PHASES"
							:key="ph.key"
							class="flex items-center gap-1.5 text-xs"
							:class="
								i < buildTickIndex
									? 'text-ink-green-3'
									: i === buildTickIndex
									? 'font-medium text-ink-blue-3'
									: 'text-ink-gray-4'
							"
						>
							<span
								class="size-1.5 rounded-full"
								:class="
									i < buildTickIndex
										? 'bg-surface-green-2'
										: i === buildTickIndex
										? 'bg-surface-blue-2 motion-safe:animate-pulse'
										: 'bg-surface-gray-3'
								"
							/>
							{{ ph.label }}
						</span>
					</template>
					<template v-else>
						<span class="flex gap-1" aria-hidden="true">
							<span
								v-for="i in 3"
								:key="i"
								class="size-1.5 rounded-full bg-surface-gray-5 motion-safe:animate-pulse"
								:style="{ animationDelay: (i - 1) * 0.18 + 's' }"
							/>
						</span>
						<span class="text-xs text-ink-gray-5">Thinking…</span>
					</template>
				</div>
			</div>
		</div>

		<!-- parked ERP-write confirmations (create/update Jarvis Dashboard…):
		     rendered in-pane so a chat-driven save never dead-ends into the
		     full chat view just to click Approve -->
		<div v-if="pendingCards.length" class="flex shrink-0 flex-col gap-2 border-t px-4 py-3">
			<div
				v-for="pa in pendingCards"
				:key="pa.token"
				class="flex flex-col gap-2 rounded-md p-3 ring-1 ring-outline-gray-modals"
			>
				<!-- human headline (+ detail line from the dry-run preview), never
				     the raw "create_doc doctype=…" tool string -->
				<div class="flex min-w-0 flex-col gap-0.5">
					<span class="text-sm font-medium text-ink-gray-8">{{ cardTitle(pa) }}</span>
					<span v-if="cardMeta(pa)" class="text-xs text-ink-gray-6">{{
						cardMeta(pa)
					}}</span>
				</div>
				<div class="flex items-center gap-2">
					<Button
						variant="solid"
						label="Approve"
						:loading="pa.busy"
						@click="approve(pa)"
					/>
					<Button
						variant="ghost"
						label="Dismiss"
						:disabled="pa.busy"
						@click="dismiss(pa)"
					/>
				</div>
			</div>
		</div>

		<!-- composer: autosizing textarea + voice + send.
		     A RAW textarea with v-model, per Composer.vue's documented pattern:
		     v-model (not :value + a manual emit) so Vue's own vModelText
		     directive keeps handling IME composition. And the box is NEVER
		     disabled: a focused, dirty textarea that is programmatically
		     disabled gets blurred by the browser, which fires `change` — the
		     frappe-ui Textarea this used to be listens on `change` too and
		     re-emitted the PRE-CLEAR value, restoring the message we had just
		     sent. Only the send button and send() are gated on `sending` /
		     `runActive` — repeat Enter/click while a turn is still running (even
		     after the POST that started it has long since resolved) must not fire
		     a second turn for the same conversation. -->
		<div class="shrink-0 border-t px-4 py-3">
			<textarea
				ref="box"
				v-model="draft"
				rows="2"
				placeholder="Describe the dashboard…"
				class="block w-full resize-none rounded border border-transparent bg-surface-gray-2 px-2 py-1.5 text-base text-ink-gray-8 transition-colors placeholder-ink-gray-4 hover:border-outline-gray-modals hover:bg-surface-gray-3 focus:border-outline-gray-4 focus:bg-surface-white focus:shadow-sm focus:outline-none focus:ring-0 focus-visible:ring-2 focus-visible:ring-outline-gray-3"
				@keydown="onKeydown"
				@input="autoGrow"
			/>
			<!-- Send stays pinned bottom-right; the controls wrap on the left in
			     this narrow, user-resizable pane. The picker is the shared main-chat
			     component: align="start" + compact keep its menu and effort flyout
			     inside the pane's overflow-hidden edge instead of clipping. -->
			<div class="mt-2 flex items-end justify-between gap-2" :style="paletteVars">
				<div class="flex min-w-0 flex-1 flex-wrap items-center gap-1.5">
					<!-- the same context ring main chat wears (ContextRing, #1136),
					     left of the model pill exactly as there, fed by the same
					     get_conversation_context payload. -->
					<ContextRing
						:context="contextInfo"
						:compacting="compacting"
						:compacted="compactedChip"
						@compact="openCompactDialog()"
					/>
					<UsagePill :usage="myUsage" />
					<ModelEffortPicker
						:model-override="modelOverride"
						:default-model="chatUi.llm_model || ''"
						:thinking-override="thinkingOverride"
						:thinking-levels="thinkingLevels"
						:models-by-provider="modelsByProvider"
						:show-providers="showProviders"
						:can-add-provider="canConnectModel"
						align="start"
						compact
						@select-model="selectModel"
						@select-thinking="selectThinking"
						@add-provider="goConnectModel"
					/>
					<VoiceRecorder v-if="caps.stt_enabled" compact @transcript="onTranscript" />
					<!-- Voice not set up is an ACTIONABLE gap, so show it faded and say so
					     rather than vanishing; deliberately off / a transient error stay
					     hidden (see voice.stt_state). -->
					<button
						v-else-if="caps.stt_state === 'unconfigured'"
						class="flex size-7 items-center justify-center rounded text-ink-gray-4 opacity-55"
						style="cursor: default"
						aria-disabled="true"
						title="Voice input is not set up on this workspace"
						aria-label="Voice input is not set up on this workspace"
						@click="
							toast.info(
								`Voice input isn't set up on this workspace yet. Ask your administrator.`
							)
						"
					>
						<FeatherIcon name="mic" class="size-4" />
					</button>
					<!-- explicit data-mode: Auto leaves it to the opening interview
					     (the agent asks before the first build); Static bakes the
					     numbers in (one-time report); Live declares view-time sources.
					     TabButtons = real radio-group semantics + the raised-chip look,
					     so the active option isn't a second solid next to Send. -->
					<!-- one wrap unit, so the label never strands on the row above its chips -->
					<span class="inline-flex items-center gap-1.5">
						<span
							class="ml-1 text-xs text-ink-gray-5"
							title="How this dashboard gets its data. Auto: I'll ask you before the first build."
						>
							Data
						</span>
						<TabButtons
							:buttons="DATA_MODES"
							:model-value="dataMode"
							@update:model-value="(v) => (dataMode = v || 'auto')"
						/>
					</span>
				</div>
				<Button
					class="shrink-0"
					variant="solid"
					label="Send"
					:disabled="!draft.trim() || sending || runActive"
					:loading="sending"
					@click="send()"
				/>
			</div>
		</div>
		<CompactDialog
			v-model="compactDialogOpen"
			:busy-reason="compactBusyReason"
			:submitting="compactSubmitting"
			:initial-hint="compactHintSeed"
			@confirm="runCompact"
		/>
	</div>
</template>

<script setup>
// DashboardChatPane - the embedded assistant chat on the Dashboards builder
// tab (bottom pane). Dashboards is the only feature that keeps an embedded chat
// pane; the Triggers one it was originally forked from has been removed in
// favour of managing triggers from the list UI. State machine:
//   conversation id  → useStorage("jarvis-dash-conv-<user>") - persisted per
//                      user; "" means no conversation yet.
//   first send       → send_message(conversation:"", context {"page":"dashboards"})
//                      creates/focuses one server-side; the returned
//                      conversation_id is stored.
//   mount w/ stored  → load its transcript; a 404 (deleted chat) silently
//                      clears storage and starts fresh.
//   realtime         → "jarvis:event" frames for OUR conversation schedule a
//                      debounced (300ms) get_conversation refetch; run:start
//                      raises run-active (and starts tracking tool:start/end
//                      for the phase ticks below), run:end / run:error clear
//                      it. kind==="canvas" frames for our conversation bubble
//                      up as emit("canvas", {message_id, items}) - the page
//                      pulls the html artifact onto the canvas pane.
//                      kind==="dashboard" frames (the new save_dashboard tool,
//                      jarvis#884 - dashboards no longer land as a canvas
//                      artifact) bubble up as emit("dashboard", {name}) - the
//                      page loads that saved row as the current document.
//   no socket        → (?nosocket / headless QA) a bounded refetch ladder after
//                      each send stands in for the realtime frames.
import { ref, computed, watch, nextTick, inject, onMounted, onBeforeUnmount } from "vue";
import { useStorage } from "@vueuse/core";
import { Button, Dropdown, FeatherIcon, TabButtons, toast } from "frappe-ui";
import JvSpinner from "@/components/JvSpinner.vue";
import VoiceRecorder from "@/components/VoiceRecorder.vue";
import AskCard from "@/components/chat/AskCard.vue";
import CompactDialog from "@/components/chat/CompactDialog.vue";
import ContextRing from "@/components/chat/ContextRing.vue";
import UsagePill from "@/components/chat/UsagePill.vue";
import { myUsage, loadMyUsage, takeUsage } from "@/stores/usage";
import ModelEffortPicker from "@/components/chat/ModelEffortPicker.vue";
import { renderMarkdown } from "@/markdown";
import { parseAsk } from "@/lib/chatAsk";
import { builderCanvasFrame } from "@/lib/dashboardRestore";
import { gotoFiredKey, parseFiredStamp, encodeFiredStamp } from "@/lib/chatGoto";
import {
	DASHBOARD_BUILD_PHASES,
	dashboardBuildPhase,
	phaseTickIndex,
	restoreDashboardRunState,
} from "@/lib/dashboardBuildCard";
import { useJarvisTheme } from "@/theme";
import { useShellStore } from "@/stores/shell";
import { session } from "@/data/session";
import {
	sendDashboardChat,
	getDashboardConversation,
	listDashboardConversations,
} from "@/api/dashboards";
import {
	listPendingConfirmations,
	confirmTool,
	dismissTool,
	getChatUiSettings,
	setConversationModel,
	setConversationThinking,
	getConversationContext,
	compactConversation,
} from "@/api";
import { agentName } from "@/branding";
import { errHtml, turnErrorInfo } from "@/lib/errors";
import { compactFailureCopy } from "@/lib/compact";
import { sendRejectionCopy } from "@/lib/sendRejectionCopy";

// get_dashboards_caps payload (creatable_scopes/manageable_roles feed the save
// dialog; stt_enabled - when the backend sends it - gates the mic)
const props = defineProps({
	caps: { type: Object, default: () => ({}) },
	// the selected theme key (lowercase) — forwarded in the send context so the
	// agent designs FOR that theme (the skill injects its token+recipe cheatsheet).
	theme: { type: String, default: "jarvis" },
	// when revising a saved dashboard, its name — forwarded in the send context
	// so the agent knows which dashboard it is iterating on ("" = a new one).
	editingName: { type: String, default: "" },
});

// canvas: {message_id, items[, restore]} for a canvas frame on our conversation
// (restore = replayed from the loaded transcript, not a live socket frame);
// activity: a run ended (the page may refresh lists); reset: New chat clicked;
// dashboard: {name} - the agent's save_dashboard tool saved a row this turn
// (jarvis#884), so the page can load it as the current document.
const emit = defineEmits([
	"canvas",
	"activity",
	"reset",
	"dashboard",
	"close",
	"select-conversation",
]);

const socket = inject("$socket", null);
const shell = useShellStore();
// AskCard styles with the jv-* tokens, which this frappe-ui page does not bind.
const { paletteVars } = useJarvisTheme();

// ── conversation persistence (per user, ChatComposer's namespacing idiom) ────
const conversation = useStorage(`jarvis-dash-conv-${session.user || "anon"}`, "");
// The message whose canvas the BUILDER last rendered - the page stamps it, this
// pane replays exactly that one. Scanning the transcript for "the newest html"
// could hand the builder an unrelated legacy/promoted artifact and arm Save
// over it.
const canvasMsg = useStorage(`jarvis-dash-canvasmsg-${session.user || "anon"}`, "");

// Dashboard conversations are a separate product namespace: they appear only
// in this menu, never in the general chat sidebar or command palette.
const dashboardChats = ref([]);
const historyLoading = ref(false);
const historyOptions = computed(() => {
	if (historyLoading.value && !dashboardChats.value.length)
		return [{ label: "Loading dashboard chats…", disabled: true }];
	if (!dashboardChats.value.length)
		return [{ label: "No previous dashboard chats", disabled: true }];
	return dashboardChats.value.map((row) => ({
		label: historyLabel(row),
		icon: row.name === conversation.value ? "check" : "message-square",
		onClick: () => {
			if (row.name !== conversation.value) emit("select-conversation", row);
		},
	}));
});

// A thread the agent never got to title still carries the server's "New
// chat" placeholder, which in a history MENU reads as the action next to it.
function historyLabel(row) {
	const title = String(row.title || "").trim();
	return (
		row.dashboard_title || (title && title !== "New chat" ? title : "Untitled dashboard chat")
	);
}

async function loadDashboardChats() {
	historyLoading.value = true;
	try {
		const data = (await listDashboardConversations()) || {};
		dashboardChats.value = Array.isArray(data.rows) ? data.rows : [];
	} catch {
		// History is a convenience; transcript/send remain available on a blip.
	} finally {
		historyLoading.value = false;
	}
}

// Same model catalogue and per-conversation overrides as main chat. Keeping
// the picker component shared makes its interaction/design identical; the
// builder owns only the compact catalogue projection and persistence calls.
const chatUi = ref({});
const modelOverride = ref("");
const thinkingOverride = ref("");
// Context meter + compaction: the same state machine main chat runs for its
// ContextRing (ChatView loadContext / runCompact), scoped to this pane's
// conversation. Dashboard threads are ordinary sessions to
// get_conversation_context / compact_conversation, so nothing is dashboard-only.
const contextInfo = ref(null); // get_conversation_context payload for the open thread
const compacting = ref(false); // a compaction we started (or one the runtime is doing mid-turn)
const compactedChip = ref(false); // ring "done" state until the next run:end
const compactDialogOpen = ref(false);
const compactSubmitting = ref(false);
const compactHintSeed = ref("");
const compactBusyReason = computed(() => {
	if (compacting.value) return "Already compacting this chat";
	if (sending.value || runActive.value) return "A reply is in progress, try again in a moment";
	return "";
});

// Best-effort meter refresh. A not-yet-measured payload (fresh:false, e.g.
// right after context:compacted) must not blank the last fresh snapshot, and a
// slow response for a thread the user has since left must not stamp its state
// onto the one now on screen. `applyCompacting` is the authoritative
// conversation-open read that may CLEAR the lock; elsewhere a fetch may only
// turn it on (run:end / run:error / context:* are the other clearers).
async function loadContext({ applyCompacting = false } = {}) {
	const id = conversation.value;
	if (!id) {
		contextInfo.value = null;
		return;
	}
	try {
		const c = await getConversationContext(id);
		takeUsage(c);
		if (conversation.value !== id) return;
		if (c && c.fresh) contextInfo.value = c;
		if (applyCompacting) compacting.value = !!(c && c.compacting);
		else if (c && c.compacting) compacting.value = true;
	} catch {
		/* meter is best-effort */
	}
}

function openCompactDialog(seed = "") {
	compactHintSeed.value = seed;
	compactDialogOpen.value = true;
}

async function runCompact(hint) {
	if (!conversation.value) return;
	compactSubmitting.value = true;
	try {
		const res = await compactConversation(conversation.value, hint);
		if (!res || !res.ok) {
			toast.error(compactFailureCopy(res && res.reason));
			return;
		}
		compacting.value = true;
		compactedChip.value = false;
		compactHintSeed.value = hint || "";
		compactDialogOpen.value = false;
	} catch (e) {
		// frappe-ui toast renders `message` via v-html: feed it the escaped
		// errHtml, never the plain-text errMessage (lib/noInlineErrorFormatter guard).
		toast.error(errHtml(e));
	} finally {
		compactSubmitting.value = false;
	}
}
const thinkingLevels = computed(() => chatUi.value.thinking_levels || ["low", "medium", "high"]);
const showProviders = computed(() => !!chatUi.value.multi_provider);
const pickableModels = computed(() => {
	const pool = chatUi.value.pool_models || [];
	if (pool.length) {
		const seen = new Set();
		const rows = [];
		for (const row of pool) {
			const key = `${row.provider}/${row.model}`;
			if (seen.has(key)) continue;
			seen.add(key);
			rows.push(row);
		}
		for (const row of pool) {
			for (const extra of (chatUi.value.catalog_models || {})[row.provider] || []) {
				const key = `${row.provider}/${extra.model}`;
				if (seen.has(key)) continue;
				seen.add(key);
				rows.push({ ...extra, provider: row.provider, tier: "", extra: true });
			}
		}
		return rows;
	}
	return (chatUi.value.subscription_models?.[chatUi.value.llm_provider] || []).map((model) => ({
		provider: chatUi.value.llm_provider || "",
		model,
		tier: "",
	}));
});
const modelsByProvider = computed(() => {
	const groups = new Map();
	for (const row of pickableModels.value) {
		const provider = row.provider || chatUi.value.llm_provider || "default";
		if (!groups.has(provider)) groups.set(provider, []);
		groups.get(provider).push(row);
	}
	return [...groups.entries()].map(([provider, models]) => ({ provider, models }));
});
const canConnectModel =
	typeof window !== "undefined" && !!(window.is_jarvis_admin || window.is_system_manager);

async function selectModel(model) {
	const previous = modelOverride.value;
	modelOverride.value = model;
	if (!conversation.value) return;
	try {
		const result = await setConversationModel(conversation.value, model);
		if (result && result.ok === false)
			throw new Error(result.reason || "Model change rejected");
	} catch {
		modelOverride.value = previous;
		toast.error("Couldn't change the model for this dashboard chat.");
	}
}

async function selectThinking(level) {
	const previous = thinkingOverride.value;
	thinkingOverride.value = level;
	if (!conversation.value) return;
	try {
		const result = await setConversationThinking(conversation.value, level);
		if (result && result.ok === false)
			throw new Error(result.reason || "Effort change rejected");
	} catch {
		thinkingOverride.value = previous;
		toast.error("Couldn't change the effort for this dashboard chat.");
	}
}

function goConnectModel() {
	shell.openSettings("aimodels");
}

function resetRuntimeControls() {
	modelOverride.value = "";
	thinkingOverride.value = "";
	contextInfo.value = null;
	compacting.value = false;
	compactedChip.value = false;
	compactHintSeed.value = "";
}

// ── transcript ────────────────────────────────────────────────────────────────
const messages = ref([]);
const loadingTranscript = ref(false);
const scroller = ref(null);

// user/assistant rows with visible content only (tool rows and internal
// chatter stay out of this compact pane)
// An errored assistant row usually has NO content (the run died before its
// first token), so it must pass on `error` alone or the failure is invisible
// and the composer just silently unlocks.
// { [message_id]: code } from a live run:error event, so this pane names a
// failure the same way ChatView does for the same event. Not persisted: a
// reload has only the row's error text and reclassifies from that.
const errorMeta = ref({});
// Failed bubbles whose raw error text is expanded ("Details" in the note).
const rawOpen = ref(new Set());
function toggleRaw(name) {
	const next = new Set(rawOpen.value);
	next.has(name) ? next.delete(name) : next.add(name);
	rawOpen.value = next;
}
function errorNote(m) {
	return turnErrorInfo(m.error, errorMeta.value[m.name] || "", { provider: m.provider });
}
// `err` is classified once here, not per template read (five reads per bubble).
const bubbles = computed(() =>
	messages.value
		.filter(
			(m) =>
				(m.role === "user" || m.role === "assistant") &&
				(String(m.content || "").trim() || (m.role === "assistant" && m.error))
		)
		.map((m) => ({ ...m, err: m.error ? errorNote(m) : null }))
);

// ChatView's stripBlocks, minimal subset: internal fenced blocks (actions,
// confirms, cards…) never render as raw fences in the pane. `jarvis-ask` is
// stripped from the PROSE here too, but unlike the others it is not discarded:
// <AskCard> renders it below the bubble (see activeAsk), so the clarifying
// questions the agent asks before building are answerable in this pane.
function stripBlocks(text) {
	return (text || "")
		.replace(/```jarvis-action[ \t]*\n[\s\S]*?```/g, "")
		.replace(/```confirm[ \t]*\n[\s\S]*?```/g, "")
		.replace(/```jarvis-ask[ \t]*\n[\s\S]*?```/g, "")
		.replace(/```jarvis-cards[ \t]*\n[\s\S]*?```/g, "")
		.replace(/```jarvis-skill[ \t]*\n[\s\S]*?```/g, "")
		.replace(/```jarvis-macro[ \t]*\n[\s\S]*?```/g, "")
		.replace(/```jarvis-chart[ \t]*\n[\s\S]*?```/g, "")
		.replace(/\n{3,}/g, "\n\n")
		.trim();
}
function renderBubble(text) {
	return renderMarkdown(stripBlocks(text));
}

// ── clarifying questions (ChatView's rule: the card lives on the LAST
// assistant message only, so a stale ask from three turns ago isn't answerable)
const lastAssistant = computed(() => {
	const rows = bubbles.value;
	for (let i = rows.length - 1; i >= 0; i--) {
		if (rows[i].role === "assistant" && !rows[i].error) return rows[i];
	}
	return null;
});
const activeAsk = computed(() =>
	lastAssistant.value ? parseAsk(lastAssistant.value.content) : null
);
const askFor = computed(() => (activeAsk.value ? lastAssistant.value.name : null));

function scrollBottom() {
	const el = scroller.value;
	if (el) el.scrollTop = el.scrollHeight;
}

function isGone(e) {
	return !!(
		e &&
		(e.status === 404 ||
			e.exc_type === "DoesNotExistError" ||
			e.status === 403 ||
			e.exc_type === "PermissionError")
	);
}

// monotonic request id - stale refetches dropped (useListPage idiom)
let loadReq = 0;
async function loadTranscript({ initial = false } = {}) {
	const id = ++loadReq;
	if (!conversation.value) return;
	if (initial) loadingTranscript.value = true;
	try {
		const d = (await getDashboardConversation(conversation.value)) || {};
		if (id !== loadReq) return;
		messages.value = d.messages || [];
		modelOverride.value = d.conversation?.model_override || "";
		thinkingOverride.value = d.conversation?.thinking_override || "";
		loadContext({ applyCompacting: initial });
		// Reconstruct progress after a reload (and during the no-socket polling
		// fallback). A normal realtime-driven transcript refresh must not overwrite
		// the more precise live tool:start/tool:end state with durable receipts that
		// naturally lag those events.
		if (initial || !socket) {
			const restoredRun = restoreDashboardRunState(messages.value);
			runActive.value = restoredRun.active;
			activeTools.value = restoredRun.tools;
			waitingFirstTool.value = restoredRun.waiting;
			if (initial && restoredRun.active && !socket) startNoSocketLadder();
		}
		// Navigating away unmounts the builder and drops its canvas html, but the
		// transcript we just reloaded still carries every artifact the agent drew
		// (get_conversation returns each message's parsed `canvas` list). Replay
		// the one the BUILDER last rendered so coming back is lossless — the
		// page ignores it when a canvas is already on screen.
		const frame = builderCanvasFrame(messages.value, canvasMsg.value);
		if (frame) emit("canvas", { ...frame, restore: true });
		nextTick(scrollBottom);
	} catch (e) {
		if (id !== loadReq) return;
		if (isGone(e)) {
			// the stored conversation was deleted (or reassigned) - start fresh
			conversation.value = "";
			messages.value = [];
			runActive.value = false;
		}
		// transient errors keep the last-good transcript; the next frame retries
	} finally {
		if (id === loadReq) loadingTranscript.value = false;
	}
}

// debounced refetch driven by realtime frames
let refetchTimer = null;
function scheduleRefetch() {
	clearTimeout(refetchTimer);
	refetchTimer = setTimeout(() => {
		loadTranscript();
		refreshPending();
	}, 300);
}

// ── parked confirmations (gated ERP writes park for human approval) ──────────
const pendingCards = ref([]);

async function refreshPending() {
	if (!conversation.value) {
		pendingCards.value = [];
		return;
	}
	try {
		const env = await listPendingConfirmations(conversation.value);
		if (env && env.ok === false) return;
		const items = (env && env.data && env.data.pending) || [];
		// keep in-flight busy flags across refreshes
		const busy = new Set(pendingCards.value.filter((c) => c.busy).map((c) => c.token));
		pendingCards.value = items.map((it) => ({ ...it, busy: busy.has(it.token) }));
	} catch {
		// transient - the next frame retries
	}
}

function removeCard(token) {
	pendingCards.value = pendingCards.value.filter((c) => c.token !== token);
}

function confirmationStorageUnavailable(response) {
	const type = response && response.error && response.error.type;
	return type === "ConfirmationUnavailableError" || type === "ConfirmationOutcomeUnknownError";
}

// ── pending-card copy ─────────────────────────────────────────────────────────
// A card only carries what list_pending_confirmations returns (token, tool,
// preview, summary, conversation, run_id). Rich path: a sandboxed dry-run
// preview (preview.would = the doc exactly as it would save) names the
// dashboard and its scope. Fallback: clean the _describe_call line
// ("create_doc doctype=…" → "Create a …") so the raw tool string never shows.
const CARD_VERBS = {
	create_doc: "Create",
	update_doc: "Update",
	delete_doc: "Delete",
	submit_doc: "Submit",
	cancel_doc: "Cancel",
};
const SCOPE_LABELS = { User: "Private", Role: "Shared with a role", Org: "Everyone" };
function previewDoc(pa) {
	const w = pa && pa.preview && pa.preview.would;
	return w && typeof w === "object" && !Array.isArray(w) ? w : null;
}
// _describe_call joins "key=value" pairs with spaces and values may hold
// spaces ("Jarvis Dashboard") - a value runs until the next key or the end.
// Anchored on a word boundary so "name=" never matches inside "docname=".
function summaryArg(s, key) {
	const m = new RegExp("(?:^|\\s)" + key + "=(.*?)(?=\\s+[a-z_]+=|$)").exec(s || "");
	return m ? m[1].trim() : "";
}
function cardTitle(pa) {
	const verb = CARD_VERBS[pa.tool];
	const doc = previewDoc(pa);
	if (doc && doc.doctype === "Jarvis Dashboard") {
		return `${verb || "Save"} dashboard: ${doc.dashboard_title || doc.name || "(unnamed)"}`;
	}
	if (doc && doc.doctype && verb) {
		const name = verb === "Create" ? "" : doc.name || "";
		return `${verb} ${doc.doctype}${name ? " · " + name : ""}`;
	}
	const raw = pa.summary || (pa.preview && pa.preview.summary) || "";
	const m = /^(create|update|delete|submit|cancel)_doc\b/.exec(raw);
	if (m) {
		const v = CARD_VERBS[m[1] + "_doc"];
		const dt = summaryArg(raw, "doctype");
		const nm = summaryArg(raw, "name") || summaryArg(raw, "docname");
		if (dt === "Jarvis Dashboard") return `${v} a dashboard${nm ? ": " + nm : ""}`;
		if (dt) return `${v} ${dt}${nm ? " · " + nm : ""}`;
	}
	return raw || "Confirm this action";
}
function cardMeta(pa) {
	const doc = previewDoc(pa);
	if (!doc || doc.doctype !== "Jarvis Dashboard") return "";
	const scope =
		doc.scope === "Role" && doc.target_role
			? `Shared with ${doc.target_role}`
			: SCOPE_LABELS[doc.scope] || "";
	return [doc.dashboard_type, scope].filter(Boolean).join(" · ");
}

async function approve(pa) {
	pa.busy = true;
	let keepCard = false;
	try {
		const r = await confirmTool(pa.token, conversation.value);
		if (r && r.ok === false) {
			keepCard = confirmationStorageUnavailable(r);
			toast.error(
				keepCard
					? r.error.message
					: "Couldn't confirm. It may have expired. Ask again in the chat."
			);
		}
	} catch (e) {
		keepCard = true;
		toast.error(errHtml(e));
	} finally {
		if (keepCard) pa.busy = false;
		else removeCard(pa.token);
		// the parked run resumes server-side after a confirm: refresh both the
		// transcript (receipt chip) and anything list-shaped upstream
		scheduleRefetch();
		emit("activity");
	}
}

async function dismiss(pa) {
	pa.busy = true;
	let keepCard = false;
	try {
		const r = await dismissTool(pa.token, conversation.value);
		if (r && r.ok === false) {
			keepCard = confirmationStorageUnavailable(r);
			toast.error((r.error && r.error.message) || "Could not discard this confirmation.");
		}
	} catch (e) {
		keepCard = true;
		toast.error(errHtml(e));
	} finally {
		if (keepCard) pa.busy = false;
		else removeCard(pa.token);
		scheduleRefetch();
	}
}

// ── run state + composer ──────────────────────────────────────────────────────
const runActive = ref(false);
const sending = ref(false);
const draft = ref("");
const box = ref(null);

// ── build phase ticks (issue #884) ───────────────────────────────────────────
// Same real signals ChatView keeps for its own "Working on it…" line and the
// live dashboard-build card: tool:start/tool:end for OUR conversation ->
// activeTools, and whether the run has started but not yet shown its first
// tool. dashboardBuildPhase never actually reads statusPhase (only whether a
// tool is running, has run, or nothing has happened yet), so it is passed
// null here - this pane has no equivalent of ChatView's "analyzing" text.
const activeTools = ref([]); // {id, name, status}[] for the run in progress
const waitingFirstTool = ref(false); // true from run:start until the first tool:start
const buildPhaseKey = computed(() =>
	dashboardBuildPhase({
		activeTools: activeTools.value,
		statusPhase: null,
		waiting: waitingFirstTool.value,
	})
);
const buildTickIndex = computed(() => phaseTickIndex(buildPhaseKey.value));

// Explicit data-mode toggle (goal requirement): "auto" = one of the questions
// the agent asks before the first build (it no longer guesses from wording),
// "static" = baked one-time report, "live" = declared view-time sources.
// Persisted per user so the choice survives page hops. ("auto" rather than ""
// so reka-ui's RadioGroup has a real value to select.) The API wrapper only
// forwards static/live; auto sends no data_mode.
const DATA_MODES = [
	{ label: "Auto", value: "auto" },
	{ label: "Static", value: "static" },
	{ label: "Live", value: "live" },
];
const dataMode = useStorage(`jarvis-dash-datamode-${session.user || "anon"}`, "auto");

function autoGrow() {
	const ta = box.value;
	if (!ta) return;
	ta.style.height = "auto";
	ta.style.height = Math.min(ta.scrollHeight, 180) + "px";
}
// Programmatic changes (the send that clears the box, dictation, the save
// dialog's hand-off) only reach the DOM on the next flush — flush:"post" so the
// textarea's value is already written when we measure scrollHeight. Typed input
// grows synchronously in the @input handler so the box never lags the caret.
watch(draft, autoGrow, { flush: "post" });

function onKeydown(e) {
	// An Enter that CONFIRMS an IME candidate (Japanese/Chinese/Korean) belongs
	// to the composition, not to us - sending on it posts the half-converted
	// reading. keyCode 229 is the pre-`isComposing` browsers' version of the
	// same signal.
	if (e.isComposing || e.keyCode === 229) return;
	// Enter sends, Shift+Enter keeps the newline
	if (e.key === "Enter" && !e.shiftKey) {
		e.preventDefault();
		send();
	}
}

function onTranscript(text) {
	// dictation appends to any typed draft (ChatComposer precedent)
	const cur = draft.value;
	draft.value = cur.trim() ? cur.replace(/\s+$/, "") + " " + text : text;
}

// send() can be handed a DIFFERENT conversation than the one it posted to (the
// stored one was deleted or reassigned server-side, so send_message opened a
// fresh one). That repoint is OURS: the run it just started is the one on
// screen, so the follow watcher below must not tear its Thinking indicator down.
let ownRepoint = false;

// jarvis#912: the fired stamp's conversation slot (see lib/chatGoto.js) is
// written here, the one place a send() call learns which conversation a
// ```jarvis-goto message's hand-off actually landed on - fresh or repointed.
// `messageId` comes from sendText()'s caller; a message-less send (the
// ordinary composer, AskCard answers, the save dialog's "fix in chat") passes
// none and this is a no-op.
function recordGotoConversation(messageId, conv) {
	if (!messageId || !conv) return;
	const key = gotoFiredKey(messageId);
	const stamp = parseFiredStamp(localStorage.getItem(key));
	localStorage.setItem(key, encodeFiredStamp(stamp ? stamp.t : Date.now(), conv));
}

// jarvis#912 round 2: undo the provisional claim gotoDashboards (ChatView.vue)
// writes before a goto-seeded send() ever starts. A send that fails never
// reaches recordGotoConversation above, so without this the claim would sit
// there un-resolved - within its freshness window (claimGotoFire) that just
// reads as "still in flight" and self-heals, but permanently blocking a retry
// is not worth waiting out a window for when the failure is known right here.
function forgetGotoClaim(messageId) {
	if (messageId) localStorage.removeItem(gotoFiredKey(messageId));
}

async function send(gotoMessageId = "") {
	const text = draft.value.trim();
	if (!text || sending.value || runActive.value) return;
	sending.value = true;
	draft.value = "";
	// optimistic user bubble - reconciled by the next transcript refetch
	const tmpName = `tmp-${Date.now()}`;
	messages.value = [...messages.value, { name: tmpName, role: "user", content: text }];
	nextTick(scrollBottom);
	try {
		const r =
			(await sendDashboardChat(
				conversation.value,
				text,
				dataMode.value,
				props.editingName,
				props.theme,
				modelOverride.value,
				thinkingOverride.value
			)) || {};
		if (r.ok === false) {
			// rejected (single-flight guard / usage cap) - nothing persisted
			messages.value = messages.value.filter((m) => m.name !== tmpName);
			if (!draft.value) draft.value = text;
			forgetGotoClaim(gotoMessageId);
			const { message, type } = sendRejectionCopy(r.reason, agentName, r);
			(toast[type] || toast.error)(message);
			return;
		}
		if (r.conversation_id && r.conversation_id !== conversation.value) {
			ownRepoint = true;
			conversation.value = r.conversation_id;
		}
		loadDashboardChats();
		recordGotoConversation(gotoMessageId, r.conversation_id || conversation.value);
		runActive.value = true;
		// This send's own optimistic start - a run:start frame for the same run
		// arrives moments later and does the same reset, but the ticks should
		// read "Understanding" from the instant Send is clicked, not lag behind
		// the socket round trip.
		activeTools.value = [];
		waitingFirstTool.value = true;
		nextTick(scrollBottom);
		if (!socket) startNoSocketLadder();
	} catch (e) {
		messages.value = messages.value.filter((m) => m.name !== tmpName);
		if (!draft.value) draft.value = text;
		forgetGotoClaim(gotoMessageId);
		toast.error(errHtml(e));
	} finally {
		sending.value = false;
	}
}

// "New chat" ASKS the page rather than acting: the page owns the canvas and
// puts up the discard confirm, then calls resetChat() back through the exposed
// handle if the user goes ahead. Resetting here first would leave a cancelled
// confirm with an emptied chat next to a canvas that survived.
function newChat() {
	emit("reset");
}

// Drop everything that belongs to the thread on screen, leaving the pointer
// alone (the conversation watcher below re-points it). `keepRun` is for the
// one case where the thread moved but the run did not: our own send.
function clearThread({ keepRun = false } = {}) {
	loadReq++; // drop any in-flight transcript load
	messages.value = [];
	pendingCards.value = [];
	if (!keepRun) runActive.value = false;
	draft.value = "";
}

function resetChat() {
	clearThread();
	resetRuntimeControls();
	conversation.value = "";
}

// The page re-points the sticky conversation slot (opening a saved dashboard
// for editing resumes the thread that built it). Follow it, or the transcript
// on screen belongs to a different dashboard than the one the next send goes
// to. Guarded on `prev`: "" -> id is our own first send, already reconciled.
watch(conversation, (id, prev) => {
	if (!prev || id === prev) return;
	const own = ownRepoint;
	ownRepoint = false;
	clearThread({ keepRun: own });
	if (!own) resetRuntimeControls();
	if (id) {
		loadTranscript({ initial: true });
		refreshPending();
	}
});

// Post a message into this pane programmatically (the save dialog's "Ask the
// assistant to fix these" hand-off, AskCard's answer submit, a ```jarvis-goto
// hand-off's seeded first message). Ignored while a send is already in flight
// OR a turn is still running for this conversation. `gotoMessageId` names the
// goto message this send answers (jarvis#912) - see recordGotoConversation.
function sendText(text, gotoMessageId = "") {
	const t = String(text || "").trim();
	if (!t || sending.value || runActive.value) return;
	draft.value = t;
	send(gotoMessageId);
}
// Re-issue the transcript's restore frame. The page holds restores off while a
// ?chat=&canvas= promotion is in flight (an explicit deep-link owns the canvas);
// if that promotion is then declined or fails, the frame this pane already
// emitted has been dropped, and the builder would sit empty until some later
// transcript load. Declining must leave the builder as it was, so ask again.
function restoreCanvas() {
	const frame = builderCanvasFrame(messages.value, canvasMsg.value);
	if (frame) emit("canvas", { ...frame, restore: true });
}
defineExpose({ resetChat, sendText, restoreCanvas });

// ── realtime ──────────────────────────────────────────────────────────────────
function onEvent(p) {
	if (!p || !p.kind) return;
	// turn frames carry conversation_id; action:pending frames carry conversation
	const frameConv = p.conversation_id || p.conversation;
	if (!conversation.value || frameConv !== conversation.value) return;
	// the agent drew/updated an artifact this turn - the page pulls the html
	// item onto the canvas pane
	if (p.kind === "canvas") {
		emit("canvas", { message_id: p.message_id, items: p.items });
		return;
	}
	// the agent's save_dashboard tool saved a row this turn (jarvis#884) - the
	// page loads it as the current document, no discard confirm needed since
	// it is this same chat's own build
	if (p.kind === "dashboard") {
		emit("dashboard", { name: p.name });
		loadDashboardChats();
		return;
	}
	// any frame for OUR conversation refreshes the transcript (debounced)
	scheduleRefetch();
	switch (p.kind) {
		case "run:start":
			runActive.value = true;
			activeTools.value = [];
			waitingFirstTool.value = true;
			break;
		case "tool:start": {
			const id = p.tool_call_id || `${p.tool_name}-${activeTools.value.length}`;
			activeTools.value = [
				...activeTools.value,
				{ id, name: p.tool_name, status: "running" },
			];
			waitingFirstTool.value = false;
			break;
		}
		case "tool:end": {
			// tool_call_id is optional on the wire; tool:start synthesized a
			// fallback id for an id-less frame, so an id-less end must fall back
			// too (latest running entry with the same name) or the entry stays
			// "running" and the phase ticks freeze on it for the rest of the turn.
			const t =
				(p.tool_call_id && activeTools.value.find((x) => x.id === p.tool_call_id)) ||
				[...activeTools.value]
					.reverse()
					.find((x) => x.name === p.tool_name && x.status === "running");
			if (t) t.status = p.status || "completed";
			break;
		}
		case "run:end":
			runActive.value = false;
			activeTools.value = [];
			waitingFirstTool.value = false;
			// the compacted chip and the compacting lock are both scoped to one
			// turn: the next terminal clears them and refetches the meter
			compactedChip.value = false;
			compacting.value = false;
			loadContext();
			emit("activity");
			loadDashboardChats();
			break;
		case "run:error":
			runActive.value = false;
			activeTools.value = [];
			waitingFirstTool.value = false;
			compacting.value = false;
			if (p.message_id)
				errorMeta.value = { ...errorMeta.value, [p.message_id]: p.code || "" };
			loadContext();
			break;
		case "context:compacted":
			compacting.value = false;
			compactedChip.value = true;
			compactHintSeed.value = "";
			loadContext();
			break;
		case "context:compact_failed":
			compacting.value = false;
			compactHintSeed.value = "";
			toast.error(compactFailureCopy(p.reason));
			break;
	}
}

// no-socket fallback (?nosocket / headless QA): a bounded refetch ladder after
// each send; run-active clears when the reply settles (or at the ladder's end).
let ladderTimers = [];
function startNoSocketLadder() {
	ladderTimers.forEach(clearTimeout);
	ladderTimers = [3000, 8000, 15000, 30000, 60000].map((ms, i, arr) =>
		setTimeout(async () => {
			await loadTranscript();
			await refreshPending();
			const last = bubbles.value[bubbles.value.length - 1];
			const settled = last && last.role === "assistant" && !last.streaming;
			if (settled || i === arr.length - 1) {
				runActive.value = false;
				emit("activity");
			}
		}, ms)
	);
}

onMounted(() => {
	loadMyUsage();
	loadDashboardChats();
	getChatUiSettings()
		.then((data) => {
			if (data) chatUi.value = data;
		})
		.catch(() => {});
	if (conversation.value) {
		loadTranscript({ initial: true });
		refreshPending();
	}
	socket && socket.on && socket.on("jarvis:event", onEvent);
});
onBeforeUnmount(() => {
	socket && socket.off && socket.off("jarvis:event", onEvent);
	clearTimeout(refetchTimer);
	ladderTimers.forEach(clearTimeout);
});
</script>
