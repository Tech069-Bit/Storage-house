<template>
	<div class="flex h-full flex-col overflow-hidden">
		<ListPage
			:breadcrumbs="[{ label: 'Skills', route: { name: 'SkillsList' } }, { label: 'Wiki' }]"
			:columns="columns"
			:rows="rows"
			row-key="name"
			:loading="loading"
			:error="error"
			:total="total"
			:has-more="hasMore"
			:quick-filters="quickFilters"
			:filter-state="filterState"
			:filters="filters"
			:page-length="pageLength"
			:on-row-click="openRow"
			storage-key="wiki"
			:empty-state="emptyState"
			@update:filters="setFilters"
			@update:filter-clauses="setClauses"
			@request-filter-schema="requestSchema"
			@dismiss-filter-notice="dismissFilterNotice"
			@update:page-length="(v) => (pageLength = v)"
			@load-more="loadMore"
			@refresh="resetLoad"
		>
			<template #right-header>
				<!-- SM extras: knowledge language + mirror sync + health check -->
				<Popover v-if="caps.is_sm" placement="bottom-end">
					<template #target="{ togglePopover }">
						<Button
							icon="settings"
							:tooltip="'Wiki settings'"
							@click="togglePopover()"
						/>
					</template>
					<template #body>
						<div
							class="my-2 w-[320px] rounded-lg bg-surface-modal p-3 shadow-2xl ring-1 ring-black ring-opacity-5"
						>
							<!-- PanelSelect, not FormControl select: a reka SelectPortal won't open
							     inside this settings Popover (same bug fixed in the list filters). -->
							<label class="mb-1 block text-xs text-ink-gray-5"
								>Knowledge language</label
							>
							<PanelSelect
								aria-label="Knowledge language"
								:options="LANGUAGE_OPTIONS"
								:model-value="caps.knowledge_language"
								@update:modelValue="changeLanguage"
							/>
							<p class="mt-1 text-p-sm text-ink-gray-5">
								Applies org-wide: wiki pages, extracted business facts and
								learned-skill drafts. English translates non-English input;
								Original keeps the source's language.
							</p>
							<div class="mt-3 flex flex-col gap-2 border-t pt-3">
								<Button
									variant="subtle"
									label="Sync to agent now"
									iconLeft="upload-cloud"
									:loading="syncing"
									@click="confirmSync"
								/>
								<!-- wiki_mirror_last_sync_status is the same internal audit
								     string every apply pipeline writes ("ok (restart via
								     admin)", "failed: fleet returned 502") and this line
								     used to print it verbatim. @/lib/syncStatus is the one
								     place that turns it into words a customer can read. -->
								<p class="text-p-sm text-ink-gray-5">
									<template v-if="caps.wiki_mirror_last_synced_at">
										Last synced {{ timeAgo(caps.wiki_mirror_last_synced_at)
										}}<span v-if="wikiSyncLabel"> - {{ wikiSyncLabel }}</span>
									</template>
									<template v-else>Not synced yet.</template>
								</p>
								<Button
									variant="subtle"
									label="Run health check"
									iconLeft="activity"
									:loading="linting"
									@click="confirmLint"
								/>
							</div>
							<p class="mt-2 text-p-sm text-ink-gray-5">
								<template v-if="caps.wiki_lint_last_run_at">
									Last health check {{ timeAgo(caps.wiki_lint_last_run_at)
									}}<span v-if="caps.wiki_lint_summary">
										- {{ caps.wiki_lint_summary }}</span
									>
								</template>
								<template v-else>Health check hasn't run yet.</template>
							</p>
						</div>
					</template>
				</Popover>
				<Button
					v-if="caps.creatable_scopes.length"
					variant="solid"
					label="New page"
					iconLeft="plus"
					@click="openCreate"
				/>
			</template>

			<template #cell-title="{ row }">
				<div class="flex items-center gap-2 overflow-hidden">
					<div class="truncate text-base font-medium text-ink-gray-9">
						{{ row.title || row.slug }}
					</div>
					<Badge
						v-if="row.contradiction_flag"
						variant="subtle"
						theme="red"
						label="Conflicting"
					/>
					<Badge v-if="row.stale" variant="subtle" theme="orange" label="Stale" />
				</div>
			</template>

			<template #cell-page_type="{ row }">
				<Badge variant="outline" theme="gray" :label="typeLabel(row.page_type)" />
			</template>

			<template #cell-scope="{ row }">
				<Tooltip :text="scopeTooltip(row)">
					<Badge
						variant="subtle"
						:theme="SCOPE_THEME[row.scope] || 'gray'"
						:label="row.scope || 'Org'"
					/>
				</Tooltip>
			</template>

			<template #cell-summary="{ row }">
				<div class="truncate text-base text-ink-gray-6">{{ row.summary }}</div>
			</template>

			<template #cell-modified="{ row }">
				<div class="flex w-full items-center justify-end">
					<Tooltip :text="exactDate(row.modified)">
						<div class="truncate text-base">{{ timeAgo(row.modified) }}</div>
					</Tooltip>
				</div>
			</template>

			<!-- row actions (server-computed can_archive; delete shares the archive
			     authority server-side). @click.stop.prevent so the buttons never
			     bubble into the row's open-dialog click (RunsTab idiom). -->
			<template #cell-_actions="{ row }">
				<div
					v-if="row.can_archive"
					class="flex w-full items-center justify-end gap-1"
					@click.stop.prevent
				>
					<Button
						v-if="!isArchivedView"
						variant="ghost"
						icon="archive"
						:tooltip="'Archive'"
						:loading="rowBusy === rowSlug(row)"
						@click="confirmArchive(row)"
					/>
					<Button
						v-else
						variant="ghost"
						icon="rotate-ccw"
						:tooltip="'Restore'"
						:loading="rowBusy === rowSlug(row)"
						@click="doRestore(row)"
					/>
					<Button
						variant="ghost"
						theme="red"
						icon="trash-2"
						:tooltip="'Delete permanently'"
						:loading="rowBusy === rowSlug(row)"
						@click="confirmDelete(row)"
					/>
				</div>
			</template>
		</ListPage>
	</div>
</template>

<script setup>
// WikiTab - the "Wiki" tab inside the Skills page (design D4): the org-wide
// knowledge base Jarvis maintains, now scope-aware (Org / Role / User pages,
// server-side visibility). Standard ListPage + useListPage kit (FilesList
// precedent): server pagination, debounced search, scope / type / attention
// quick filters. A row click navigates to the routed WikiDetail page
// (pages/wiki/WikiDetail.vue, view/edit/archive gated by the server's
// can_edit/can_archive flags); a trailing actions column offers Archive
// (Restore on the Archived view) and permanent Delete inline for rows the
// caller may manage. "New page" navigates to WikiDetail's create route and
// shows for anyone whose creatable_scopes isn't empty; SMs also get the
// settings popover (knowledge language, mirror sync, health check).
import { reactive, ref, computed, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import { Badge, Button, Popover, Tooltip, toast, confirmDialog } from "frappe-ui";
import ListPage from "@/components/list/ListPage.vue";
import PanelSelect from "@/components/list/PanelSelect.vue";
import { useListPage } from "@/composables/useListPage";
import { wikiListFetch } from "@/pages/list/listFetchers";
import { timeAgo, exactDate } from "@/utils/datetime";
import { humaniseSyncStatus } from "@/lib/syncStatus";
import {
	getWikiCaps,
	archiveWikiPage,
	restoreWikiPage,
	deleteWikiPage,
	setKnowledgeLanguage,
	syncWikiMirrorNow,
	runWikiLintNow,
} from "@/api/wiki";
import { agentName } from "@/branding";
import { errHtml } from "@/lib/errors";
import { WIKI_TYPES, SCOPE_THEME } from "@/lib/wikiMeta";

// /skills is a TABBED shell; the `fv2` payload carries its view key so a sibling
// tab's filters are never half-applied here (judgment C08-7).
const route = useRoute();
const router = useRouter();

// ── static config ────────────────────────────────────────────────────────────
const TYPE_OPTIONS = [
	{ label: "All types", value: "" },
	...WIKI_TYPES.map((t) => ({ label: t === "Org" ? "Org notes" : t, value: t })),
];
const SCOPE_OPTIONS = [
	{ label: "All scopes", value: "" },
	{ label: "Org", value: "org" },
	{ label: "My role", value: "role" },
	{ label: "Mine", value: "mine" },
];
const ATTENTION_OPTIONS = [
	{ label: "All pages", value: "" },
	{ label: "Needs attention", value: "1" },
	{ label: "Archived", value: "archived" },
];
// "Org" as a page TYPE collides visually with the "Org" scope badge one
// column over; display it under a clearer name (stored value unchanged).
const TYPE_LABELS = { Org: "Org notes" };
function typeLabel(t) {
	return TYPE_LABELS[t] || t;
}
const LANGUAGE_OPTIONS = [
	{ label: "English (recommended)", value: "English" },
	{ label: "Original language", value: "Original" },
];

const columns = [
	{ label: "Title", key: "title", width: 3 },
	{ label: "Type", key: "page_type", width: "8rem" },
	{ label: "Scope", key: "scope", width: "6rem" },
	{ label: "Summary", key: "summary", width: 4 },
	{ label: "Updated", key: "modified", width: "8rem", align: "right" },
	{ label: "", key: "_actions", width: "7rem", align: "right" },
];
// search rides the quick-filter strip (FilesList precedent): it lives in the
// filters object so the input stays controlled, and fetchFn moves it onto the
// endpoint's `search` kwarg.
const quickFilters = [
	{ key: "search", label: "Search pages", type: "text" },
	{ key: "scope", label: "Scope", type: "select", options: SCOPE_OPTIONS },
	{ key: "page_type", label: "Type", type: "select", options: TYPE_OPTIONS },
	// "View", not "Attention": it also carries the Archived lifecycle view
	{ key: "attention", label: "View", type: "select", options: ATTENTION_OPTIONS },
];
// plan 08 wave 1: the curated `filterDefs` array is GONE as the filter catalog.
// The panel is generated from the server schema for view_key "wiki_pages".
//
// Only `page_type` maps 1:1 onto a canonical field. The other two quick controls
// stay legacy-only on purpose, and the registry says why: `scope` is the
// all|org|role|mine VIEW predicate (not the doctype's `scope` field — "mine"
// means scope='User' AND target_user=me, which no single clause expresses), and
// `attention` is a staleness/contradiction predicate that also carries the
// Archived lifecycle switch over `status`.
const QUICK_CLAUSES = { page_type: "page_type" };

// ── list state (server envelope; endpoint paginates by page number) ──────────
const {
	rows,
	total,
	hasMore,
	loading,
	error,
	filters,
	setFilters,
	pageLength,
	resetLoad,
	loadMore,
	refreshKeep,
	filterState,
	setClauses,
	requestSchema,
	dismissFilterNotice,
} = useListPage({
	fetchFn: wikiListFetch,
	storageKey: "wiki",
	viewKey: "wiki_pages",
	quickClauses: QUICK_CLAUSES,
	rootDoctype: "Jarvis Wiki Page",
	route,
	router,
});

// Archive vs Restore in the actions column keys off the lifecycle view:
// the Archived view lists only Archived pages, every other view only Active.
const isArchivedView = computed(() => filters.attention === "archived");

const emptyState = computed(() => {
	if (filters.scope === "mine" && caps.creatable_scopes.includes("User"))
		return {
			icon: "book-open",
			title: "No personal pages yet",
			description: `Personal pages are private to you and ${agentName}. Pick Personal scope in "New page" to create one.`,
		};
	// Panel clauses count as "filtered" too. Without this a panel-only narrowing
	// to zero rows claimed "No wiki pages yet" — on a knowledge base that reads
	// as data loss, which is the single most alarming thing this list can say
	// (design.md §3.8).
	if (Object.keys(filters).length || (filterState.value?.activeCount || 0) > 0)
		return {
			icon: "book-open",
			title: "No pages match",
			description: "Try a different search, scope or type filter.",
		};
	return {
		icon: "book-open",
		title: "No wiki pages yet",
		description: `${agentName} builds this from chat and voice notes. Use "New page" to add one yourself.`,
	};
});

function scopeTooltip(row) {
	if (row.scope === "Role") return `Visible to people with role: ${row.target_role || "-"}`;
	if (row.scope === "User")
		return `Personal page - visible only to ${row.target_user || "its owner"}`;
	return "Visible to everyone";
}

// ── caps (creatable scopes + SM header extras) ───────────────────────────────
const caps = reactive({
	is_sm: false,
	creatable_scopes: [],
	manageable_roles: [],
	knowledge_language: "English",
	wiki_lint_last_run_at: null,
	wiki_lint_summary: "",
	wiki_mirror_last_synced_at: null,
	wiki_mirror_last_sync_status: "",
});

// What the "Last synced …" line says about the last mirror push. Empty only when the
// backend recorded nothing at all, so the line stays a bare timestamp instead of
// gaining a redundant clause; an unrecognised status still gets syncStatus's degraded
// label rather than being dropped, because silence there would read as success. The
// failure reason IS shown: this line has room for it, and it is the only clue a
// customer gets about why the wiki is stale.
const wikiSyncLabel = computed(() => {
	const raw = (caps.wiki_mirror_last_sync_status || "").trim();
	if (!raw) return "";
	const st = humaniseSyncStatus(raw);
	return st.detail ? `${st.text}: ${st.detail}` : st.text;
});

async function loadCaps() {
	try {
		const c = await getWikiCaps();
		caps.is_sm = !!c.is_sm;
		caps.creatable_scopes = c.creatable_scopes || [];
		caps.manageable_roles = c.manageable_roles || [];
		caps.knowledge_language = c.knowledge_language || "English";
		caps.wiki_lint_last_run_at = c.wiki_lint_last_run_at || null;
		caps.wiki_lint_summary = c.wiki_lint_summary || "";
		caps.wiki_mirror_last_synced_at = c.wiki_mirror_last_synced_at || null;
		caps.wiki_mirror_last_sync_status = c.wiki_mirror_last_sync_status || "";
	} catch (e) {
		// read-only view stays useful without caps (no create / SM chrome)
	}
}

// ── row click / "New page" navigate to the routed wiki detail page ──────────
function openRow(row) {
	router.push({ name: "WikiPageDetail", params: { slug: row.slug || row.name } });
}
function openCreate() {
	router.push({ name: "WikiPageNew" });
}

// ── row actions (archive / restore / delete) ─────────────────────────────────
// slug of the row with an in-flight lifecycle call - one at a time is plenty
const rowBusy = ref("");
function rowSlug(row) {
	return row.slug || row.name;
}

async function runRowAction(row, fn, successMsg) {
	const slug = rowSlug(row);
	rowBusy.value = slug;
	try {
		await fn(slug);
		toast.success(successMsg);
		resetLoad();
	} catch (e) {
		toast.error(errHtml(e));
	} finally {
		rowBusy.value = "";
	}
}

function confirmArchive(row) {
	confirmDialog({
		title: "Archive this page?",
		message:
			"Archived pages stop appearing in the list and are no longer used as chat context. The record is kept.",
		onConfirm: async ({ hideDialog }) => {
			hideDialog();
			await runRowAction(row, archiveWikiPage, "Page archived");
		},
	});
}

// no confirm: Restore is itself the escape hatch for an accidental archive
function doRestore(row) {
	runRowAction(row, restoreWikiPage, "Page restored");
}

function confirmDelete(row) {
	confirmDialog({
		title: "Delete this page permanently?",
		message:
			"Permanently deletes this page - archiving keeps it recoverable. This cannot be undone.",
		onConfirm: async ({ hideDialog }) => {
			hideDialog();
			await runRowAction(row, deleteWikiPage, "Page deleted");
		},
	});
}

// ── SM extras (settings popover) ─────────────────────────────────────────────
const syncing = ref(false);
const linting = ref(false);

async function changeLanguage(v) {
	if (!v || v === caps.knowledge_language) return;
	const previous = caps.knowledge_language;
	try {
		await setKnowledgeLanguage(v);
		caps.knowledge_language = v;
		toast.success(`Knowledge language set to ${v}`);
	} catch (e) {
		caps.knowledge_language = previous;
		toast.error(errHtml(e));
	}
}

function confirmSync() {
	confirmDialog({
		title: "Sync wiki to agent now?",
		// #621: this used to promise "the daily sync". There is no daily sync: wiki_mirror
		// is wired only as doc events, with no scheduler entry at all. Promising a
		// fallback that does not exist is worse than promising nothing, because a user
		// who reads it reasonably decides NOT to press the button, believing the mirror
		// catches up within a day. It never does.
		message:
			"Pushes every active org-scope page into the agent's workspace mirror now. " +
			"The mirror is otherwise updated only when a page changes, so use this if it " +
			"looks out of date.",
		onConfirm: async ({ hideDialog }) => {
			syncing.value = true;
			try {
				const r = await syncWikiMirrorNow();
				hideDialog();
				if (r && r.ok === false) toast.error(r.reason || "Could not queue the sync.");
				else toast.success("Sync queued");
			} catch (e) {
				toast.error(errHtml(e));
			} finally {
				syncing.value = false;
			}
		},
	});
}

function confirmLint() {
	confirmDialog({
		title: "Run wiki health check?",
		message:
			"Scans active pages for contradictions, stale content, orphans and " +
			"near-duplicate titles, and flags pages needing attention. May take a moment.",
		onConfirm: async ({ hideDialog }) => {
			linting.value = true;
			try {
				const r = await runWikiLintNow();
				hideDialog();
				if (r && r.ok === false)
					toast.error(r.reason || "Could not run the health check.");
				else toast.success("Health check finished");
				loadCaps();
				refreshKeep();
			} catch (e) {
				toast.error(errHtml(e));
			} finally {
				linting.value = false;
			}
		},
	});
}

// ── init ─────────────────────────────────────────────────────────────────────
onMounted(loadCaps);
</script>
