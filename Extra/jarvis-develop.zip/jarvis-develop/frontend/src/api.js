// Thin wrappers around frappe-ui's `call` (which posts to /api/method/... with
// the session cookie + CSRF). Same backend the Desk chat uses, so conversations
// stay consistent across surfaces.
import { call } from "frappe-ui";
import { listPageArgs as _page } from "./api/listPageArgs";

export const listConversations = () => call("jarvis.chat.api.list_conversations");
export const listTools = () => call("jarvis.chat.api.list_tools");
export const getConversation = (conversation) =>
	call("jarvis.chat.api.get_conversation", { conversation });
// Rich outputs: fetch one canvas/chart artifact's render-ready HTML for an
// assistant message (sandboxed-iframe srcdoc). `name` selects which artifact
// when a message has several.
export const getCanvas = (message, name, dark) =>
	call("jarvis.chat.api.get_canvas", { message, name: name || "", dark: dark ? 1 : 0 });
// Tabular/text preview for the artifact side panel (xlsx/csv → sheets, txt → text).
export const previewFile = (fileUrl) =>
	call("jarvis.chat.api.preview_file", { file_url: fileUrl });
export const createOrFocusEmpty = () => call("jarvis.chat.api.create_or_focus_empty");
// Post-reply feedback: a thumbs up/down (+ optional note on a down) on one
// assistant reply. Best-effort - the bench derives the metadata server-side and
// forwards it to the admin fleet dashboard; the tap never blocks on that.
export const submitFeedback = (message, rating, note) =>
	call("jarvis.chat.feedback.submit_feedback", {
		message_id: message,
		rating,
		note: note || "",
	});
// Once-per-session popup ("How did this session go?"): status poll (is it due
// for this conversation right now?) and the answer/Skip submission. Mirrors
// submitFeedback's best-effort contract - see SessionFeedbackDialog.vue.
export const sessionFeedbackStatus = (conversation) =>
	call("jarvis.chat.feedback.session_feedback_status", { conversation });
export const submitSessionFeedback = (conversation, chip_value, note) =>
	call("jarvis.chat.feedback.submit_session_feedback", {
		conversation,
		chip_value: chip_value || undefined,
		note: note || "",
	});
// Periodic "business pulse" survey: a due-check run on chat open (also CLAIMS
// the offer server-side, see feedback.pulse_context) and the answer submission.
// Mirrors submitFeedback's best-effort contract - see PulseFeedbackDialog.vue.
export const pulseContext = () => call("jarvis.chat.feedback.pulse_context", {});
export const submitPulseFeedback = (
	stars,
	features_offered,
	features_selected,
	use_case_text,
	note
) =>
	call("jarvis.chat.feedback.submit_pulse_feedback", {
		stars,
		features_offered: JSON.stringify(features_offered || []),
		features_selected: JSON.stringify(features_selected || []),
		use_case_text: use_case_text || "",
		note: note || "",
	});
export const archiveConversation = (conversation) =>
	call("jarvis.chat.api.archive_conversation", { conversation });
// Danger zone: permanently delete ALL of the user's conversations + messages.
export const clearChatHistory = () => call("jarvis.chat.api.clear_chat_history");
export const renameConversation = (conversation, title) =>
	call("jarvis.chat.api.rename_conversation", { conversation, title });
export const setStar = (conversation, starred) =>
	call("jarvis.chat.api.set_star", { conversation, starred: starred ? 1 : 0 });
export const retryMessage = (message) => call("jarvis.chat.api.retry_message", { message });
export const getChatUiSettings = () => call("jarvis.chat.api.get_chat_ui_settings");
// Estimated token usage (this chat / this month / total + monthly budget).
// Response also carries a "measured" block (real gateway-recorded counters +
// the caller's own monthly_token_limit) once the backend records usage —
// null/zeros until then (design doc §6, UsagePane's "Measured usage" block).
export const getUsage = (conversation) =>
	call("jarvis.chat.api.get_usage", { conversation: conversation || "" });
// Context-window meter for one chat: {used, capacity, pct, warn_pct,
// auto_compact_pct, route, compaction_count, last_compacted_at, compacting,
// fresh}. Bench snapshot, refreshed after every completed turn.
export const getConversationContext = (conversation) =>
	call("jarvis.chat.api.get_conversation_context", { conversation });
// Summarise older turns. Optional hint = what to keep. Resolves to
// {ok, queued} or {ok:false, reason}; the result arrives later as a
// context:compacted / context:compact_failed event.
export const compactConversation = (conversation, hint = "") =>
	call("jarvis.chat.api.compact_conversation", { conversation, hint: hint || null });
// Tool runs recorded in one chat, newest turn first, from the PERSISTED tool
// rows: the same rows the thread's Activity accordion renders. The Settings
// Activity pane used to derive this from the browser's live run stream, which
// read zero on every reload (#551). Response: {runs:[{tools,ms,names}],
// tool_calls}.
export const getToolActivity = (conversation) =>
	call("jarvis.chat.api.get_tool_activity", { conversation });
// ---- account reconnect (fresh bench -> existing paid subscription) ---------
export const reconnectAvailable = (email, company = "") =>
	call("jarvis.onboarding.reconnect_available", { email, company });
export const startAccountReconnect = (email, company = "") =>
	call("jarvis.onboarding.start_account_reconnect", { email, company });
export const checkAccountReconnect = (requestId, code) =>
	call("jarvis.onboarding.check_account_reconnect", { request_id: requestId, code: code || "" });
// Operator-issued code path: no prior request, so the customer supplies the code
// they got from support PLUS their registered email (the second factor). Same
// landing as check_account_reconnect; a wrong/expired/unmatched pair -> "invalid".
export const redeemReconnectCode = (code, email) =>
	call("jarvis.onboarding.redeem_reconnect_code", { code: code || "", email: email || "" });

export const isReadyForChat = () => call("jarvis.account.is_ready_for_chat");
// Re-drive this workspace's saved AI config through admin - the customer lever
// for a stuck apply (jarvis#825, reason "llm_apply_stuck"). Probes admin first
// and only re-pushes if the container is NOT already serving; throttled once per
// 180s server-side. Admin-gated (require_jarvis_admin). Returns get_llm_sync_status()'s
// shape plus `outcome`: converged | queued | throttled | not_configured.
export const resyncLlm = () => call("jarvis.onboarding.resync_llm");
// Read-only poll of a durable LLM-apply operation (plan-05 D2). The single
// Start-chatting controller (frontend/src/lib/llmOperation.js) follows exactly one
// operation id to a terminal state through this; it never spends the apply bucket.
export const getLlmApplyOperation = (operationId) =>
	call("jarvis.account.get_llm_apply_operation", { operation_id: operationId });

// ---- workspace reset (customer self-serve, admin-gated) --------------------
export const requestWorkspaceReset = (reason, opts = {}) =>
	call("jarvis.onboarding.request_workspace_reset", {
		reason: reason || "",
		wipe_data: opts.wipeData ? 1 : 0,
		revoke_llm: opts.revokeLlm ? 1 : 0,
	});
export const workspaceResetState = () => call("jarvis.onboarding.workspace_reset_state");
// Reset onboarding: clears connection + creds and (wipeData, the CLI default)
// all workspace content, so the setup wizard re-runs. No container rebuild.
export const resetOnboarding = (wipeData = true) =>
	call("jarvis.onboarding.reset_onboarding", { wipe_data: wipeData ? 1 : 0 });

// GSTIN party autofill on the Details step, using THIS site's own India Compliance (offered only
// where its lookup API is usable). `available` gates the button; `gstin_autofill` returns the party
// details ({found, ...}) or a soft miss — the form always falls back to manual entry.
export const gstinAutofillAvailable = () => call("jarvis.onboarding.gstin_autofill_available");
export const gstinAutofill = (gstin) => call("jarvis.onboarding.gstin_autofill", { gstin });

// --- Per-user chat settings + real (measured) usage tracking, incl. the
// tenant-admin usage table (design doc §4/§6). All return the house
// {ok, data} / {ok:false, reason} envelope — unlike getUsage above, which is
// a flat legacy dict. ---
const US = "jarvis.chat.user_settings_api.";
export const getMySettings = () => call(US + "get_my_settings");
export const updateMySettings = (p) => call(US + "update_my_settings", p || {});
export const setUserTheme = (theme) => call(US + "set_user_theme", { theme });
// Persist the sidebar nav order (drag-to-reorder). order = {top:[labels], more:[labels]}.
export const setSidebarOrder = (order) =>
	call(US + "set_sidebar_order", { order: JSON.stringify(order || {}) });
// New-chat prompt suggestions, synthesised from the caller's own recent chat
// titles. Returns the server-side CACHE (and quietly queues a refresh when it is
// stale) — never generates inline, so this is a cheap read. {ok, data:{suggestions:[]}}.
export const getPromptSuggestions = () => call(US + "get_prompt_suggestions");
export const getCapabilityCatalog = () => call(US + "get_capability_catalog");
export const logCapabilityPick = (title) => call(US + "log_capability_pick", { title });
// Jarvis Admin (or System Manager) only — server re-checks independently of
// the client's window.is_jarvis_admin gate.
export const adminListUserUsage = () => call(US + "admin_list_user_usage");
// limitPeriod: "All time" | "Daily" | "Weekly" | "Monthly"; omitted = unchanged.
// Switching it restarts the user's window server-side.
export const adminSetUserLimit = (user, monthlyTokenLimit, limitPeriod) =>
	call(US + "admin_set_user_limit", {
		user,
		monthly_token_limit: monthlyTokenLimit,
		...(limitPeriod ? { limit_period: limitPeriod } : {}),
	});
export const adminSetUserModelLimit = (user, model, monthlyTokenLimit) =>
	call(US + "admin_set_user_model_limit", {
		user,
		model,
		monthly_token_limit: monthlyTokenLimit,
	});
export const adminSyncUsage = () => call(US + "admin_sync_usage");

// --- Whitelabel branding (tenant-admin only; server re-checks) ---
const BR = "jarvis.branding.";
export const getBranding = () => call(BR + "get_branding");
export const updateBranding = (p) => call(BR + "update_branding", p || {});

// --- Predefined + custom PDF templates. list/get default: any Jarvis user. set
// default, and the whole custom-template CRUD + preview + options set below:
// tenant-admin only (server re-checks). rerender: any user, ownership-checked on
// the source File - the per-document override on a PDF artifact card. ---
const PT = "jarvis.pdf_templates.";
export const listPdfTemplates = () => call(PT + "list_pdf_templates");
export const getDefaultPdfTemplate = () => call(PT + "get_default_pdf_template");
export const setDefaultPdfTemplate = (key) => call(PT + "set_default_pdf_template", { key });
export const rerenderDocument = (source_name, template) =>
	call(PT + "rerender_document", { source_name, template });
// Custom template admin CRUD (tenant-admin only). `payload`/`config` are plain
// objects here - callers JSON.stringify them, matching the backend's `payload:
// str` / `config: str` signatures (same convention as saveLlmPool's `models`).
export const getPdfTemplate = (key) => call(PT + "get_pdf_template", { key });
export const savePdfTemplate = (payload) => call(PT + "save_pdf_template", { payload });
export const deletePdfTemplate = (key) => call(PT + "delete_pdf_template", { key });
// config: {key, company} for a saved template, or {draft:{...}, company} for
// unsaved edits - see PdfTemplatesPane.vue's payloadFromForm().
export const previewPdfTemplate = (config) => call(PT + "preview_pdf_template", { config });
export const pdfTemplateOptions = () => call(PT + "pdf_template_options");

// --- Mobile onboarding: QR of the mobile PWA URL (no secret — just the public
// URL). Scanning opens /jarvis-mobile (Android offers to install it, iOS opens
// it in Safari for Add-to-Home-Screen). ---
export const getPwaQr = () => call("jarvis.mobile.auth.get_pwa_qr");

// --- Custom skills (customer-authored, pushed to the container) ---
const SK = "jarvis.chat.custom_skills_api.";
export const listCustomSkills = () => call(SK + "list_custom_skills");
export const getCustomSkill = (name) => call(SK + "get_custom_skill", { name });
export const createCustomSkill = (p) => call(SK + "create_custom_skill", p);
export const updateCustomSkill = (p) => call(SK + "update_custom_skill", p);
export const deleteCustomSkill = (name) => call(SK + "delete_custom_skill", { name });
export const applyCustomSkills = () => call(SK + "apply_custom_skills");
export const getCustomSkillsSyncStatus = () => call(SK + "get_custom_skills_sync_status");
// Skill sharing: owner shares a skill with specific users (read-only for them).
export const listShareableUsers = () => call(SK + "list_shareable_users");
export const getSkillShares = (name) => call(SK + "get_skill_shares", { name });
export const shareCustomSkill = (name, users) =>
	call(SK + "share_custom_skill", { name, users: JSON.stringify(users || []) });

// --- Macros (customer-authored prompt sequences run as chained turns) ---
const MC = "jarvis.chat.macros_api.";
export const listMacros = () => call(MC + "list_macros");
export const getMacro = (name) => call(MC + "get_macro", { name });
export const createMacro = (p) =>
	call(MC + "create_macro", { ...p, steps: JSON.stringify(p.steps || []) });
export const updateMacro = (p) => {
	const args = { ...p };
	if (p.steps !== undefined) args.steps = JSON.stringify(p.steps);
	return call(MC + "update_macro", args);
};
export const deleteMacro = (name) => call(MC + "delete_macro", { name });
export const runMacro = (name) => call(MC + "run_macro", { name });
export const stopMacroRun = (run) => call(MC + "stop_macro_run", { run });
// Run-history dashboard (settings → Macro runs).
export const listMacroRuns = (params) => call(MC + "list_macro_runs", params || {});
export const macroRunStats = () => call(MC + "macro_run_stats");
// Background summarize: fired after every 2+ step save; the WORKER applies the
// summary when the turn ends (macro:merged event) - no client round-trip needed.
// Run is gated on merge_status while pending.
export const summarizeMacro = (name) => call(MC + "summarize_macro", { name });
export const setConversationModel = (conversation, model) =>
	call("jarvis.chat.api.set_conversation_model", { conversation, model: model || "" });
// Reasoning effort. "" clears the override, so the turn inherits Jarvis Settings.
// The server maps this onto agent's "/think <level>" directive.
export const setConversationThinking = (conversation, thinking) =>
	call("jarvis.chat.api.set_conversation_thinking", { conversation, thinking: thinking || "" });

// --- Recurring business-note greeting banner ---
// maybe_greet takes no user argument on purpose: it always acts on the session
// user, so one user can never trigger a greeting for another. All gating
// (every-third-chat cadence / dismissed / has-notes) lives on the server.
const GR = "jarvis.chat.greeting.";
export const maybeGreet = () => call(GR + "maybe_greet");
// "Maybe later" / the card's X: hides for the rest of the current cadence tick
// (survives refresh); the card returns on the next multiple-of-three chat.
export const hideGreeting = () => call(GR + "hide_greeting");
export const dismissGreeting = () => call(GR + "dismiss_greeting");

// --- Record draft panel (direct apply, no LLM in the loop) ---
const AC = "jarvis.chat.actions_api.";
export const getDoctypeFormMeta = (doctype) => call(AC + "get_doctype_form_meta", { doctype });
export const loadDocForEdit = (doctype, name) => call(AC + "load_doc", { doctype, name });
export const applyAction = (action) =>
	call(AC + "apply_action", { action: JSON.stringify(action) });
// Write-safety gate (issue #186): confirm a parked ERP write by its one-time
// token. Pass the conversation the click came from so the server enforces the
// real conversation guard (#11). Returns the tool result envelope {ok, ...} on
// success. A gone token returns InvalidConfirmation; a Redis outage returns a
// ConfirmationUnavailableError/ConfirmationOutcomeUnknownError that the UI must
// keep on screen because the business action did not run in that request.
export const confirmTool = (token, conversation) =>
	call(AC + "confirm_tool", { token, conversation: conversation || "" });
// "Approve & run" (skill approve-and-run, P1): a SIBLING of confirm_tool, not an
// overload - it confirms this card's step 1 AND opens the armed skill's
// uninterrupted run, so the covered writes after this one execute with receipts
// instead of parking their own cards. Same {ok,...}/InvalidConfirmation/
// storage-unavailable envelope as confirmTool (jarvis/chat/actions_api.py
// approve_and_run). Only reachable from a card whose preview.card.approve_run is
// true, and only from its own button - never from the typed "go ahead" path
// (that stays confirm-only, see ChatView.vue's approvalTokens comment).
export const approveAndRun = (token, conversation) =>
	call(AC + "approve_and_run", { token, conversation: conversation || "" });
// Discard a parked ERP write by its one-time token: consumes the token (so it
// can't replay or re-surface on reload), leaves a durable "discarded" receipt
// chip in the transcript, and queues a note so the agent's next turn learns it
// was vetoed. Returns {ok, data:{status:"discarded"|"already_handled"}}; the SPA
// drops the card for those success states; storage-error envelopes retain it.
export const dismissTool = (token, conversation) =>
	call(AC + "dismiss_tool", { token, conversation: conversation || "" });
// Resync (issue #186, R3 fix for #3): re-surface the caller's own currently
// parked confirmation cards after a reload/reconnect. Returns
// {ok, data:{pending:[{token, tool, preview, summary, conversation, run_id}]}}.
// `source` is an optional provenance tag (layered re-check design): the on-demand
// controls pass "pill"/"menu" and the silent auto-heal passes "auto", so the backend
// attributes per layer how often a card had to be re-surfaced (AC-detect rescue).
export const listPendingConfirmations = (conversation, source) =>
	call(AC + "list_pending_confirmations", {
		conversation: conversation || "",
		...(source ? { source } : {}),
	});

export async function sendMessage(
	conversation,
	message,
	modelOverride,
	attachments,
	context,
	approvalTokens,
	voice
) {
	// Empty conversation is allowed: the backend creates (or focuses) an empty
	// conversation itself and returns its id as `conversation_id` - saves the
	// SPA a createOrFocusEmpty round-trip before the first send (latency plan).
	const args = { conversation: conversation || "", message };
	// Dictated-and-sent flag (via_voice on the persisted Jarvis Chat Message):
	// true only when ChatView's send() found a non-empty voice-ack token for
	// this payload. Omitted (not even `voice: 0`) for every ordinary typed
	// send, matching every existing caller that doesn't pass this arg.
	if (voice) args.voice = 1;
	if (modelOverride) args.model_override = modelOverride;
	if (attachments && attachments.length) args.attachments = JSON.stringify(attachments);
	// The ordered tokens of the confirmation cards on screen. A typed "confirm 2"
	// selects by the number the user sees, so the server must resolve that number
	// against THESE tokens (what was displayed) rather than a list it re-fetches -
	// otherwise a card expiring between glance and send renumbers the rest and the
	// wrong card runs. Server ignores it unless the message parses as an approval.
	if (approvalTokens && approvalTokens.length)
		args.approval_tokens = JSON.stringify(approvalTokens);
	// Forward context for a viewing-context doc/report, the one-shot "ground on
	// wiki" flag (which can arrive without a doc), a page marker ("triggers" /
	// "dashboards") that primes the agent for that surface's flow from the main
	// chat, OR the composer's connector-focus pill ({key, label} of the one
	// connector the user scoped this turn to — a soft prompt-level nudge, never
	// tool gating). The backend re-applies the same allow-list
	// (chat.api.send_message).
	if (
		context &&
		(context.doctype ||
			context.ground_wiki ||
			context.page === "triggers" ||
			context.page === "dashboards" ||
			(context.focus_connector &&
				context.focus_connector.key &&
				context.focus_connector.label))
	)
		args.context = JSON.stringify(context);
	return call("jarvis.chat.api.send_message", args);
}

// Actually abort a running turn (agent chat.abort) — best-effort; on failure
// the UI stop stands and the turn finishes server-side.
export async function stopRun(conversation, runId) {
	return call("jarvis.chat.api.stop_run", { conversation, run_id: runId || "" });
}

// Phase-0 admission (chat concurrency): cancel a turn that is still QUEUED
// (behind other turns, not yet dispatched). Owner-checked server-side.
export const cancelQueuedTurn = (runId) =>
	call("jarvis.chat.admission.cancel_queued_turn", { run_id: runId });

// Poll-on-focus fallback for the queued chip: returns {state, position}.
export const getQueuePosition = (runId) =>
	call("jarvis.chat.admission.queue_position", { run_id: runId });

// Server-truth resync for the queued chip (SUXI-1): the conversation's own
// non-terminal turn, if any. Rebuilds the chip after a reload / conversation
// switch / second tab / WS reconnect (the queued chip is otherwise client-only).
export const getActiveTurn = (conversation) =>
	call("jarvis.chat.admission.active_turn_for_conversation", { conversation });

// Mentions: reuse Frappe's built-in Link-field search (no custom backend).
// `pageLength` defaults to the mention picker's 8; the list FilterGroup asks for
// plan 08 §9's Link-suggestion cap of 20. Frappe's own search_link enforces the
// target DocType's read permission + user permissions, which is why plan 08 adds
// no second search endpoint.
//
// `referenceDoctype` / `linkFieldname` (plan 08 P1-06) name WHERE the Link is
// used, so a DocType's custom `search_link` hook and user-permission behaviour
// can key off the field. They are untrusted CONTEXT — the server still enforces
// the target's read permission regardless — and are sent only when known
// (mentions omit them). The list FilterGroup passes the schema entry's own
// (doctype, fieldname), which the shared schema already knows.
export const searchLink = (doctype, txt, pageLength, referenceDoctype, linkFieldname) => {
	const args = { doctype, txt: txt || "", page_length: pageLength || 8 };
	// Frappe's search_link params (frappe/desk/search.py): reference_doctype +
	// keyword-only link_fieldname. Sent only when known.
	if (referenceDoctype) args.reference_doctype = referenceDoctype;
	if (linkFieldname) args.link_fieldname = linkFieldname;
	return call("frappe.desk.search.search_link", args);
};

// Field metadata for the record-edit action card: powers Link/Select/Date
// controls (returns {ok, doctype, fields:[{fieldname,label,fieldtype,options}]}).
export const getDoctypeFields = (doctype) =>
	call("jarvis.chat.api.get_doctype_fields", { doctype });

// --- LLM pool / models config (System-Manager only, gated server-side) ---
export const getLlmConfig = () => call("jarvis.onboarding.get_llm_config");
export const getPresetCatalog = () => call("jarvis.onboarding.get_preset_catalog");
// Admin-managed model catalog slice (api_key_models, subscription_models,
// default_models) for the pool editor + subscription card. Independent of
// get_chat_ui_settings so it also works in the onboarding wizard, which never
// calls that. See jarvis.chat.api.get_model_catalog_ui.
export const getModelCatalogUi = () => call("jarvis.chat.api.get_model_catalog_ui");
export const getLlmSyncStatus = () => call("jarvis.onboarding.get_llm_sync_status");
// jarvis#840: the pre-chat preflight. Answers what readiness cannot -
// { plugin, persona, usable: {state, detail} } - and never refuses: every
// failure inside it degrades to unchecked/unknown (only usable.state "auth"
// blocks, client-side). Plain dict, no ok-envelope, like isReadyForChat.
export const runChatPreflight = () => call("jarvis.preflight.run_chat_preflight");
// Persist the desired pool AND return the durable apply-operation descriptor the
// Start-chatting controller follows (plan-05 D2). Returns (unwrapped)
// { apply_operation: <12-key descriptor|null>, idempotency_key, resumable }.
// The idempotency_key makes a re-call after a lost response dedupe on admin
// rather than mint a second desired version; resumable:true with
// apply_operation:null means the descriptor is available under the SAME key on a
// re-call (a bench→admin timeout after a server-side retry).
// `forceProbe` (jarvis_admin_v2#297) asks admin to run a real probe even against
// a byte-identical config, so a repeat subscription Test does not just answer
// from the last verdict on record. Defaults false: every ordinary save,
// including "Start chatting", calls this with fewer than five arguments and so
// never sends it. Reused for a fresh probe on demand only by
// LlmPoolEditor.vue's testSubscriptionRow, which also mints a fresh
// idempotencyKey on every press - force_probe is not part of admin's
// idempotency fingerprint, so a repeated key would resolve through admin's
// idempotent-reuse path regardless of this flag.
export const saveLlmPool = (
	models,
	preset = null,
	routingMode = "failover",
	idempotencyKey = "",
	forceProbe = false
) =>
	call("jarvis.onboarding.save_llm_pool", {
		models: JSON.stringify(models),
		preset: preset || "",
		routing_mode: routingMode,
		idempotency_key: idempotencyKey || "",
		force_probe: forceProbe ? 1 : 0,
	});
// Tear the whole AI connection down: deletes every stored credential on the
// bench (models[] rows + the legacy flat fields) and asks admin to delete them
// from the workspace container. NOT "save an empty pool" - saveLlmPool refuses
// an empty list on purpose. Idempotent. Returns { disconnected: true }.
export const disconnectLlm = () => call("jarvis.onboarding.disconnect_llm");
// Pre-save "Test" probe for ONE api-key model row (never persists, never
// touches the fleet/container - see jarvis/llm_key_probe.py). args:
// {provider, model, api_key, base_url, use_stored_key}. Returns
// {ok, verdict, checks:[{check,ok,detail}], provider, local_endpoint, caveat}.
// `verdict` is "pass" | "fail" | "unverified" and is what decides how the result
// renders: "unverified" means the bench never reached the endpoint, which is a
// statement about this network and not a failure the customer caused, so it must
// not show in red (#680). `ok` stays strictly verdict === "pass", so anything
// gating on it keeps today's strictness.
// `use_stored_key` asks the server to load the saved key for this provider
// rather than a typed one (#679). The key is never sent to the browser in either
// direction, so this flag is the only way to test an already-saved credential.
export const testLlmApiKey = (args) => call("jarvis.llm_key_probe.test_llm_api_key", args);

// --- Onboarding wizard (managed signup) ---
// Arg names mirror the real backend signatures (jarvis/onboarding.py,
// jarvis/account.py) - verified against the desk wizard's frappe.call usage in
// jarvis/jarvis/page/jarvis_onboarding/jarvis_onboarding.js.
export const listPlans = () => call("jarvis.onboarding.list_plans");
// {providers: [...], default: "..."} - already narrowed to gateways the
// operator enabled AND this bench build can render.
export const listPaymentProviders = () => call("jarvis.onboarding.list_payment_providers");
export const getAccountDefaults = () => call("jarvis.onboarding.get_account_defaults");
// ERP-derived billing defaults for the selected Company (Plan 01): its primary
// Contact phone + primary billing Address (+ optional GSTIN), or a coded error
// ({ok:false, error:{code}}). Behind the same onboarding-admin gate.
export const getCompanyOnboardingDefaults = (company) =>
	call("jarvis.onboarding.get_company_onboarding_defaults", { company });
export const syncConnection = () => call("jarvis.onboarding.sync_connection");
// Lead-capture + T&C frozen contract. Fire-and-forget upsert of a Jarvis Lead
// on entering the Plan step - the CALLER is responsible for not awaiting this
// in a way that blocks the step transition and for swallowing rejections
// (this wrapper does not catch; jarvis.onboarding.capture_onboarding_lead
// itself never raises, but the underlying frappe-ui `call` can still reject
// on a network failure).
export const captureOnboardingLead = (payload) =>
	call("jarvis.onboarding.capture_onboarding_lead", payload || {});
// The admin-hosted Terms & Conditions URL for the Review & Pay checkbox link.
// Best-effort ({url: ""} on any failure) - the view falls back to plain
// unlinked text rather than gating the checkbox on this fetch.
export const getTermsUrl = () => call("jarvis.onboarding.get_terms_url");
export const startSignup = (email, company, plan, provider, billing) =>
	call("jarvis.onboarding.start_signup", { email, company, plan, provider, billing });
// Authenticated billing-only edit (Plan 01, post-intent Review & Pay "Edit"):
// updates the owned Pending Payment customer WITHOUT creating/replacing an
// intent. NEVER guest signup. Returns {billing_saved, billing} (normalized).
export const updateBilling = (billing) => call("jarvis.onboarding.update_billing", { billing });
export const checkSignupPaymentState = () => call("jarvis.onboarding.check_signup_payment_state");
export const finishPayment = (payload) => call("jarvis.onboarding.finish_payment", { payload });

// --- Payment state machine (plan 02 / plan 03 contract) ---------------------
// These wrap the SAME whitelisted endpoints, but they must NOT go through
// frappe-ui's `call`: `call` throws on a 4xx and keeps only a decoded message,
// while the whole payment contract lives in the RESPONSE BODY - the stamped
// `error` object on a throw, the `{ok, data, context}` envelope on a coded 4xx.
// `rawOnboardingCall` returns `{status, body, networkError}` untouched, and
// @/onboarding/paymentCodec.decode reads it. usePaymentFlow consumes this map.
async function rawOnboardingCall(method, args, opts = {}) {
	const headers = {
		Accept: "application/json",
		"Content-Type": "application/json; charset=utf-8",
		"X-Frappe-Site-Name": window.location.hostname,
	};
	if (window.csrf_token && window.csrf_token !== "{{ csrf_token }}") {
		headers["X-Frappe-CSRF-Token"] = window.csrf_token;
	}
	try {
		const res = await fetch(`/api/method/${method}`, {
			method: "POST",
			headers,
			body: JSON.stringify(args || {}),
			// The client-side deadline (plan 02 P0-3). usePaymentFlow races every
			// payment call against a wall-clock timeout and aborts this signal when it
			// fires, so a stalled proxy/never-settling fetch cannot leave the customer
			// on a permanent busy screen. An abort is a CLIENT signal only - the flow
			// treats it as truth-UNKNOWN and reconciles server truth, never as a
			// payment verdict, because aborting the browser does not cancel server
			// work.
			signal: opts.signal,
		});
		let body = null;
		try {
			body = await res.json();
		} catch (e) {
			body = null; // an HTML error page, an empty 502 - decode() treats it as unreadable
		}
		return { status: res.status, body };
	} catch (e) {
		// fetch itself rejected: offline, DNS, CORS - OR the deadline aborted it. An
		// AbortError must propagate so the flow's timeout race sees the timeout (it
		// is racing this promise against its own timer); everything else is a
		// networkError, never a payment verdict.
		if (e && e.name === "AbortError") throw e;
		return { status: 0, body: null, networkError: true };
	}
}

// The raw-response endpoint map usePaymentFlow is constructed with. Kept as one
// object so the flow's dependency surface is explicit and stubbable in tests.
// Each method takes an optional `{signal}` so the flow can bound it (P0-3).
export const onboardingPaymentApi = {
	getOnboardingState: (opts) =>
		rawOnboardingCall("jarvis.onboarding.get_onboarding_state", {}, opts),
	startSignup: (
		{ email, company, plan, provider, billing, partner_code, terms_accepted, contact_consent },
		opts
	) =>
		// Plan 01: the normalized billing snapshot rides the FIRST signup call so it
		// persists server-side while the customer is still a guest (update_billing is
		// authenticated and unreachable mid-signup). Included only when present - an
		// empty object is never sent (the caller omits it), so an older admin that
		// ignores the kwarg is unaffected.
		// partner_code: an optional TOP-LEVEL kwarg (never inside billing), same
		// omit-when-absent shape - an older admin that doesn't know the kwarg drops
		// it and the signup proceeds exactly as before.
		// terms_accepted / contact_consent (T&C + lead-capture frozen contract): sent
		// UNCONDITIONALLY, unlike billing/partner_code above - the view only calls
		// this once the required Review & Pay checkbox is ticked, and admin's
		// acceptance check needs to see the real value, not an omitted key.
		rawOnboardingCall(
			"jarvis.onboarding.start_signup",
			{
				email,
				company,
				plan,
				provider,
				...(billing ? { billing } : {}),
				...(partner_code ? { partner_code } : {}),
				terms_accepted,
				contact_consent,
			},
			opts
		),
	initiateSignupPayment: ({ plan, provider }, opts) =>
		// Deliberately NO idempotency_key: the bench owns that receipt
		// (onboarding_contract.next_idempotency_key). Passing one from the browser
		// invites a replay of a dead intent.
		rawOnboardingCall("jarvis.onboarding.initiate_signup_payment", { plan, provider }, opts),
	checkSignupPaymentStatus: (opts) =>
		rawOnboardingCall("jarvis.onboarding.check_signup_payment_status", {}, opts),
	confirmSignupPayment: (payload, opts) =>
		rawOnboardingCall("jarvis.onboarding.finish_payment", { payload }, opts),
	syncConnection: () => call("jarvis.onboarding.sync_connection"),
	// jarvis#297 P0-2a: "Resend the link". This bench method does not exist yet -
	// the wizard only ever calls it when the machine's canResendVerification is
	// true, and admin never sends that flag today, so this stays unreachable in
	// production. Wired against the endpoint name the fix's report specifies, so
	// wiring it up is the only step left once both planes ship their half.
	resendVerification: (opts) =>
		rawOnboardingCall("jarvis.onboarding.resend_verification_email", {}, opts),
};
export const isOnboarded = () => call("jarvis.account.is_onboarded");
// args: {provider, model, api_key, base_url, auth_mode, force}
export const saveLlmCreds = (args) => call("jarvis.onboarding.save_llm_creds", args);

// --- Per-account chat-subscription capture (paste-back OAuth) ---
// begin → { nonce, authorize_url, expires_in }; open authorize_url, sign in,
// paste the redirected URL back → complete captures the account (no side effects).
export const beginPoolAccountSignin = (provider, model) =>
	call("jarvis.oauth.api.begin_pool_account_signin", { provider, model });
// complete is capture-only → { capture_id, account_ref, label, account_email,
// provider, upstream }. The oauth blob NEVER crosses the wire (plan-05 D2): the
// server holds it under capture_id and merges it by account_ref at save time.
export const completePoolAccountSignin = (nonce, redirectedUrl) =>
	call("jarvis.oauth.api.complete_pool_account_signin", {
		nonce,
		redirected_url: redirectedUrl,
	});
// Claude Pro/Max signs in through the browser, the same shape xAI's bare-code
// paste uses: begin starts the official Claude CLI's own sign-in inside the
// tenant container and returns { login_id, authorize_url, expires_at }; the
// customer opens authorize_url, approves, and pastes the code Anthropic shows
// back. complete relays that code and captures the account (same capture-only
// shape as completePoolAccountSignin) - no token ever crosses the wire.
export const beginClaudeCliLogin = (model) =>
	call("jarvis.oauth.api.begin_claude_cli_login", { model });
export const completeClaudeCliLogin = (loginId, code) =>
	call("jarvis.oauth.api.complete_claude_cli_login", { login_id: loginId, code });
// Customer backed out before pasting a code: best-effort, tells fleet to kill
// the detached CLI login and drop its transcript.
export const cancelClaudeCliLogin = (loginId) =>
	call("jarvis.oauth.api.cancel_claude_cli_login", { login_id: loginId });
// Device-code (Kimi) capture: begin returns { device_flow:true, user_code,
// verification_uri, interval }; poll on `interval` → { status:"pending" } until
// the user approves, then the same capture-only { status:"ok", capture_id,
// account_ref, label, account_email, provider, upstream } (no oauth blob).
export const pollPoolAccountSignin = (nonce) =>
	call("jarvis.oauth.api.poll_pool_account_signin", { nonce });
// The current user's un-consumed, un-expired OAuth captures, so a reload (or the
// error-banner Retry that re-runs load()) rehydrates a just-connected account
// without a second sign-in (plan-05 D2). → { captures: [{ capture_id,
// account_ref, label, account_email, provider, upstream, expires_at }] }.
export const getPendingOauthCaptures = () => call("jarvis.oauth.api.list_pending_captures");
// Revoke + erase a pending capture server-side when the customer removes an
// unsaved just-connected account. → {}.
export const cancelPendingOauthCapture = (captureId) =>
	call("jarvis.oauth.api.cancel_pending_capture", { capture_id: captureId });

// --- DIRECT single chat-subscription (legacy flat-field path) ---------------
// Existing customers who onboarded a single chat subscription keep their creds
// in the flat llm_*/llm_oauth_* fields (NOT the models[] pool). get_llm_config
// can't see them, so AccountView probes this to decide whether to render the
// DIRECT re-authorize card instead of the pool editor. Returns
// { is_direct_subscription, connected, auth_mode, provider, model,
//   account_email, connected_at }.
export const getDirectSubscriptionStatus = () =>
	call("jarvis.oauth.api.get_direct_subscription_status");
// DIRECT paste-back re-authorize: begin → { ok, data:{nonce, authorize_url,
// expires_in} }; complete pushes the fresh blob to the container's
// auth-profiles.json + rewrites the flat fields (force restart). These write
// Jarvis Settings - unlike the pool "capture-only" variants above.
export const beginPasteSignin = (provider, model) =>
	call("jarvis.oauth.api.begin_paste_signin", { provider, model });
export const completePasteSignin = (nonce, redirectedUrl) =>
	call("jarvis.oauth.api.complete_paste_signin", { nonce, redirected_url: redirectedUrl });
// Tear down the direct subscription (clears the container profile + flat fields,
// flips bench back to api_key). Returns { ok } / { ok:false, error }.
export const disconnectSubscription = () => call("jarvis.oauth.api.disconnect");

// --- LLM Monitor (System-Manager gated server-side). Real Bifrost usage, NOT the getUsage estimate. ---
export const getLlmUsage = () => call("jarvis.account.get_llm_usage");
export const getLlmConnectionStatus = () => call("jarvis.account.get_llm_connection_status");
// The member-tier half of the same badge (jarvis#711). Returns ONLY { state },
// one of ok / applying / attention / down - no shape, no model or provider
// names, no profile ids, and no reason for "attention". Any workspace user may
// call it; an admin uses getLlmConnectionStatus above instead, which is a
// superset of this verdict.
export const getLlmConnectionHealth = () => call("jarvis.account.get_llm_connection_health");
export const getAccount = () => call("jarvis.account.get_account");
// BILLING plan lifecycle. Not to be confused with disconnectSubscription
// above, which drops the LLM PROVIDER subscription (ChatGPT/Claude OAuth).
// These end / restore the paid Jarvis plan itself.
export const cancelPlanAtPeriodEnd = () => call("jarvis.account.cancel_plan_at_period_end");
export const resumePlan = () => call("jarvis.account.resume_plan");
export const reauthorizeAutopay = () => call("jarvis.account.reauthorize_autopay");
// Past-Due pay-now, step one of two ("stop-autopay-to-pay"): neutralizes the
// customer's still-live Razorpay mandate so the EXISTING reactivation grid
// (can_reactivate) takes over for step two - this call never charges anything.
// Unlike renewPlan, every refusal here (FeatureDisabled/NotEligible/
// PAYMENT_UNDER_REVIEW/NoSubscription) is already reduced to a clean message by
// the bench's onboarding._surface() before it reaches the browser, so this rides
// the ordinary call() - no raw coded envelope to decode. Resolves {ok:true,
// outcome:"neutralized"|"already_dead"|"already_active"}; a refusal rejects.
export const stopAutopayToPay = () => call("jarvis.account.stop_autopay_to_pay");
export const previewDowngrade = (targetPlan) =>
	call("jarvis.account.preview_downgrade", { target_plan: targetPlan });
export const startDowngrade = (targetPlan) =>
	call("jarvis.account.start_downgrade", { target_plan: targetPlan });
export const cancelScheduledDowngrade = () => call("jarvis.account.cancel_scheduled_downgrade");
// The paying half of the billing page. preview_* prices the change so the
// customer sees the number BEFORE a payment sheet opens; start_* returns the
// gateway handles that sheet needs. Both were already whitelisted for the desk
// page and only lacked an SPA wrapper.
export const previewUpgrade = (targetPlan) =>
	call("jarvis.account.preview_upgrade", { target_plan: targetPlan });
export const startUpgrade = (targetPlan) =>
	call("jarvis.account.start_upgrade", { target_plan: targetPlan });
// Renewal mints its order through the onboarding endpoint, the same one the
// desk page called. Its Checkout result is confirmed by `finishPayment` above
// (declared with the onboarding wrappers), which is the single signature-verify
// endpoint for EVERY billing flow here, not just renewal and first signup.
// `targetPlan` reactivates a LAPSED subscription onto another plan (up or down)
// at that plan's full price; omitted, this is the plain same-plan renewal.
// RAW: renew answers a parked-money hold, a plan refusal or a rate limit as a
// CODED envelope under a 4xx. Those are answers about the payment and carry their
// own next action; call() would reduce them to a red sentence with nowhere to go.
// `targetPlan` is forwarded whenever it is supplied at all - an empty string is a
// caller bug and must reach admin's typed refusal, not be silently downgraded to a
// plain renewal that supersedes the attempt already in flight.
export const renewPlan = (targetPlan) =>
	rawOnboardingCall(
		"jarvis.onboarding.renew",
		targetPlan === undefined || targetPlan === null ? {} : { target_plan: targetPlan }
	);
// Renew's stuck-checkout recovery pair (unlike renewPlan above, these ARE in
// the account namespace). billingPaymentState is the passive read - re-echoes
// a live pay-page token so BillingPage can resume the SAME checkout instead of
// minting a second one. checkBillingPayment is the active healer: reconciles
// provider truth and never creates or replaces an intent.
export const billingPaymentState = () => call("jarvis.account.get_billing_payment_state");
// RAW, like its signup twin: the healer answers a rate limit or an under-review
// verdict as a CODED envelope under a deliberate 4xx. Those are answers about the
// payment, not transport errors, and call() would throw the code away.
export const checkBillingPayment = (opts) =>
	rawOnboardingCall("jarvis.account.check_billing_payment_status", {}, opts);

// GST invoices + billing details for the billing page (Phase 3b). getInvoices lists the
// customer's own invoices; downloadInvoice returns a base64 PDF (admin re-verifies ownership).
// getBillingProfile/updateBillingDetails drive the editable billing-details card (a partner-
// billed customer gets a read-only "billed through <partner>" and cannot edit).
export const getInvoices = () => call("jarvis.account.get_invoices");
export const downloadInvoice = (erpName) =>
	call("jarvis.account.download_invoice", { erp_name: erpName });
export const getBillingProfile = () => call("jarvis.account.get_billing_profile");
export const updateBillingDetails = (billing) =>
	call("jarvis.account.update_billing_details", { billing });

// File input: upload to Frappe's File doctype, return {file_url, file_name}.
export async function uploadFile(file) {
	const fd = new FormData();
	fd.append("file", file, file.name);
	fd.append("is_private", "1");
	const r = await fetch("/api/method/upload_file", {
		method: "POST",
		headers: { "X-Frappe-CSRF-Token": window.csrf_token || "" },
		body: fd,
		credentials: "include",
	});
	if (!r.ok) throw new Error(`upload failed (${r.status})`);
	const data = await r.json();
	const f = data.message || data;
	return { file_url: f.file_url, file_name: f.file_name || file.name };
}

// Branding logo/favicon: PUBLIC file (the favicon <link> and the PWA manifest
// must fetch it without a session cookie), unlike the private uploadFile above.
export async function uploadBrandAsset(file) {
	const fd = new FormData();
	fd.append("file", file, file.name);
	fd.append("is_private", "0");
	const r = await fetch("/api/method/upload_file", {
		method: "POST",
		headers: { "X-Frappe-CSRF-Token": window.csrf_token || "" },
		body: fd,
		credentials: "include",
	});
	if (!r.ok) throw new Error(`upload failed (${r.status})`);
	const data = await r.json();
	const f = data.message || data;
	return { file_url: f.file_url, file_name: f.file_name || file.name };
}

// ── File Box: drop an inbound document, get a directed processing chat ──
export const fileboxDrop = (file_url, file_name) =>
	call("jarvis.chat.filebox.drop_file", { file_url, file_name });
export const fileboxList = () => call("jarvis.chat.filebox.list_inbound", {});

// ── Approvals: pending-decision queue + decide-and-resume ──
export const listApprovals = (status = "Pending") =>
	call("jarvis.chat.approvals_api.list_approvals", { status });
export const approvalsPendingCount = () => call("jarvis.chat.approvals_api.pending_count", {});
export const decideApproval = (name, decision, approve = 1) =>
	call("jarvis.chat.approvals_api.decide", { name, decision, approve });
// Ignore a request off the board (no verdict, no chat resume); reversible.
export const dismissApproval = (name) =>
	call("jarvis.chat.approvals_api.dismiss_approval", { name });
export const restoreApproval = (name) =>
	call("jarvis.chat.approvals_api.restore_approval", { name });

// ── Agents Marketplace: catalog, install/enable/schedule, apply, runs+findings ──
// enable/disable + schedule + config are INSTANT (pure DB writes). Apply is the
// only call that reconciles the container (install/uninstall/update → restart),
// polled via getAgentsSyncStatus exactly like the custom-skills apply pill.
const AG = "jarvis.chat.agents_api.";
export const listAgents = () => call(AG + "list_agents");
export const getAgentInstallations = () => call(AG + "get_installations");
export const installAgent = (agent_slug) => call(AG + "install_agent", { agent_slug });
export const uninstallAgent = (installation) => call(AG + "uninstall_agent", { installation });
export const setAgentEnabled = (installation, enabled) =>
	call(AG + "set_enabled", { installation, enabled: enabled ? 1 : 0 });
export const setAgentSchedule = (installation, p) =>
	call(AG + "set_schedule", { installation, ...(p || {}) });
// Engagement config JSON (benchmark_value, percentage, engagement_risk_level,
// rounding_step) read by the agent on its installation.
export const setAgentConfig = (installation, config) =>
	call(AG + "set_config", { installation, config: JSON.stringify(config || {}) });
// options: per-launch payload. `source_apps` (array of app names) is REQUIRED for
// the custom-app-learning agent - the server refuses the launch without an
// explicit selection and stamps it as the run's source-read authorization.
export const runAgentNow = (installation, options) =>
	call(AG + "run_agent_now", {
		installation,
		...(options ? { options: JSON.stringify(options) } : {}),
	});
export const applyAgents = () => call(AG + "apply_agents");
export const getAgentsSyncStatus = () => call(AG + "get_agents_sync_status");
export const listAgentRuns = (agent, limit) =>
	call(AG + "list_runs", { agent: agent || "", limit: limit || 50 });
export const listAgentFindings = (p) => call(AG + "list_findings", p || {});
export const setFindingState = (finding, state) =>
	call(AG + "set_finding_state", { finding, state });
// Listing admin (System Manager only - the server enforces it; the SPA merely
// probes getAgentAdminOverview and hides the Admin tab on 403). Access gating
// moved to api/agents.setAgentAccess (jarvis#1062), which sets roles and named
// users together; the set_agent_roles ENDPOINT survives as a compat shim for
// cached older SPA builds, but nothing in this build calls it.
export const setListingStatus = (agent_slug, status) =>
	call(AG + "set_listing_status", { agent_slug, status });
export const getAgentAdminOverview = () => call(AG + "get_agent_admin_overview");

// ── Paginated feature-page lists (design §2.7) ──────────────────────────────
// One frozen envelope for all four features:
//   { rows, total, has_more, start, page_length[, facets] }  (facets: Approvals only;
//   Approvals first-page responses also carry `awaiting_reply` — chat questions
//   with no approval row behind them, rendered by ApprovalsBoard's strip)
// Request args (search/filters/sort/paging + filters_v2) come from the ONE
// shared encoder `api/listPageArgs.js` (plan 08 P0-01) — imported as `_page` so
// Skills/Macros/File Box/Approvals and the feature wrappers cannot drift apart.

// plan 08 §6.1: the fields THIS caller may filter `view_key` on, with the
// per-field operators and defaults. Answers only for MIGRATED views; every
// rejection carries a stable `list_filter_*` code (see filterModel.js).
export const getListFilterSchema = (viewKey) =>
	call("jarvis.chat.list_filters.get_list_filter_schema", { view_key: viewKey });
// plan 08 §P1-05 / M1.3: the per-view {view_key: enabled} capability map, so a
// list can learn whether filters_v2 is on for its view BEFORE emitting any clause
// (a rolled-back view must send zero filters_v2 on every path). Cheap — the flag
// map only, no field catalog.
export const getListFilterCapabilities = () =>
	call("jarvis.chat.list_filters.list_filters_capabilities");
export const listCustomSkillsPage = (p) => call(SK + "list_custom_skills_page", _page(p));
export const listMacrosPage = (p) => call(MC + "list_macros_page", _page(p));
export const fileboxListPage = (p) => call("jarvis.chat.filebox.list_inbound_page", _page(p));
export const listApprovalsPage = (p) =>
	call("jarvis.chat.approvals_api.list_approvals_page", _page(p));

// ── File Box FB-1: cascade delete + clear-processed + bulk delete (Q4) ──────
// delete_inbound: owner-gated cascade (approvals + messages + File docs + the
// conversation); refuses while the latest assistant message is streaming.
export const fileboxDelete = (conversation) =>
	call("jarvis.chat.filebox.delete_inbound", { conversation });
// clear_processed_inbound: bulk-delete the caller's done|error rows → {ok, deleted}.
export const fileboxClearProcessed = () => call("jarvis.chat.filebox.clear_processed_inbound");
// delete_inbound_bulk (Q4): same cascade + streaming-refusal per row → {deleted, skipped}.
// List JSON-encoded for parity with the other list-argument wrappers.
export const fileboxDeleteBulk = (conversations) =>
	call("jarvis.chat.filebox.delete_inbound_bulk", {
		conversations: JSON.stringify(conversations || []),
	});

// --- MCP Connectors (MCP_CONNECTORS_PLAN.md P4; broker + SSRF guard live
// entirely server-side in jarvis.connectors, this is just the SPA's thin CRUD
// + test-probe surface). All eleven calls run @require_jarvis_user and re-check
// row permissions server-side (jarvis.chat.connector_permissions) regardless
// of what the client believes about scope/role. ---
const CN = "jarvis.chat.connectors_api.";
// {oauth_redirect_uri, catalog, shared:[row], mine:[row]}.
export const listConnectors = () => call(CN + "list_connectors");
// p = {label, preset, base_url, scope, credential, auth_method?, enabled?,
// key?}. Presets other than "Custom URL" ignore base_url server-side (pinned
// to the vendor endpoint). enabled defaults to 1 server-side; the dialog
// always passes 0 when creating from a connect press (F8) so a row nobody
// has finished setting up isn't visible to anyone else until Save (step 2)
// flips it back on.
export const addConnector = (p) => call(CN + "add_connector", p);
// Runs a live initialize + tools/list through the broker; on success writes
// tools_cache + merges allowed_actions. {ok, tools:[...]} | {ok:false, error}.
export const testConnector = (name) => call(CN + "test_connector", { name });
// actions: [{action, allowed}] - JSON-stringified like every other list/dict
// param this codebase posts through call() (see personalise_api's payload
// convention); read_only/destructive are always server-recomputed, never
// trusted from here.
export const setConnectorAllowedActions = (name, actions) =>
	call(CN + "set_allowed_actions", { name, actions: JSON.stringify(actions || []) });
// p = {label?, base_url?, credential?, enabled?}. base_url only takes effect
// on a Custom URL connector; a blank/omitted credential means "keep the saved
// one" - the SPA never round-trips the real secret back to resubmit it.
export const updateConnector = (name, p) => call(CN + "update_connector", { name, ...(p || {}) });
export const deleteConnector = (name) => call(CN + "delete_connector", { name });
// OAuth tier: {ok, url, started_at} to redirect the browser to, or {ok:false, error}.
// The return trip is handled by connectors_api.mcp_oauth_callback for every row.
export const connectOauth = (name) => call(CN + "connect_oauth", { name });
// Poll target for oauthSignin.js's tab flow: {ok, connected, connected_at, error}.
// `error` is one-shot - the server clears it once this has read it.
export const oauthSigninStatus = (name) => call(CN + "oauth_signin_status", { name });
// Deletes the CURRENT user's sign-in for this connector. Idempotent.
export const disconnectOauth = (name) => call(CN + "disconnect_oauth", { name });
// Checks whether an address needs a sign-in, WITHOUT creating anything - call it
// before addConnector so the user can be shown where they would sign in.
// {ok, needs_signin, signin_host, registration, scopes} | {ok:false, error}.
export const probeConnectorAuth = (base_url) => call(CN + "probe_connector_auth", { base_url });
// Admin only, and only for a connector whose row reports needs_static_client:
// the id/secret an admin got by registering this workspace at the provider
// (against the row's oauth_redirect_uri). A blank secret keeps the stored one.
export const setOauthClientCredentials = (name, client_id, client_secret) =>
	call(CN + "set_oauth_client_credentials", {
		name,
		client_id,
		client_secret: client_secret || "",
	});

// --- Support panel (Plan 3) -------------------------------------------------
export const supportListTickets = () => call("jarvis.support.api.list_tickets");
export const supportCreateTicket = (subject, body) =>
	call("jarvis.support.api.create_ticket", { subject, body: body || "" });
export const supportGetThread = (ticket) => call("jarvis.support.api.get_thread", { ticket });
export const supportReply = (ticket, body) => call("jarvis.support.api.reply", { ticket, body });
export const supportCloseTicket = (ticket) => call("jarvis.support.api.close_ticket", { ticket });
export const supportAwaitingCount = () => call("jarvis.support.api.awaiting_count");

// Same-origin GET so <img>/<a> resolve against the bench; session cookie authenticates.
export const supportDownloadUrl = (ticket, fileUrl) =>
	`/api/method/jarvis.support.media.download?ticket=${encodeURIComponent(
		ticket
	)}&file_url=${encodeURIComponent(fileUrl)}`;

// Pull the human reason out of a Frappe error response the way frappe-ui's
// `call()` does (it parses `_server_messages` the same way), so errMsg() in
// the support store shows "file too large" / "no file provided" rather than
// a generic status-code string.
function _uploadErrorMessage(data, status) {
	try {
		if (data && data._server_messages) {
			const msgs = JSON.parse(data._server_messages);
			const first = typeof msgs[0] === "string" ? JSON.parse(msgs[0]) : msgs[0];
			if (first && first.message) return String(first.message);
		}
	} catch (e) {
		/* fall through to the status code */
	}
	return `upload failed (${status})`;
}

export async function supportUpload(ticket, file, comm) {
	const fd = new FormData();
	fd.append("ticket", ticket);
	// Attach to the reply Communication (when given) so Helpdesk renders the file inline; a
	// ticket-level File only shows in the sidebar. Appended before the file, so the multipart
	// scalar fields precede the binary part.
	if (comm) fd.append("comm", comm);
	fd.append("file", file, file.name);
	const r = await fetch("/api/method/jarvis.support.media.upload", {
		method: "POST",
		headers: { "X-Frappe-CSRF-Token": window.csrf_token || "" },
		body: fd,
		credentials: "include",
	});
	if (!r.ok) {
		const data = await r.json().catch(() => null);
		throw new Error(_uploadErrorMessage(data, r.status));
	}
	const data = await r.json();
	const msg = data.message || data;
	return msg.data || msg;
}
