"""
Single Instance Manager for JARVIS

This module ensures that only one instance of JARVIS runs at a time.
When the user clicks the JARVIS icon again, the existing window is brought
to focus instead of creating a new window.

Uses a socket-based approach that works cross-platform (Windows, macOS, Linux).
"""

import socket
import json
import sys
import os
import time
from pathlib import Path

# Port for IPC communication
JARVIS_IPC_PORT = 19999
JARVIS_IPC_HOST = "127.0.0.1"
IPC_TIMEOUT = 2  # seconds

# Lockfile path
def get_lockfile_path():
    """Get the path to the lockfile that stores the port number."""
    if getattr(sys, "frozen", False):
        base_dir = Path(sys.executable).parent
    else:
        base_dir = Path(__file__).resolve().parent
    return base_dir / ".jarvis_lock"


class SingleInstanceManager:
    """
    Manages single-instance enforcement for JARVIS.
    
    On first run: starts the IPC server
    On subsequent runs: connects to existing instance and signals it
    """
    
    def __init__(self):
        self.is_primary = False
        self.server_socket = None
        self.port = JARVIS_IPC_PORT
        
    def start_server(self):
        """Start the IPC server (primary instance only)."""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((JARVIS_IPC_HOST, self.port))
            self.server_socket.listen(5)
            self.server_socket.settimeout(0.1)  # Non-blocking
            self.is_primary = True
            self._write_lockfile()
            print(f"[JARVIS] Primary instance started (IPC on port {self.port})")
            return True
        except (OSError, socket.error) as e:
            print(f"[JARVIS] Could not start IPC server: {e}")
            return False
    
    def try_connect_to_existing(self):
        """Try to connect to an existing JARVIS instance."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(IPC_TIMEOUT)
            sock.connect((JARVIS_IPC_HOST, JARVIS_IPC_PORT))
            
            # Send "focus" signal to bring window to front
            message = {"action": "focus", "timestamp": time.time()}
            sock.send(json.dumps(message).encode("utf-8"))
            sock.close()
            print("[JARVIS] Connected to existing instance - signaling focus")
            return True
        except (ConnectionRefusedError, socket.timeout, OSError):
            return False
    
    def _write_lockfile(self):
        """Write lock file with port number."""
        try:
            lockfile = get_lockfile_path()
            lockfile.write_text(str(self.port), encoding="utf-8")
        except Exception as e:
            print(f"[JARVIS] Warning: Could not write lockfile: {e}")
    
    def _read_lockfile(self):
        """Read port number from lock file."""
        try:
            lockfile = get_lockfile_path()
            if lockfile.exists():
                return int(lockfile.read_text(encoding="utf-8").strip())
        except Exception:
            pass
        return JARVIS_IPC_PORT
    
    def check_and_acquire(self):
        """
        Check if another instance is running.
        Returns True if this should be the primary instance.
        Returns False if another instance is running (should exit).
        """
        # Try to connect to existing instance
        if self.try_connect_to_existing():
            return False
        
        # Try to become the primary instance
        if self.start_server():
            return True
        
        # Could not start server and could not connect - uncertain state
        # Allow startup (better to have duplicate than none)
        return True
    
    def accept_connection(self):
        """
        Accept a single IPC connection (non-blocking).
        Returns message dict if received, None otherwise.
        """
        if not self.server_socket:
            return None
        
        try:
            client_socket, _ = self.server_socket.accept()
            client_socket.settimeout(1)
            data = client_socket.recv(4096).decode("utf-8")
            client_socket.close()
            
            if data:
                return json.loads(data)
        except socket.timeout:
            pass
        except (json.JSONDecodeError, OSError):
            pass
        
        return None
    
    def cleanup(self):
        """Clean up IPC resources."""
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception:
                pass
        
        # Remove lockfile
        try:
            lockfile = get_lockfile_path()
            if lockfile.exists():
                lockfile.unlink()
        except Exception:
            pass


def ensure_single_instance():
    """
    Ensure only one JARVIS instance runs.
    Call this at the very start of main().
    
    Returns: SingleInstanceManager instance (for accepting focus signals)
    """
    manager = SingleInstanceManager()
    
    if not manager.check_and_acquire():
        # Another instance is already running
        print("[JARVIS] Another instance is already running. Exiting...")
        sys.exit(0)
    
    return manager
