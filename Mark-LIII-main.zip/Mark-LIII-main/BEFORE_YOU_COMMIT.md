# ✅ BEFORE YOU COMMIT — SAFEGUARD CHECKLIST

**Read this before every commit!**

---

## 🚨 THE ONE RULE THAT MATTERS

> **NEVER delete or remove a feature without explicit confirmation.**

---

## ✅ Pre-Commit Checklist

### 1️⃣ What Changed?
- [ ] I can list all files I modified
- [ ] I can list all files I deleted (should be ZERO)
- [ ] I can list all new files I added
- [ ] Each change has a clear reason

### 2️⃣ Did I Delete Anything?
- [ ] No files were deleted
- [ ] If yes: I have documented WHY and got confirmation
- [ ] If yes: User impact is acceptable
- [ ] If yes: There's an alternative or migration path

### 3️⃣ Testing — Does Everything Still Work?
- [ ] Jarvis starts without errors
- [ ] LLM connection works (Ollama/LM Studio)
- [ ] Speech input/output working
- [ ] Background monitoring active

### 4️⃣ Feature Tests (Run These)
- [ ] Web search works (or expected to fail if offline)
- [ ] File operations work (create, read, delete files)
- [ ] App launcher works (open an app)
- [ ] System control works (check CPU, adjust volume)
- [ ] Reminders work (set and verify)
- [ ] Automations work (create and trigger a rule)
- [ ] Desktop control works (change display settings)
- [ ] Code helper works (ask for code help)

### 5️⃣ No Accidental Changes
- [ ] No debug code left behind
- [ ] No commented-out features
- [ ] No console.log/print statements for debugging
- [ ] No unused imports
- [ ] No broken links in comments
- [ ] No API keys or secrets in code

### 6️⃣ Documentation
- [ ] CHANGELOG updated (if this is a release)
- [ ] README updated (if needed)
- [ ] Comments added for complex changes
- [ ] No outdated comments

### 7️⃣ Commit Message
- [ ] Commit message explains WHAT changed
- [ ] Commit message explains WHY
- [ ] No generic messages like "fixes", "update", "cleanup"

---

## 📋 Commit Message Template

```
[TYPE] Brief description (50 chars max)

Longer explanation here (if needed).

Files changed:
- file1.py: What changed
- file2.py: What changed

Features tested:
- ✓ Web search
- ✓ File operations
- ✓ Reminders
- ✓ Automations

Breaking changes: None
Migration needed: No
```

### Commit Types:
```
[FEATURE]   = New capability added (no deletions)
[FIX]       = Bug fixed (no deletions)
[IMPROVE]   = Existing feature enhanced (no deletions)
[DOCS]      = Documentation only
[REFACTOR]  = Code reorganized (no behavior change, no deletions)
[PERF]      = Performance improvement
[SECURITY]  = Security fix
```

### Examples:

✅ GOOD:
```
[FEATURE] Add automation rules UI in dashboard

- Added quick-action button bar to dashboard/static/app.html
- Users can trigger saved automations from web dashboard
- Fallback styling for mobile devices

Features tested:
- ✓ Dashboard loads without errors
- ✓ Quick buttons responsive on mobile
- ✓ Automation triggering works
- ✓ All existing features intact

No features deleted.
```

❌ BAD:
```
update ui
```

❌ BAD:
```
[REFACTOR] Clean up old code

Deleted: actions/web_search.py
Reason: Not using it
```

---

## 🗑️ IF You're Deleting Something

### Step 1: Document It
```
Feature: [Name of feature being removed]
File: [Which file(s)]
Used for: [What did users do with it?]
Why delete: [Reason it must go]
Alternative: [Is there another way to do this?]
Impact: [How many users affected?]
Migration: [What do users do now?]
Timestamp: [When removed]
Approval: [Who approved this deletion?]
```

### Step 2: Get Permission
You MUST get explicit approval before deleting anything.

### Step 3: Document in CHANGELOG
```markdown
### Removed
- web_search.py: Removed web search capability
  Reason: Incompatible with new LLM API
  Migration: Use browser_control instead to access search engines
  Impact: Users can still search via browser
  Alternative: Local LLM provides knowledge for common queries
```

### Step 4: Create Migration Guide
Provide users with clear steps for what to do instead.

---

## 🔍 Red Flags (Stop and Rethink)

If you see any of these, STOP before committing:

🚩 You deleted a file but aren't sure what it was for  
→ **Don't delete it.** Ask first.

🚩 Multiple features broken after your changes  
→ **Something went wrong.** Revert and debug.

🚩 You disabled a feature "temporarily"  
→ **Don't do this in production.** Use feature flags or version it properly.

🚩 You have a bunch of deleted lines without documentation  
→ **Document why before committing.**

🚩 You changed something and now tests are failing  
→ **Fix the issue, don't delete the test.**

🚩 You're committing "just to push it up"  
→ **Make sure it actually works first.**

---

## 💾 Backup Steps (Do This First!)

```bash
# 1. Create a backup branch
git checkout -b backup-$(date +%Y%m%d-%H%M%S)

# 2. Make your changes on the backup branch first
# (Edit files, test everything)

# 3. If everything works, cherry-pick or merge to main

# Or manually:
cp -r Mark-LIII-main Mark-LIII-main.backup-$(date +%Y%m%d)
```

---

## 🧪 How to Test Before Committing

### Quick Test:
```bash
python main.py &
# Let it start...
# Test voice input: "What's the weather?"
# Test file operations: "Open my documents folder"
# Test automation: "Set up a new automation rule"
# Check for errors in console
```

### Full Test (All 20 Actions):
```
✓ background_monitor    - Background processes visible
✓ browser_control       - Browser opens and loads sites
✓ code_helper           - Code analysis works
✓ computer_control      - Can lock/unlock screen
✓ computer_settings     - Can adjust brightness/volume
✓ desktop               - Can open apps
✓ dev_agent             - Development assistance works
✓ file_controller       - Can navigate file system
✓ file_processor        - Can process documents
✓ flight_finder         - Flight search works (if internet)
✓ game_updater          - Can check game updates
✓ open_app              - Applications launch
✓ proactive             - Suggestions appear
✓ reminder              - Can set and trigger reminders
✓ screen_processor      - Can capture screen
✓ send_message          - Can compose messages
✓ system_monitor        - System stats visible
✓ weather_report        - Weather lookup works (if internet)
✓ web_search            - Web search works (if internet)
✓ youtube_video         - YouTube control works (if internet)
```

---

## 📝 CHANGELOG Template

When releasing a version:

```markdown
## [2026-09-18] - Version X.X

### Added
- New feature A (code details)
- New feature B (code details)

### Changed
- Modified feature C (what changed and why)
- Updated feature D

### Fixed
- Bug in feature E (what was broken, how fixed)

### Removed
- None (or if yes, detailed explanation)

### Security
- Fixed vulnerability in X

### Verified ✓
- ✓ All 20 actions working
- ✓ No features removed
- ✓ Backward compatible
- ✓ Tested on Windows/macOS/Linux

### Migration Notes
- None (if breaking changes: detailed steps)

### Breaking Changes
- None (or details if yes)
```

---

## 🚀 Final Checklist Before Pushing

- [ ] All tests pass
- [ ] No debug code
- [ ] No commented code
- [ ] Commit message is descriptive
- [ ] CHANGELOG updated (if applicable)
- [ ] No files accidentally deleted
- [ ] Backup created
- [ ] README/docs updated (if needed)
- [ ] Ready to share with others

---

## 🆘 "Oh No, I Messed Up!"

### If you deleted something by mistake:
```bash
git checkout HEAD~1 -- <filename>
# or
git log --diff-filter=D --summary | grep delete
git checkout <commit>^ -- <filename>
```

### If you broke something:
```bash
git diff HEAD  # See what changed
git stash      # Temporarily hide changes
# (test if it works now)
git stash pop  # Bring back your changes
```

### If you're not sure:
```bash
git status                    # See all changes
git diff                      # See exactly what changed
git log --oneline -10         # See recent commits
git branch                    # See what branch you're on
```

---

## 📚 More Info

Read the full policies:
- `FEATURE_PROTECTION_POLICY.md` — Detailed safeguard rules
- `JARVIS_CONNECTIVITY_ANALYSIS.md` — What works offline
- `MARK_LIII_ANALYSIS.md` — Feature inventory
- `readme.md` — Original documentation

---

## ⭐ Golden Rule

**Before you commit, ask yourself:**

1. Did I delete anything? (It better not be!)
2. Do all the features still work?
3. Can I explain my changes clearly?
4. Would I want someone else to make these changes to MY code?

If you answered "no" to any of these → **Fix it before committing.**

---

**Remember:** Every line you delete removes something someone depends on. Be careful. Be intentional. Be safe. ✅
