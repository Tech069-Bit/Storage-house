"""
Offline fallback assistant — voice in, voice out, still learns, no internet.

Used automatically by main.py's _run_offline_loop when the network light is
orange/red (see core/network_monitor.py) instead of leaving the mic dead and
giving no response at all. Three local pieces, all already shipped in this
project as core/stt.py, core/llm_client.py and core/tts.py from an earlier
architecture — this module is what actually wires them together:

  Listen  - WhisperSTT (core/stt.py), with a simple energy-gated recorder:
            starts recording once the mic goes louder than the ambient floor,
            stops after a short silence, transcribes the clip. Falls back to
            Vosk if Whisper's model files were never downloaded (both need a
            one-time internet download the first time; after that they're
            fully local).
  Think   - a local LLM via Ollama or any OpenAI-compatible local server
            (core/llm_client.py — LM Studio, Jan, LocalAI, llama.cpp server,
            etc.), given the SAME long-term memory context the online
            assistant uses (memory/memory_manager.py) plus a short rolling
            history of just this offline conversation.
  Learn   - if the local model supports tool/function calling, it can call
            save_memory exactly like the online model does, straight into
            the SAME memory/long_term.json — nothing about where memories
            live changes just because the network is down. A model without
            tool support simply doesn't learn mid-offline-conversation; it
            still converses using whatever is already stored.
  Speak   - Kokoro (core/tts.py) — the only bundled TTS engine that doesn't
            itself need the internet (EdgeTTS and ElevenLabs both do), so
            it's used here regardless of the user's online TTS preference.

Nothing here is a full replacement for the Live API: no barge-in, no vision,
and answer quality depends entirely on whatever local model is installed
(requires Ollama, or another local OpenAI-compatible server, actually
running — see core/llm_client.py's docstring for setup). It exists so JARVIS
never goes completely silent just because the internet did.
"""
from __future__ import annotations

import numpy as np
import sounddevice as sd

from core import llm_client
from memory.memory_manager import load_memory, update_memory, format_memory_for_prompt

SEND_SAMPLE_RATE = 16000

_VALID_CATEGORIES = {"identity", "preferences", "projects", "relationships", "wishes", "notes"}

_SAVE_MEMORY_TOOL = {
    "type": "function",
    "function": {
        "name": "save_memory",
        "description": "Save a durable fact about the user for later conversations.",
        "parameters": {
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "enum": sorted(_VALID_CATEGORIES),
                },
                "key":   {"type": "string", "description": "Short snake_case identifier."},
                "value": {"type": "string", "description": "Concise value in English."},
            },
            "required": ["category", "key", "value"],
        },
    },
}


class OfflineAssistant:
    """One instance per offline stretch — built lazily (loading Whisper/Kokoro
    takes real time) and discarded once the connection comes back."""

    def __init__(self, assistant_name: str = "JARVIS", language_hint: str | None = None):
        self.assistant_name = (assistant_name or "JARVIS").strip() or "JARVIS"
        self._history: list[dict] = []   # rolling chat turns for this offline stretch
        self._stt = self._build_stt(language_hint)
        self._tts = self._build_tts()

    # ── Setup ────────────────────────────────────────────────────────────────

    def _build_stt(self, language_hint):
        try:
            from core.stt import WhisperSTT
            return WhisperSTT(model_name="base", language=language_hint)
        except Exception as e:
            print(f"[Offline] Whisper unavailable ({e}) — trying Vosk…")
            from core.stt import VoskSTT
            return VoskSTT(language=language_hint or "en-us")

    def _build_tts(self):
        from core.tts import create_tts_player
        return create_tts_player({"tts_engine": "kokoro"})

    # ── Listen ───────────────────────────────────────────────────────────────

    def listen_once(self, max_seconds: float = 12.0, silence_ms: int = 900,
                     level_threshold: float = 0.03) -> str:
        """Blocking. Waits for the mic to go louder than level_threshold, keeps
        recording until a short silence follows, then transcribes the clip.
        Returns "" for silence/timeout/error — never raises just because
        nobody spoke."""
        chunk_frames  = 1024
        chunks: list[np.ndarray] = []
        speaking      = False
        silence_run   = 0
        silence_limit = max(1, int(silence_ms / 1000 * SEND_SAMPLE_RATE / chunk_frames))
        max_iters     = max(1, int(max_seconds * SEND_SAMPLE_RATE / chunk_frames))

        try:
            with sd.InputStream(samplerate=SEND_SAMPLE_RATE, channels=1,
                                 dtype="float32", blocksize=chunk_frames) as stream:
                for _ in range(max_iters):
                    data, _ = stream.read(chunk_frames)
                    level = float(np.sqrt(np.mean(np.square(data)))) if data.size else 0.0
                    if level >= level_threshold:
                        speaking    = True
                        silence_run = 0
                        chunks.append(data.copy())
                    elif speaking:
                        silence_run += 1
                        chunks.append(data.copy())
                        if silence_run >= silence_limit:
                            break
                    # else: quiet and nobody has spoken yet — keep waiting
        except Exception as e:
            print(f"[Offline] Mic error: {e}")
            return ""

        if not chunks:
            return ""

        audio = np.concatenate(chunks, axis=0).flatten().astype(np.float32)
        try:
            if hasattr(self._stt, "transcribe"):
                return (self._stt.transcribe(audio) or "").strip()
            # VoskSTT's streaming API — feed the whole clip as one chunk.
            pcm16 = (audio * 32767).astype(np.int16).tobytes()
            text, _ = self._stt.process_chunk(pcm16)
            return (text or "").strip()
        except Exception as e:
            print(f"[Offline] Transcription failed: {e}")
            return ""

    # ── Think ────────────────────────────────────────────────────────────────

    def respond(self, user_text: str) -> str:
        memory_block = format_memory_for_prompt(load_memory())
        system = (
            f"You are {self.assistant_name}, a helpful voice assistant currently "
            "running fully OFFLINE on the user's own computer because the "
            "internet — or your usual AI service — is unreachable right now. "
            "Say so naturally if it's relevant, but don't dwell on it. Keep "
            "replies short and conversational, since this is spoken out loud. "
            "If the user shares a durable fact worth remembering (name, "
            "preference, project, relationship, etc.), call save_memory.\n\n"
            + memory_block
        )
        messages = [{"role": "system", "content": system}, *self._history,
                    {"role": "user", "content": user_text}]

        try:
            result = llm_client.call_llm(messages, tools=[_SAVE_MEMORY_TOOL])
        except Exception as e:
            return (f"I can't reach my usual AI service, and I couldn't reach "
                    f"a local one either — {e}")

        for call in (result.get("tool_calls") or []):
            try:
                fn   = call.get("function", {}) or {}
                args = fn.get("arguments", {}) or {}
                if fn.get("name") != "save_memory" or not isinstance(args, dict):
                    continue
                cat = str(args.get("category", "notes")).strip().lower()
                key = str(args.get("key", "")).strip().lower().replace(" ", "_")
                val = str(args.get("value", "")).strip()
                if cat not in _VALID_CATEGORIES:
                    cat = "notes"
                if key and val:
                    update_memory({cat: {key: {"value": val}}})
            except Exception as e:
                print(f"[Offline] save_memory tool call failed: {e}")

        reply = (result.get("content") or "").strip() or \
            "I didn't catch that clearly — could you say it again?"

        self._history.append({"role": "user",      "content": user_text})
        self._history.append({"role": "assistant",  "content": reply})
        self._history = self._history[-12:]   # keep the local model's context small and fast
        return reply

    # ── Speak ────────────────────────────────────────────────────────────────

    def speak(self, text: str) -> None:
        if text and text.strip():
            self._tts.speak(text)
