"""
Work / task queue — "give JARVIS something to work on".

Lets the user hand off a piece of work in natural language ("build me a
snake game", "research flight prices to Tokyo and summarize them", "organize
my Downloads folder") instead of it only being able to act on things said to
it live. Tasks are stored here; main.py's background task worker
(_run_task_worker) picks up pending ones once the assistant is idle — not
mid-conversation — and replays the task description into the live session as
a normal user turn, so it's solved with whatever real tools already exist
(dev_agent, browser_control, file_controller, web_search, etc.). This module
only owns storage; it never executes anything itself.

Stored locally in config/tasks.json — never synced, never sent anywhere. Not
committed to git (see .gitignore).
"""
from __future__ import annotations

import json
import sys
import time
import uuid
from pathlib import Path


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


_TASKS_PATH   = _base_dir() / "config" / "tasks.json"
_MAX_TASKS    = 50    # open (non-done) tasks at once
_MAX_DESC_LEN = 500

_STATUS_MARK = {"pending": "○", "in_progress": "◐", "done": "●", "failed": "✕"}


def load_tasks() -> list[dict]:
    try:
        data = json.loads(_TASKS_PATH.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return data
    except Exception:
        pass
    return []


def _save_tasks(tasks: list[dict]) -> None:
    try:
        _TASKS_PATH.parent.mkdir(parents=True, exist_ok=True)
        _TASKS_PATH.write_text(
            json.dumps(tasks, indent=2, ensure_ascii=False), encoding="utf-8"
        )
    except Exception as e:
        print(f"[Tasks] ⚠️  Could not save tasks: {e}")


def add_task(description: str) -> str:
    description = (description or "").strip()[:_MAX_DESC_LEN]
    if not description:
        return "I need a description of the work before I can add it."

    tasks = load_tasks()
    open_count = len([t for t in tasks if t.get("status") != "done"])
    if open_count >= _MAX_TASKS:
        return f"You already have {_MAX_TASKS} open tasks — clear some before adding more."

    tasks.append({
        "id":          uuid.uuid4().hex[:8],
        "description": description,
        "status":      "pending",   # pending -> in_progress -> done | failed
        "created":     time.time(),
        "result":      "",
    })
    _save_tasks(tasks)
    return (f"Added to your task list: \"{description}\". "
            f"I'll pick it up in the background once we're not mid-conversation.")


def list_tasks_text() -> str:
    tasks = load_tasks()
    if not tasks:
        return "You don't have any tasks queued."
    lines = []
    for t in tasks:
        status = t.get("status", "pending")
        mark = _STATUS_MARK.get(status, "?")
        line = f"{mark} [{status}] {t.get('description', '')}"
        if status == "failed" and t.get("result"):
            line += f" — {t['result']}"
        lines.append(line)
    return "Your tasks:\n" + "\n".join(lines)


def _find(tasks: list[dict], key: str) -> dict | None:
    key = key.strip().lower()
    for t in tasks:
        if t.get("id", "").lower() == key:
            return t
    for t in tasks:
        if key and key in t.get("description", "").lower():
            return t
    return None


def complete_task(task_id_or_text: str) -> str:
    tasks = load_tasks()
    t = _find(tasks, task_id_or_text or "")
    if t is None:
        return "I couldn't find a task matching that."
    t["status"] = "done"
    _save_tasks(tasks)
    return f"Marked \"{t.get('description')}\" as done."


def remove_task(task_id_or_text: str) -> str:
    tasks = load_tasks()
    t = _find(tasks, task_id_or_text or "")
    if t is None:
        return "I couldn't find a task matching that."
    tasks = [x for x in tasks if x is not t]
    _save_tasks(tasks)
    return f"Removed \"{t.get('description')}\" from your task list."


def next_pending_task() -> dict | None:
    for t in load_tasks():
        if t.get("status") == "pending":
            return t
    return None


def set_task_status(task_id: str, status: str, result: str = "") -> None:
    tasks = load_tasks()
    for t in tasks:
        if t.get("id") == task_id:
            t["status"] = status
            if result:
                t["result"] = result[:_MAX_DESC_LEN]
            break
    _save_tasks(tasks)
