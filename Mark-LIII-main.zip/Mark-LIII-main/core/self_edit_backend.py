"""
Self-modification backend — lets JARVIS edit its OWN source code on request.

Design goals, in order of importance:

  1. Nothing is ever overwritten without the on-screen CONFIRM gate in
     core/confirm.py — the same gate that guards shutdown/delete. The model
     can propose an edit; only a human pressing CONFIRM makes it real. See
     plugins/self_edit.py, which is what actually calls confirm.request().

  2. Every edit keeps a timestamped backup, and undo_last() can put a file
     back exactly as it was — including undoing an undo, since undoing also
     backs up whatever was current first.

  3. Only files inside this project, under an explicit allow-list of code
     locations, can be touched — no path escaping BASE_DIR, and never the
     data/config files (api keys, memory, tasks, automation rules). Those
     are DATA, not code, and are never something to "edit" this way.

Changes take effect on the NEXT RESTART — this app doesn't hot-reload its own
running code, and pretending otherwise would be worse than just saying so.
"""
from __future__ import annotations

import difflib
import sys
import time
from pathlib import Path


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR    = _base_dir()
BACKUPS_DIR = BASE_DIR / "self_backups"

# Directories JARVIS is allowed to read/write its own code in, plus the two
# top-level entry-point files.
_ALLOWED_DIRS  = {"actions", "core", "plugins", "dashboard", "memory"}
_ALLOWED_FILES = {"main.py", "ui.py"}
_ALLOWED_EXTS  = {".py", ".html", ".txt"}

_MAX_BACKUPS_PER_FILE = 10


def resolve_target(rel_path: str) -> Path | None:
    """Returns the absolute path if rel_path is inside the allow-list and
    inside BASE_DIR, else None. Blocks '..' escapes and anything outside the
    project — config/api_keys.json and the memory data files included,
    deliberately: those are never editable through this path."""
    rel_path = (rel_path or "").strip().replace("\\", "/").lstrip("/")
    if not rel_path:
        return None

    root = BASE_DIR.resolve()
    candidate = (root / rel_path).resolve()
    try:
        rel = candidate.relative_to(root)
    except ValueError:
        return None   # escapes the project root

    if candidate.suffix not in _ALLOWED_EXTS:
        return None

    parts = rel.parts
    if not parts:
        return None
    if len(parts) == 1:
        if parts[0] not in _ALLOWED_FILES:
            return None
    else:
        if parts[0] not in _ALLOWED_DIRS:
            return None
    return candidate


def list_editable_files() -> str:
    lines: list[str] = []
    for f in sorted(_ALLOWED_FILES):
        if (BASE_DIR / f).exists():
            lines.append(f)
    for d in sorted(_ALLOWED_DIRS):
        base = BASE_DIR / d
        if not base.exists():
            continue
        for p in sorted(base.rglob("*")):
            if (p.is_file() and p.suffix in _ALLOWED_EXTS
                    and "__pycache__" not in p.parts):
                lines.append(str(p.relative_to(BASE_DIR)).replace("\\", "/"))
    return "\n".join(lines)


def diff_stat(old: str, new: str) -> str:
    if not old:
        return f"New file — {len(new.splitlines())} lines."
    diff = list(difflib.unified_diff(old.splitlines(), new.splitlines(), lineterm=""))
    added   = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
    removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))
    return f"+{added} / -{removed} lines."


def _backup_path(rel_path: str) -> Path:
    BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    ts   = time.strftime("%Y%m%d_%H%M%S")
    flat = rel_path.replace("/", "__")
    return BACKUPS_DIR / f"{ts}__{flat}.bak"


def _backup(target: Path, rel_path: str) -> Path | None:
    if not target.exists():
        return None
    dest = _backup_path(rel_path)
    dest.write_bytes(target.read_bytes())
    _prune_backups(rel_path)
    return dest


def _prune_backups(rel_path: str) -> None:
    flat = rel_path.replace("/", "__")
    matches = sorted(BACKUPS_DIR.glob(f"*__{flat}.bak"))
    while len(matches) > _MAX_BACKUPS_PER_FILE:
        try:
            matches.pop(0).unlink()
        except Exception:
            pass


def _latest_backup(rel_path: str) -> Path | None:
    if not BACKUPS_DIR.exists():
        return None
    flat = rel_path.replace("/", "__")
    matches = sorted(BACKUPS_DIR.glob(f"*__{flat}.bak"))
    return matches[-1] if matches else None


def apply_edit(target: Path, rel_path: str, new_content: str) -> str:
    """Backs up the current file (if any), writes new_content. Never raises —
    this runs behind the confirm gate, on a worker thread that only logs."""
    try:
        _backup(target, rel_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(new_content, encoding="utf-8")
        return (f"Updated {rel_path}. Restart JARVIS for the change to take "
                f"effect — say \"undo my last code change\" if something breaks.")
    except Exception as e:
        return f"Could not write {rel_path}: {e}"


def undo_last(rel_path: str) -> str:
    """Restores rel_path from its most recent backup, after first backing up
    whatever is currently there — so an undo can itself be undone."""
    target = resolve_target(rel_path)
    if target is None:
        return f"'{rel_path}' isn't a file I'm allowed to touch."
    src = _latest_backup(rel_path)
    if src is None:
        return f"I don't have a backup for {rel_path} to restore."
    try:
        if target.exists():
            _backup(target, rel_path)   # preserve the pre-undo state too
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(src.read_bytes())
        return f"Restored {rel_path} from backup. Restart JARVIS to apply it."
    except Exception as e:
        return f"Could not restore {rel_path}: {e}"
