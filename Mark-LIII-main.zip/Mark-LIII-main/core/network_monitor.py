"""
Lightweight, dependency-free connectivity monitor.

Classifies the network into one of four states so the HUD can show a single
light that reflects whether JARVIS can actually *do* anything right now —
not just whether *some* internet connection exists:

    good     — the Gemini API host is reachable and fast
    slow     — the Gemini API host is reachable but laggy
    limited  — general internet works, but the Gemini API host does not
               (VPN / firewall / regional block — JARVIS's brain is
               unreachable even though the machine is "online")
    offline  — nothing is reachable

Uses raw TCP connects only (no requests/aiohttp dependency, no DNS-heavy HTTP
round trips) so this stays cheap enough to poll every few seconds forever.
"""

from __future__ import annotations

import socket
import time

# Host used for the Gemini Live API — a fast TCP+TLS connect here is a good
# proxy for "JARVIS's AI backend is reachable" without spending a full
# request/response round trip.
_API_HOST = "generativelanguage.googleapis.com"
_API_PORT = 443

# Host used purely to tell "no internet at all" apart from "internet works,
# just not to Google's AI API". A public DNS resolver's port is being
# raw-connected to (not queried), so this doesn't depend on the machine's own
# DNS server being configured correctly.
_INTERNET_HOST = "8.8.8.8"
_INTERNET_PORT = 53

_TIMEOUT = 1.5   # seconds — short enough not to stall a repeating poll loop
_SLOW_MS = 400   # latency above this on the API host reads as "slow"


def _tcp_probe(host: str, port: int, timeout: float = _TIMEOUT):
    """Raw TCP connect latency in ms, or None if it fails/times out."""
    start = time.monotonic()
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return (time.monotonic() - start) * 1000.0
    except Exception:
        return None


def check() -> tuple[str, str]:
    """Blocking — run this in a thread/executor, not on the event loop.

    Returns (status, detail):
        status is one of 'good' | 'slow' | 'limited' | 'offline'
        detail is a short human-readable string for a tooltip/log line.
    """
    api_ms = _tcp_probe(_API_HOST, _API_PORT)
    if api_ms is not None:
        if api_ms <= _SLOW_MS:
            return "good", f"{api_ms:.0f} ms to JARVIS's AI service"
        return "slow", f"{api_ms:.0f} ms to JARVIS's AI service — responses may lag"

    net_ms = _tcp_probe(_INTERNET_HOST, _INTERNET_PORT)
    if net_ms is not None:
        return "limited", "Internet is up, but JARVIS's AI service is unreachable"

    return "offline", "No internet connection"
