"""
Task/work queue plugin — hand JARVIS a piece of work to do on its own.

Use for things like "add to my task list: organize my downloads folder",
"what's on my task list", "mark the snake game task as done". Storage lives
in core/tasks.py; the actual execution of queued work happens autonomously
in main.py's background task worker (_run_task_worker), which replays a
pending task's description into the live session once the assistant is idle
— not mid-conversation — so it's solved with whatever real tools already
exist (dev_agent, browser_control, file_controller, web_search, etc.). This
plugin only lets the user manage the queue by voice.
"""
from core.tasks import add_task, list_tasks_text, complete_task, remove_task

PLUGIN = {
    "name": "manage_task",
    "description": (
        "Adds, lists, completes, or removes items on the user's task/work "
        "queue — things they've handed off for JARVIS to work on by itself in "
        "the background (building something, researching something, "
        "organizing files, etc.), as opposed to something to do right now. "
        "Use action='add' when the user says things like 'add this to my "
        "task list', 'here's something to work on', 'can you handle X for "
        "me', 'add a task: ...'. "
        "Use action='list' when they ask what's queued, pending, or in "
        "progress. "
        "Use action='complete' when they say a task is done or ask you to "
        "mark it done. "
        "Use action='remove' when they want a queued task deleted. "
        "Do NOT use this for something the user wants done immediately in "
        "this conversation — only for work to be picked up later, on its own."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "One of: 'add', 'list', 'complete', 'remove'.",
            },
            "description": {
                "type": "STRING",
                "description": (
                    "The task text, required for 'add'. For 'complete'/"
                    "'remove', a phrase that matches the task to find it."
                ),
            },
        },
        "required": ["action"],
    },
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    action      = (parameters.get("action") or "").strip().lower()
    description = parameters.get("description", "")

    try:
        if action == "add":
            result = add_task(description)
        elif action == "list":
            result = list_tasks_text()
        elif action == "complete":
            result = complete_task(description)
        elif action == "remove":
            result = remove_task(description)
        else:
            result = f"I don't recognize task action '{action}'."
    except Exception as e:
        return f"Task handling failed: {e}"

    if player:
        try:
            player.write_log(f"JARVIS: {result}")
        except Exception:
            pass
    return result
