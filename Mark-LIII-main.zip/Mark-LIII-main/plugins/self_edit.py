"""
Self-modification plugin — lets the user ask JARVIS to change its own code.

"propose_edit" never writes anything by itself: it generates the new file
content with an LLM, compile-checks it, and hands it to the SAME on-screen
CONFIRM gate used for shutdown/delete (core/confirm.py) — nothing is written
until a human presses CONFIRM on the HUD. See core/self_edit_backend.py for
the file allow-list, backups, and undo.

This is a plugin (not a built-in action) on purpose: it shows up in the
Plugin Manager like any other, so it can be switched off entirely for anyone
who doesn't want JARVIS touching its own code at all.
"""
from __future__ import annotations

import json
import re

from core import confirm as confirm_gate
from core.self_edit_backend import (
    BASE_DIR, resolve_target, list_editable_files, diff_stat, apply_edit, undo_last,
)

_WRITER_MODEL = "gemini-flash-latest"

_ARCH_PRIMER = (
    "This project auto-discovers tools at startup: a file under actions/ "
    "with a module-level `TOOL = {\"name\": ..., \"description\": ..., "
    "\"parameters\": {...}, \"handler\": some_function}` dict, OR a file "
    "under plugins/ with a module-level `PLUGIN = {\"name\": ..., "
    "\"description\": ..., \"parameters\": {...}}` dict plus a module-level "
    "`run(parameters, player=None, session_memory=None)` function, is picked "
    "up automatically — no other file needs to change to add one."
)


def _get_api_key() -> str:
    path = BASE_DIR / "config" / "api_keys.json"
    return json.loads(path.read_text(encoding="utf-8"))["gemini_api_key"]


def _strip_fences(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```[a-zA-Z]*\r?\n?", "", text)
    text = re.sub(r"\r?\n?```\s*$", "", text)
    return text.strip()


def _generate_new_content(rel_path: str, instruction: str, current: str) -> str:
    from google import genai as _genai
    client = _genai.Client(api_key=_get_api_key())
    is_new = not current
    prompt = (
        f"You are editing JARVIS's own source file: {rel_path}\n"
        + (_ARCH_PRIMER + "\n\n" if is_new else "\n")
        + f"Instruction: {instruction}\n\n"
        + ("This file does not exist yet — create it from scratch.\n\n"
           if is_new else
           f"CURRENT FILE CONTENT:\n{current}\n\n")
        + "Output ONLY the complete new file content. No markdown fences, "
          "no explanation, no commentary before or after. Preserve "
          "everything not related to the instruction. The result must be "
          "syntactically valid."
    )
    resp = client.models.generate_content(model=_WRITER_MODEL, contents=prompt)
    return _strip_fences(resp.text or "")


def _propose_edit(rel_path: str, instruction: str) -> str:
    rel_path = (rel_path or "").strip()
    target = resolve_target(rel_path)
    if target is None:
        return (
            f"I'm not allowed to edit '{rel_path}'. I can only edit my own "
            "code — files under actions/, core/, plugins/, dashboard/, "
            "memory/, or main.py / ui.py — never config or memory data files."
        )
    if not instruction or not instruction.strip():
        return "I need to know what change to make before I can propose one."

    current = target.read_text(encoding="utf-8") if target.exists() else ""

    try:
        new_content = _generate_new_content(rel_path, instruction, current)
    except Exception as e:
        return f"Could not generate the change: {e}"

    if not new_content.strip():
        return ("The generated file came back empty — not proposing that. "
                "Try rephrasing the instruction.")

    if target.suffix == ".py":
        try:
            compile(new_content, rel_path, "exec")
        except SyntaxError as e:
            return (f"The generated code has a syntax error ({e}) — not "
                     "proposing it. Try rephrasing the instruction.")

    # A drastically shrunken existing file is almost always the model losing
    # context mid-generation, not an intended change.
    if current and len(new_content) < 0.2 * len(current) and "delete" not in instruction.lower():
        return ("The generated file looks suspiciously truncated compared to "
                 "the original — not proposing it. Try a narrower instruction.")

    if new_content == current:
        return "That would produce no actual change — nothing to confirm."

    stat = diff_stat(current, new_content)

    if confirm_gate.pending_title():
        return "There is already a confirmation waiting on screen. Ask the user to answer that one first."

    return confirm_gate.request(
        key=f"self_edit:{rel_path}",
        title=f"Modify {rel_path}?",
        detail=(f"{instruction}\n\n{stat}\n"
                f"A backup is kept automatically. Restart JARVIS to apply."),
        run=lambda: apply_edit(target, rel_path, new_content),
    )


PLUGIN = {
    "name": "edit_own_code",
    "description": (
        "Proposes a change to JARVIS's OWN source code, applies a previously "
        "undone change back, or lists which of its own files can be edited. "
        "Use action='list_files' first if you don't already know which file "
        "to change. Use action='propose_edit' when the user asks you to "
        "change your own behavior or code, add a new action or plugin to "
        "yourself, or fix a bug in yourself — this NEVER writes anything by "
        "itself, it only puts an on-screen confirmation banner up; tell the "
        "user out loud that you need them to confirm it. Use "
        "action='undo_last' if the user says a recent self-change broke "
        "something and to revert it. NEVER use this tool for the user's own "
        "separate coding projects — that is a different tool's job, not this."
    ),
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "action": {
                "type": "STRING",
                "description": "One of: 'list_files', 'propose_edit', 'undo_last'.",
            },
            "target_file": {
                "type": "STRING",
                "description": (
                    "Path relative to the project root, e.g. 'ui.py', "
                    "'actions/reminder.py', 'plugins/new_feature.py'. "
                    "Required for 'propose_edit' and 'undo_last'."
                ),
            },
            "instruction": {
                "type": "STRING",
                "description": "Plain-language description of the change. Required for 'propose_edit'.",
            },
        },
        "required": ["action"],
    },
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    action      = (parameters.get("action") or "").strip().lower()
    target_file = parameters.get("target_file", "")
    instruction = parameters.get("instruction", "")

    try:
        if action == "list_files":
            files  = list_editable_files()
            result = ("My editable source files:\n" + files) if files else "I couldn't find any editable files."
        elif action == "propose_edit":
            result = _propose_edit(target_file, instruction)
        elif action == "undo_last":
            result = undo_last(target_file)
        else:
            result = f"I don't recognize self-edit action '{action}'."
    except Exception as e:
        return f"Self-edit failed: {e}"

    # propose_edit already raises its own on-screen confirmation banner —
    # don't double-log it as a plain chat line too.
    if player and action != "propose_edit":
        try:
            player.write_log(f"JARVIS: {result}")
        except Exception:
            pass
    return result
