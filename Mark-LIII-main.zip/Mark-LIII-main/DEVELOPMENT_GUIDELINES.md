# 📋 JARVIS DEVELOPMENT GUIDELINES
**Last Updated:** September 18, 2026

---

## Quick Reference

### 🛡️ Rule #1: NO FEATURE DELETION
Before removing anything:
1. Create backup
2. Document the reason
3. Get explicit approval
4. Test everything still works
5. Update CHANGELOG

See: `FEATURE_PROTECTION_POLICY.md`

### 🌐 Rule #2: Know Your Connectivity
**Jarvis Works:**
- ✅ Offline: Local AI, system control, file ops, automations
- ⚠️ Online: Web search, weather, browser, messages, YouTube
- 📊 See: `JARVIS_CONNECTIVITY_ANALYSIS.md`

### ✅ Rule #3: Always Test Before Commit
```
Must pass (every commit):
✓ Jarvis starts without errors
✓ At least 5 features tested
✓ No debug code left
✓ Commit message explains WHY
```

See: `BEFORE_YOU_COMMIT.md`

---

## File Inventory

### 📍 Safeguard Documentation (Added Sep 18, 2026)
```
✓ FEATURE_PROTECTION_POLICY.md   - Detailed safeguard rules (8.6 KB)
✓ JARVIS_CONNECTIVITY_ANALYSIS.md - Online/offline breakdown (16 KB)
✓ BEFORE_YOU_COMMIT.md            - Pre-commit checklist (7.2 KB)
✓ DEVELOPMENT_GUIDELINES.md       - This file
✓ MARK_LIII_ANALYSIS.md           - Version comparison (in root)
```

### 🎯 Core Project Files (All Intact - Sep 9, 2026)
```
✓ main.py                         - Main entry point (updated Sep 18)
✓ ui.py                           - UI framework (updated Sep 18)
✓ config/api_keys.json            - Configuration (local only)
✓ config/automation_rules.json    - Automation storage (NEW Sep 18)
```

### 🛠️ Action Modules (20 Total - All Intact)
```
✓ actions/background_monitor.py   - Background tasks
✓ actions/browser_control.py      - Web browser control
✓ actions/code_helper.py          - Code assistance
✓ actions/computer_control.py     - System control
✓ actions/computer_settings.py    - System settings
✓ actions/desktop.py              - Desktop control
✓ actions/dev_agent.py            - Development tools
✓ actions/file_controller.py      - File operations
✓ actions/file_processor.py       - File processing
✓ actions/flight_finder.py        - Flight search
✓ actions/game_updater.py         - Game management
✓ actions/open_app.py             - App launcher
✓ actions/proactive.py            - Proactive suggestions
✓ actions/reminder.py             - Reminders
✓ actions/screen_processor.py     - Screen capture
✓ actions/send_message.py         - Message sending
✓ actions/system_monitor.py       - System monitoring
✓ actions/weather_report.py       - Weather
✓ actions/web_search.py           - Web search
✓ actions/youtube_video.py        - YouTube control
```

### 🔧 Core Modules (12 Total - All Intact)
```
✓ core/action_loader.py           - Action discovery
✓ core/audio_devices.py           - Audio management
✓ core/confirm.py                 - User confirmation
✓ core/installer.py               - Dependency installer
✓ core/llm_client.py              - Local LLM interface
✓ core/plugin_loader.py           - Plugin system
✓ core/stt.py                     - Speech recognition
✓ core/tts.py                     - Text to speech
✓ core/undo.py                    - Undo functionality
✓ core/wake_word.py               - Wake word detection
✓ core/automation.py              - Automation rules (NEW Sep 18)
✓ memory/memory_manager.py        - Memory system
```

### 🌐 Dashboard (Updated Sep 18)
```
✓ dashboard/server.py             - WebSocket server
✓ dashboard/static/app.html       - Web UI (updated Sep 18)
```

### 📦 Plugins (1 New on Sep 18)
```
✓ plugins/_template.py            - Plugin template
✓ plugins/automation_control.py   - Automation management (NEW Sep 18)
```

---

## Development Workflow

### For Bug Fixes:
```
1. Create backup branch
2. Identify root cause
3. Fix only that issue
4. Test: Original + dependent features
5. Commit: [FIX] description
6. No files should be deleted
```

### For New Features:
```
1. Create feature branch
2. Implement feature
3. Test: All 20 actions + new feature
4. Document in CHANGELOG
5. Commit: [FEATURE] description
6. No files should be deleted
```

### For Refactoring:
```
1. Backup current version
2. Refactor code (behavior unchanged)
3. Test: All features work identically
4. No files should be deleted
5. Commit: [REFACTOR] description
6. Note: Code reorganization, behavior unchanged
```

### For Optimizations:
```
1. Measure performance baseline
2. Implement optimization
3. Measure new performance
4. Verify all features still work
5. Commit: [PERF] description
6. Include: % improvement metrics
7. No files should be deleted
```

---

## Testing Requirements

### Before Every Commit:
```
✓ No Python syntax errors
✓ Jarvis starts successfully
✓ LLM connects (Ollama/LM Studio)
✓ At least 1 action works
✓ No debug print/log statements
✓ No commented-out code
```

### Before Release:
```
✓ All 20 actions tested
✓ Automations work (create, trigger, delete)
✓ Reminders work (set, trigger, clear)
✓ File operations work
✓ System control works
✓ No features deleted or broken
✓ Offline capabilities intact
✓ CHANGELOG updated
✓ Version number bumped
✓ README updated (if needed)
```

---

## Key Statistics

| Metric | Value | Status |
|--------|-------|--------|
| Core Actions | 20 | ✅ All present |
| Core Modules | 12 | ✅ All present |
| New Features (Sep 18) | 3 | ✅ Added |
| Features Removed | 0 | ✅ Protected |
| Offline Capabilities | ~14 actions | ✅ Preserved |
| Internet-only Actions | ~6 actions | ⚠️ Documented |
| Documentation Files | 5 | ✅ Complete |
| Safeguard Checklists | 3 | ✅ Ready |

---

## Important Dates

| Date | Event | Status |
|------|-------|--------|
| Sep 9, 2026 | Original Mark-LIII | ✓ Baseline |
| Sep 18, 2026 | Update released | ✓ Additions only |
| Sep 18, 2026 | Safeguards added | ✓ Protection enabled |
| Today | You reading this | 🎯 Informed |

---

## Communication

### When Making Changes:
1. **Announce:** "I'm working on X"
2. **Show progress:** Share what you've done
3. **Test:** Verify everything works
4. **Review:** Get feedback before final commit
5. **Document:** Update CHANGELOG and commit message

### When Requesting Changes:
1. **Create backup:** Before applying updates
2. **List changes:** Know what's being changed
3. **Test carefully:** Each feature one by one
4. **Verify nothing broke:** Full test suite
5. **Keep backups:** Until confident

---

## Emergency Contacts

If something goes wrong:

1. **Backup exists?** Restore from backup
2. **Git history available?** Revert commit
3. **Time to debug?** Find root cause, fix, test
4. **Don't know?** Don't commit; ask first

---

## Code Quality Standards

### Naming:
```
✓ descriptive_function_name()     # Functions
✓ VariableForClass                # Classes
✓ CONSTANT_IN_CAPS                # Constants
✓ _private_to_module()            # Private functions
```

### Comments:
```
✓ # Why this code exists
✓ """Docstring explaining function"""
✓ Explain complex logic
✗ # Do this if x  (use variable names instead)
```

### Error Handling:
```
✓ try/except with specific errors
✓ Log what went wrong
✓ Return meaningful error messages
✗ Bare except: pass
```

### Performance:
```
✓ Use asyncio for I/O operations
✓ Queue up automation actions
✓ Don't block the main thread
✓ Cache frequently accessed data
```

---

## Resources

### Must Read:
1. `BEFORE_YOU_COMMIT.md` — Before any commit
2. `FEATURE_PROTECTION_POLICY.md` — For safety rules
3. `JARVIS_CONNECTIVITY_ANALYSIS.md` — Understand dependencies

### Reference:
- `readme.md` — Original documentation
- `MARK_LIII_ANALYSIS.md` — Feature comparison
- `config/api_keys.json` — Configuration

### Tools:
```
# Offline LLM
https://ollama.com              # Ollama
https://lmstudio.ai             # LM Studio

# Git
git status                      # See changes
git diff                        # See details
git log --oneline -20           # See history
git checkout HEAD~1 -- file     # Restore file
```

---

## Summary

**Before you commit anything:**
1. ✅ Create backup
2. ✅ Test 5+ features
3. ✅ Write clear commit message
4. ✅ Read BEFORE_YOU_COMMIT.md
5. ✅ Verify nothing deleted
6. ✅ Update CHANGELOG if needed

**Always remember:**
> A feature deleted is a workflow broken.  
> Test before you commit.  
> Ask before you delete.  
> Document why.

---

**Version:** 1.0  
**Last Updated:** September 18, 2026  
**Status:** Active & Protected ✅
