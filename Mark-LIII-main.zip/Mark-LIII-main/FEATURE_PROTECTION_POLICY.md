# 🛡️ JARVIS (MARK LIII) — FEATURE PROTECTION POLICY
**Version:** 1.0  
**Effective Date:** September 18, 2026  
**Last Updated:** September 18, 2026

---

## ⚠️ CRITICAL RULE: NO DELETION WITHOUT CONFIRMATION

### 🚫 NEVER Delete or Remove:
Before making ANY changes that could affect features, improvements, or capabilities:

1. **Create a backup of the current version**
   ```bash
   git checkout -b backup-$(date +%Y%m%d-%H%M%S)
   # or manually copy all files
   ```

2. **Document what you're changing**
   ```
   - WHAT: Which feature/file is changing?
   - WHY: Why is this change needed?
   - IMPACT: What existing features might this affect?
   - BEFORE: Save diff of original
   ```

3. **Test the change in isolation**
   - Test the new/modified feature works
   - Test ALL related features still work
   - Test dependent features aren't broken

4. **Create a CHANGELOG entry**
   ```
   ## [Date] - [Version]
   ### Changed
   - [Specific change with justification]
   ### Fixed
   - [What problem this solves]
   ### Verified
   - [List of features tested]
   ```

5. **Get explicit confirmation before committing**
   - Document all features tested
   - Verify nothing was removed
   - Get approval before merge/push

---

## 📋 Feature Inventory to Protect

### Core Action Modules (20 total) — DO NOT DELETE:
```
✓ background_monitor.py         ✓ open_app.py
✓ browser_control.py            ✓ proactive.py
✓ code_helper.py                ✓ reminder.py
✓ computer_control.py           ✓ screen_processor.py
✓ computer_settings.py          ✓ send_message.py
✓ desktop.py                    ✓ system_monitor.py
✓ dev_agent.py                  ✓ weather_report.py
✓ file_controller.py            ✓ web_search.py
✓ file_processor.py             ✓ youtube_video.py
✓ flight_finder.py
✓ game_updater.py
```

### Core Modules (12 total) — DO NOT DELETE:
```
✓ action_loader.py              ✓ plugin_loader.py
✓ audio_devices.py              ✓ stt.py
✓ confirm.py                    ✓ tts.py
✓ installer.py                  ✓ undo.py
✓ llm_client.py                 ✓ wake_word.py
✓ automation.py (NEW - Sep 18)   ✓ memory/memory_manager.py
```

### Recent Additions (Sep 18, 2026) — DO NOT DELETE:
```
✓ core/automation.py            - Automation rule engine
✓ plugins/automation_control.py - Voice control for automations
✓ Dashboard push notifications  - Browser notifications
✓ Dashboard quick actions       - Quick-action button UI
```

---

## 🔄 Change Approval Workflow

### Before Each Update:
1. List all files being modified/added
2. List all files being deleted (should be ZERO)
3. For each file deleted, provide:
   - **Feature Name:** Which user-facing feature will be removed?
   - **Reason:** Why must this be removed?
   - **Alternative:** Is there a way to keep it?
   - **User Impact:** How will users be affected?

### Example (BAD - Don't do this):
```
❌ Deleted: actions/web_search.py
   Reason: "Not using it"
   Impact: Users can't search the web anymore
   → NOT APPROVED
```

### Example (GOOD - With justification):
```
✅ Modified: ui.py
   Change: Font family Courier New → Segoe UI
   Reason: Better rendering consistency
   Impact: Visual improvement, no feature loss
   Tested: All UI elements render correctly
   → APPROVED
```

---

## 📊 Version Control Guidelines

### Commit Message Format:
```
[FEATURE] Add new automation rules system
- Added core/automation.py with rule matching
- Added plugins/automation_control.py for voice control
- Verified: All 20 actions still work, no deletions
- Tested: Background monitor, reminders, web_search

OR

[FIX] Fix font rendering inconsistency
- Changed ui.py font from Courier New to Segoe UI
- Verified: No features removed or broken
- Tested: Dashboard, notifications, all UI elements

Never use:
❌ "Cleanup" without specifics
❌ "Remove old code" without explanation
❌ "Refactor" that deletes features
```

### Branch Naming:
```
✓ feature/automation-rules
✓ fix/font-rendering
✓ docs/update-changelog
✓ backup/archive-v1.0

❌ cleanup
❌ delete-old-stuff
❌ remove-unused
```

---

## 🧪 Testing Checklist Before Any Commit

After making changes, verify:

### Core Functionality:
- [ ] Jarvis starts without errors
- [ ] LLM connection works (local Ollama/LM Studio)
- [ ] Speech recognition working
- [ ] Text-to-speech working
- [ ] Background monitoring active

### All 20 Action Modules:
- [ ] Web search (requires internet)
- [ ] Browser control (requires internet)
- [ ] Weather report (requires internet)
- [ ] Flight finder (requires internet)
- [ ] File operations (local only)
- [ ] Screen capture (local only)
- [ ] App launcher (local only)
- [ ] System monitor (local only)
- [ ] Code helper (local)
- [ ] Dev agent (local)
- [ ] Desktop control (local only)
- [ ] Computer settings (local only)
- [ ] Computer control (local only)
- [ ] Background monitor (local only)
- [ ] Reminders (local only)
- [ ] Message sending (hybrid)
- [ ] YouTube control (requires internet)
- [ ] Game updater (requires internet)
- [ ] Proactive suggestions (local)
- [ ] Screen processor (local only)

### New Features (if added):
- [ ] Feature works as intended
- [ ] Doesn't break existing features
- [ ] No unrelated code changed
- [ ] Error handling works
- [ ] Logged to CHANGELOG

### Removed Features (if any):
- [ ] User approval obtained
- [ ] Alternative solution provided (if applicable)
- [ ] Documentation updated
- [ ] Users notified in release notes
- [ ] Support plan in place

---

## 🚨 Emergency Procedures

### If you accidentally delete something:

1. **Stop immediately** — don't make more changes
2. **Restore from backup:**
   ```bash
   git checkout HEAD~1 -- <filename>
   # or manually copy from backup
   ```
3. **Document what happened**
4. **Report the incident** with timestamp

### If a feature breaks:

1. **Don't "fix" it by removing the feature**
2. **Debug the actual issue:**
   ```bash
   # Check error logs
   cat logs/jarvis.log
   
   # Test isolated component
   python -c "from actions.xyz import handler; handler({})"
   ```
3. **Fix the root cause**
4. **Verify fix doesn't break other features**

---

## 📝 Sample CHANGELOG Entry

```markdown
## [2026-09-18] - Mark LIII

### Added
- Automation rules system (core/automation.py, plugins/automation_control.py)
  - Users can now create "when I say X, do Y" voice macros
  - Up to 40 rules with 5 actions each
  - Local storage only, never synced
- Dashboard push notifications for backgrounded tab
- Dashboard quick-action buttons UI

### Changed
- ui.py: Centralized font management (Courier New → Segoe UI)
  - Improves consistency across all platforms
  - Better readability of UI elements
- main.py: Added automation queue processing

### Fixed
- Font rendering inconsistency on different OS

### Verified
✓ All 20 action modules working
✓ All 12 core modules intact
✓ Background monitor still active
✓ Reminders, web search, file operations intact
✓ Browser control, screen capture working
✓ Dashboard notifications enabled
✓ Local LLM connection stable

### Testing
- Tested automation rules creation and triggering
- Tested all existing features for regression
- Verified offline capabilities remain unchanged

### Migration
- Apply all files from mark_liii_updates/
- No data loss or compatibility breaks
- Existing automations/rules: None (new feature)
```

---

## ✅ Checklist Before Publishing Any Version

- [ ] No features deleted since last stable version
- [ ] CHANGELOG updated with detailed changes
- [ ] All 20 actions tested
- [ ] Backup created with timestamp
- [ ] Git history clean (meaningful commit messages)
- [ ] No commented-out code left behind
- [ ] No debug prints in production code
- [ ] Error handling complete
- [ ] Documentation updated
- [ ] Version number bumped (if releasing)
- [ ] Tested on actual hardware (not just code review)

---

## 🎯 Summary

**The Golden Rule:** 
> Every line of code you delete removes something a user depended on. Before deleting anything:
> 1. Ask: "Do I really need to delete this?"
> 2. If yes: "Could I disable it instead?"
> 3. If yes to both: "Have I verified it's truly unused?"
> 4. Only then: Delete with full documentation and testing.

**This protects:**
- User workflows
- Your own ability to recover mistakes
- Project stability and trust
- Development velocity (less time debugging regressions)

---

## 📞 Questions?

If you're unsure whether a change is safe:
1. Create the backup branch
2. Make the change
3. Run the full test checklist
4. Document your findings
5. Ask for review before merging

**Better safe than sorry!** 🛡️
